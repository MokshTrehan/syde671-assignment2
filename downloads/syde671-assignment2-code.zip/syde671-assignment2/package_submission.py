"""Package code+inputs and a complete assignment hand-in, without environments."""
from pathlib import Path
import hashlib
import json
import shutil
from zipfile import ZipFile, ZIP_DEFLATED

ROOT=Path(__file__).resolve().parent

def code_files():
    for p in sorted(ROOT.iterdir()):
        if p.is_file() and p.suffix in {'.py','.json','.txt','.md','.mjs'}:yield p
    for folder in ['src','tests','data','results']:
        for p in sorted((ROOT/folder).rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.zip','.pyc'} and p.name!='asset_contact_sheet.jpg':yield p
    for name in ['style.css','report.js']:
        yield ROOT/'site'/name

def main():
    out=ROOT/'output';out.mkdir(exist_ok=True)
    (ROOT/'site/downloads').mkdir(exist_ok=True)
    code=out/'syde671-assignment2-code.zip'
    with ZipFile(code,'w',ZIP_DEFLATED) as z:
        for p in code_files():z.write(p,Path('syde671-assignment2')/p.relative_to(ROOT))
    shutil.copy2(code,ROOT/'site/downloads'/code.name)
    pdf=out/'syde671-assignment2-report.pdf'
    if pdf.exists():shutil.copy2(pdf,ROOT/'site/downloads'/pdf.name)
    complete=out/'syde671-assignment2-submission.zip'
    with ZipFile(complete,'w',ZIP_DEFLATED) as z:
        if (ROOT/'SUBMISSION.md').exists():z.write(ROOT/'SUBMISSION.md','SUBMISSION.md')
        for p in sorted((ROOT/'site').rglob('*')):
            if p.is_file():z.write(p,Path('webpage')/p.relative_to(ROOT/'site'))
    manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [code,complete,pdf] if p.exists()}
    (out/'checksums.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps(manifest,indent=2))

if __name__=='__main__':main()
