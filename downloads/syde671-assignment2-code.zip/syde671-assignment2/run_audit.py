#!/usr/bin/env python3
"""Regenerate the report audit from the unchanged frequency experiment config."""
from src.audit_metrics import write_audit


def main(config=None, saved=None):
    """Also callable after run_frequencies generates its saved result dictionary."""
    result = write_audit(config=config, saved_result=saved)
    print('Saved results/audit.json; all saved measurements matched.', flush=True)
    return result


if __name__ == '__main__':
    main()
