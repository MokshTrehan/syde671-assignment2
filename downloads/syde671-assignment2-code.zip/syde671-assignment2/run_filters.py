#!/usr/bin/env python3
"""Generate all Part 1 / Part 2.1 figures and measured report content.

Run from this directory: .venv/bin/python run_filters.py
Sources are in data/provided; provenance is recorded in data/sources.json.
"""
from __future__ import annotations
import inspect
import json
from pathlib import Path
import time

import cv2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import hsv_to_rgb
import numpy as np
from PIL import Image, ImageOps
from scipy.signal import convolve2d

from src.filters import (DX, DY, _convolution_inputs, convolve_four_loops,
                         convolve_two_loops, gradient_magnitude,
                         orientation_without_angles, unsharp_kernel)

ROOT = Path(__file__).resolve().parent
IMAGES = ROOT / 'site/images'
RESULTS = ROOT / 'results'
DATA = ROOT / 'data/provided'
for directory in [IMAGES, RESULTS]:
    directory.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                     'figure.facecolor': '#f9fafb', 'axes.titleweight': 'semibold',
                     'axes.titlesize': 11, 'savefig.facecolor': '#f9fafb'})


def load(name, max_side=640, grayscale=False):
    im = ImageOps.exif_transpose(Image.open(DATA / name)).convert('RGB')
    im.thumbnail((max_side, max_side), Image.Resampling.LANCZOS)
    x = np.asarray(im, dtype=np.float64) / 255.0
    if grayscale:
        x = x @ np.array([0.299, 0.587, 0.114])
    return x


def figure_grid(name, items, cols=3, figsize=None, suptitle=None):
    rows = (len(items) + cols - 1) // cols
    if figsize is None:
        figsize = (4 * cols, 3.7 * rows)
    fig, axes = plt.subplots(rows, cols, figsize=figsize, squeeze=False,
                             constrained_layout=True)
    for ax, item in zip(axes.flat, items):
        arr, title, *options = item
        kwargs = options[0] if options else {}
        if arr.ndim == 2:
            kwargs = {'cmap': 'gray', **kwargs}
        ax.imshow(arr, **kwargs)
        ax.set_title(title, pad=8)
        ax.set_axis_off()
    for ax in list(axes.flat)[len(items):]:
        ax.set_axis_off()
    if suptitle:
        fig.suptitle(suptitle, fontsize=14, fontweight='bold')
    path = IMAGES / f'{name}.jpg'
    fig.savefig(path, dpi=150, bbox_inches='tight', pad_inches=0.14, pil_kwargs={'quality': 91})
    plt.close(fig)
    return f'images/{name}.jpg'


def table(title, columns, rows):
    return {'title': title, 'columns': columns, 'rows': rows}


def figref(path, caption):
    return {'path': path, 'caption': caption, 'alt': caption}


def gaussian(size, sigma):
    g1 = cv2.getGaussianKernel(size, sigma)
    return g1 @ g1.T


def channel_convolution(image, kernel, boundary='symm'):
    if image.ndim == 2:
        return convolve2d(image, kernel, mode='same', boundary=boundary)
    return np.stack([convolve2d(image[..., c], kernel, mode='same', boundary=boundary)
                     for c in range(image.shape[2])], axis=-1)


def edge_mask(magnitude, threshold, rim=7):
    mask = magnitude > threshold
    mask[:rim] = False; mask[-rim:] = False
    mask[:, :rim] = False; mask[:, -rim:] = False
    return mask


def crop_interior(x, rim=7):
    return x[rim:-rim, rim:-rim]


def mse(a, b):
    return float(np.mean((a - b) ** 2))


def psnr(a, b):
    error = mse(a, b)
    return float(10 * np.log10(1 / error)) if error else None


def convolution_section():
    selfie = load('selfie.jpg', max_side=512, grayscale=True)
    box = np.ones((9, 9), float) / 81
    smooth = convolve_two_loops(selfie, box)
    gx, gy = convolve_two_loops(selfie, DX), convolve_two_loops(selfie, DY)
    limit = max(np.quantile(np.abs(gx), .995), np.quantile(np.abs(gy), .995))
    path = figure_grid('filters_selfie', [
        (selfie, 'Self portrait · grayscale', {'vmin': 0, 'vmax': 1}),
        (smooth, '9 × 9 box convolution · zero padding', {'vmin': 0, 'vmax': 1}),
        (gx, 'Dₓ = [1, 0, −1] · signed response', {'cmap': 'RdBu_r', 'vmin': -limit, 'vmax': limit}),
        (gy, 'Dᵧ = Dₓᵀ · signed response', {'cmap': 'RdBu_r', 'vmin': -limit, 'vmax': limit})
    ], cols=4, figsize=(14, 5.1))
    rng = np.random.default_rng(671)
    cases = [('3×5 asymmetric', rng.normal(size=(3, 5))),
             ('2×4 asymmetric (even)', rng.normal(size=(2, 4))),
             ('9×9 box', box), ('1×3 derivative', DX)]
    sample = np.asarray(Image.fromarray(np.uint8(selfie * 255)).resize((96, 96)), float) / 255
    benchmark = []
    max_error = 0.0
    for label, kernel in cases:
        reference = convolve2d(sample, kernel, mode='same', boundary='fill', fillvalue=0)
        for name, method in [('Four loops', convolve_four_loops), ('Two loops', convolve_two_loops),
                             ('SciPy convolve2d', lambda i, k: convolve2d(i, k, mode='same', boundary='fill'))]:
            method(sample, kernel)  # Warm-up, excluded.
            timings = []
            for _ in range(3):
                t = time.perf_counter(); result = method(sample, kernel)
                timings.append((time.perf_counter() - t) * 1000)
            error = float(np.max(np.abs(result - reference)))
            max_error = max(max_error, error)
            benchmark.append([label, name, round(float(np.median(timings)), 3), f'{error:.2e}'])
    constant = np.ones((25, 25))
    boundary_rows = []
    for boundary in ['fill', 'symm', 'wrap']:
        result = convolve2d(constant, box, mode='same', boundary=boundary)
        boundary_rows.append([boundary, round(float(result[0, 0]), 6),
                              round(float(result[0, 12]), 6), round(float(result[12, 12]), 6)])
    section = {'id': 'part11', 'title': '1.1 · Convolutions from scratch', 'paragraphs': [
        'Both implementations compute true convolution: flip the kernel in both dimensions, zero-pad the image, and accumulate products. The four-loop version iterates over image rows, image columns, kernel rows, and kernel columns. The two-loop version keeps the two kernel loops and multiplies a whole shifted image slice at once. No convolution routine, FFT, window-view helper, or image-processing library is used inside either implementation.',
        'For a kernel of height Kh and width Kw, padding before each axis is floor(K/2) and padding after it is floor((K−1)/2). This asymmetry for even kernels matches SciPy’s “same” crop convention. Testing non-symmetric odd and even kernels is necessary: a symmetric Gaussian alone would not catch an accidental correlation or a one-pixel offset.',
        f'The grayscale selfie is {selfie.shape[1]} × {selfie.shape[0]} pixels; luminance uses 0.299R + 0.587G + 0.114B on RGB values in [0,1]. The 9 × 9 average removes fine texture. Dₓ and Dᵧ emphasize changes across columns and rows respectively; the signed display has one common symmetric color scale. Zero extension visibly darkens a smoothed outer rim and can introduce false derivatives at the frame.',
        f'For a fixed 96 × 96 selfie crop/resize, the table reports the median of three timed calls after one warm-up. Every method uses float64, zero extension, and “same” output. Maximum error across all comparisons is {max_error:.2e}. These are measurements on this computer, not universal speed claims. Both manual methods do O(HWKhKw) arithmetic; vectorizing the image operations removes Python’s per-pixel overhead.',
        'The boundary test uses an all-ones 25 × 25 image and a normalized 9 × 9 box. Zero fill produces 25/81 at a corner and 5/9 along an edge; symmetric and periodic extension preserve one everywhere. “Same” describes output size, not how pixels beyond the image are supplied.'
    ], 'figures': [figref(path, 'Self portrait, 9 × 9 box-filtered portrait, and signed horizontal/vertical derivatives. Red is positive and blue is negative; shared derivative scale clips only the strongest responses for visibility.')],
    'tables': [table('Runtime and correctness (96 × 96 float64 input)', ['Kernel', 'Method', 'Median ms', 'Max |error|'], benchmark),
               table('Boundary behavior of a constant image', ['SciPy boundary', 'Corner', 'Top edge midpoint', 'Center'], boundary_rows)],
    'code': [{'title': 'Input validation, kernel flip, and exact padding', 'text': inspect.getsource(_convolution_inputs)},
             {'title': 'Four-loop convolution', 'text': inspect.getsource(convolve_four_loops)},
             {'title': 'Two-loop convolution', 'text': inspect.getsource(convolve_two_loops)}]}
    return section, {'convolution_max_error': max_error, 'benchmark': benchmark}


def camera_sections():
    raw = Image.open(DATA / 'cameraman.png').convert('RGB')
    a = np.asarray(raw)
    ys, xs = np.nonzero(np.any(a < 250, axis=2))
    box = (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1)
    camera = np.asarray(raw.crop(box).resize((256, 256), Image.Resampling.LANCZOS), float) / 255
    camera = camera @ np.array([.299, .587, .114])
    Image.fromarray(np.uint8(np.clip(camera, 0, 1) * 255)).save(IMAGES / 'filters_cameraman_input.png')
    gx = convolve_two_loops(camera, DX); gy = convolve_two_loops(camera, DY)
    mag = gradient_magnitude(gx, gy)
    limit = .65
    gradient_fig = figure_grid('filters_finite_difference', [
        (camera, 'Cameraman · 256 × 256', {'vmin': 0, 'vmax': 1}),
        (gx, 'Horizontal derivative I ∗ Dₓ', {'cmap': 'RdBu_r', 'vmin': -limit, 'vmax': limit}),
        (gy, 'Vertical derivative I ∗ Dᵧ', {'cmap': 'RdBu_r', 'vmin': -limit, 'vmax': limit}),
        (mag, 'Magnitude √(gₓ² + gᵧ²)', {'vmin': 0, 'vmax': .65})
    ], cols=4, figsize=(14, 4.2))
    thresholds = [.08, .16, .24]
    masks = [edge_mask(mag, t) for t in thresholds]
    fractions = [float(crop_interior(m).mean()) for m in masks]
    threshold_fig = figure_grid('filters_thresholds', [
        (m, f'T = {t:.2f} · {fraction:.1%} retained' + ('\nSelected' if t == .16 else ''), {'vmin': 0, 'vmax': 1})
        for m, t, fraction in zip(masks, thresholds, fractions)], cols=3, figsize=(12, 4.4))
    part12 = {'id': 'part12', 'title': '1.2 · Finite difference operator', 'paragraphs': [
        'The horizontal and vertical responses are gx = I ∗ [1,0,−1] and gy = I ∗ [1,0,−1]ᵀ. True convolution flips the stencil, so a left-to-right brightening gives positive gx. Gradient magnitude is √(gx² + gy²); it combines both directions into an unsigned edge-strength map.',
        f'The supplied public cameraman rendering has a thin white border. I crop it to {box} (left, top, right, bottom; right/bottom excluded), then resize the remaining square to 256 × 256 with Lanczos. All calculations use floating intensities in [0,1], with no per-image normalization before thresholding.',
        f'I compare thresholds 0.08, 0.16, and 0.24, which retain {fractions[0]:.1%}, {fractions[1]:.1%}, and {fractions[2]:.1%} of the evaluated interior. I choose 0.16: it retains the person, camera, and tripod more clearly than 0.24 while rejecting much of the ground texture retained by 0.08. This is a visual tradeoff, not an accuracy score against annotated ground truth.',
        'The edge predicate is magnitude > T. A seven-pixel frame is excluded from binary maps and edge-fraction measurements throughout Part 1, preventing zero-padding artifacts from being mistaken for scene edges and matching the largest Gaussian derivative support used below. The signed derivative and magnitude images still show their unmasked responses.'
    ], 'figures': [figref(gradient_fig, 'Cameraman finite differences and gradient magnitude. Signed derivatives share [−0.65,0.65]; magnitude is displayed over [0,0.65].'),
                   figref(threshold_fig, 'Threshold sweep on the original finite-difference magnitude. The middle threshold balances contour continuity and background texture; black outer frame is excluded from evaluation.')],
    'tables': [table('Threshold sensitivity', ['Threshold', 'Interior edge fraction', 'Selection'],
                     [[t, f'{f:.2%}', 'Selected' if t == .16 else 'Comparison'] for t, f in zip(thresholds, fractions)])],
    'code': [{'title': 'Gradient and edge magnitude', 'text': 'gx = convolve_two_loops(image, DX)\ngy = convolve_two_loops(image, DY)\nmagnitude = np.sqrt(gx * gx + gy * gy)\nedges = magnitude > threshold'}]}
    size, sigma = 13, 2.0
    g = gaussian(size, sigma)
    blurred = convolve2d(camera, g, mode='same', boundary='fill')
    seqx = convolve2d(blurred, DX, mode='same'); seqy = convolve2d(blurred, DY, mode='same')
    dogx = convolve2d(g, DX, mode='full'); dogy = convolve2d(g, DY, mode='full')
    singlex = convolve2d(camera, dogx, mode='same'); singley = convolve2d(camera, dogy, mode='same')
    dogmag = gradient_magnitude(singlex, singley)
    full_blur = convolve2d(camera, g, mode='full')
    def halo_derivative(d, dog):
        full = convolve2d(full_blur, d, mode='full')
        y0, x0 = (np.array(dog.shape) - 1) // 2
        return full[y0:y0 + camera.shape[0], x0:x0 + camera.shape[1]]
    halox, haloy = halo_derivative(DX, dogx), halo_derivative(DY, dogy)
    halo_error = max(float(np.max(np.abs(singlex - halox))), float(np.max(np.abs(singley - haloy))))
    same_error = max(float(np.max(np.abs(singlex - seqx))), float(np.max(np.abs(singley - seqy))))
    interior_error = max(float(np.max(np.abs(crop_interior(singlex - seqx)))), float(np.max(np.abs(crop_interior(singley - seqy)))))
    kernel_fig = figure_grid('filters_dog_kernels', [
        (g, 'G · 13 × 13 · σ = 2 px', {'cmap': 'viridis'}),
        (dogx, 'G ∗ Dₓ · 13 × 15', {'cmap': 'RdBu_r', 'vmin': -np.abs(dogx).max(), 'vmax': np.abs(dogx).max()}),
        (dogy, 'G ∗ Dᵧ · 15 × 13', {'cmap': 'RdBu_r', 'vmin': -np.abs(dogy).max(), 'vmax': np.abs(dogy).max()})
    ], cols=3, figsize=(12, 4.5))
    smoothed_derivatives_fig = figure_grid('filters_smoothed_derivatives', [
        (seqx, 'Smoothed horizontal derivative\n(I ∗ G) ∗ Dₓ', {'cmap': 'RdBu_r', 'vmin': -.35, 'vmax': .35}),
        (seqy, 'Smoothed vertical derivative\n(I ∗ G) ∗ Dᵧ', {'cmap': 'RdBu_r', 'vmin': -.35, 'vmax': .35}),
        (gradient_magnitude(seqx, seqy), 'Smoothed gradient magnitude\n√(gₓ² + gᵧ²)', {'vmin': 0, 'vmax': .35})
    ], cols=3, figsize=(12, 4.5))
    dog_fig = figure_grid('filters_dog_comparison', [
        (blurred, 'Gaussian-smoothed image', {'vmin': 0, 'vmax': 1}),
        (dogmag, 'Single DoG gradient magnitude', {'vmin': 0, 'vmax': .35}),
        (edge_mask(mag, .16), 'Raw derivative edges · T = 0.16', {'vmin': 0, 'vmax': 1}),
        (edge_mask(dogmag, .08), 'DoG edges · T = 0.08', {'vmin': 0, 'vmax': 1}),
        (np.abs(singlex - seqx), 'Naïve same/same discrepancy\nBoundary only', {'cmap': 'magma', 'vmin': 0, 'vmax': max(same_error, 1e-15)}),
        (np.abs(singlex - halox), f'Halo-preserved discrepancy\nmax = {halo_error:.1e}', {'cmap': 'magma', 'vmin': 0, 'vmax': 1e-12})
    ], cols=3, figsize=(12, 8))
    rng = np.random.default_rng(671)
    noisy = np.clip(camera + rng.normal(0, .08, camera.shape), 0, 1)
    ngx = convolve2d(noisy, DX, mode='same'); ngy = convolve2d(noisy, DY, mode='same')
    ndx = convolve2d(noisy, dogx, mode='same'); ndy = convolve2d(noisy, dogy, mode='same')
    raw_noise_rms = float(np.sqrt(np.mean(crop_interior(ngx - gx) ** 2 + crop_interior(ngy - gy) ** 2)))
    dog_noise_rms = float(np.sqrt(np.mean(crop_interior(ndx - singlex) ** 2 + crop_interior(ndy - singley) ** 2)))
    noise_fig = figure_grid('filters_noise', [
        (noisy, 'Added noise · σ = 0.08 · clipped [0,1]', {'vmin': 0, 'vmax': 1}),
        (edge_mask(gradient_magnitude(ngx, ngy), .16), 'Noisy finite differences · T = 0.16', {'vmin': 0, 'vmax': 1}),
        (edge_mask(gradient_magnitude(ndx, ndy), .08), 'Noisy DoG · T = 0.08', {'vmin': 0, 'vmax': 1})
    ], cols=3, figsize=(12, 4.3))
    part13 = {'id': 'part13', 'title': '1.3 · Derivative of Gaussian', 'paragraphs': [
        'I construct a 13 × 13 Gaussian at σ = 2 pixels as the outer product of cv2.getGaussianKernel(13,2) with itself. First blur with G, then differentiate with Dₓ/Dᵧ. Equivalently, form Kx = G ∗ Dₓ and Ky = G ∗ Dᵧ once, then use a single convolution per derivative. These are finite-difference derivatives of the sampled Gaussian; their supports are 13 × 15 and 15 × 13 because full kernel convolution preserves the extra two samples.',
        f'Convolution associativity gives I ∗ (G ∗ D) = (I ∗ G) ∗ D on the same zero-extended infinite image. In a finite implementation, calling “same” after BOTH stages throws away the blurred halo and breaks equality at the frame: the maximum error here is {same_error:.3g}, although the evaluated interior agrees to {interior_error:.2e}. Retaining the full Gaussian result, applying the derivative, and cropping only once restores agreement over the entire image to {halo_error:.2e}. The discrepancy panel makes this boundary issue explicit.',
        'Compared with raw finite differences, DoG removes fine grass texture and yields smoother, wider contours. It can merge nearby edges and remove weak detail; Gaussian smoothing is therefore a noise/detail tradeoff. I use T = 0.08 for DoG and T = 0.16 for raw gradients because smoothing lowers response amplitudes. These are separately chosen operating points, not proof that one detector has higher accuracy.',
        f'To test noise sensitivity, I add seeded Gaussian noise with σ = 0.08 and clip to [0,1]. I compare each noisy gradient with its own clean counterpart, avoiding the mistake of calling intentional smoothing a noise error. Interior vector-gradient residual RMS falls from {raw_noise_rms:.5f} for finite differences to {dog_noise_rms:.5f} for DoG ({raw_noise_rms / dog_noise_rms:.1f}× lower). This measures stability for this image/noise realization, not recovery of lost detail.'
    ], 'figures': [figref(kernel_fig, 'Gaussian and its sampled derivative kernels. A common signed scale is used for the x/y derivative kernels; the Gaussian uses its own nonnegative scale.'),
                   figref(smoothed_derivatives_fig, 'Repeating the finite-difference procedure after Gaussian smoothing: signed horizontal and vertical derivatives share the scale [−0.35,0.35], followed by their magnitude on [0,0.35]. These panels use sequential same-sized convolutions with zero padding; the boundary-equivalence comparison below explains the difference from a single DoG convolution.'),
                   figref(dog_fig, 'Gaussian derivative results, raw/DoG threshold maps, and the difference between finite implementations. Preserving the intermediate halo is necessary for global equality.'),
                   figref(noise_fig, 'Controlled noisy cameraman experiment. Gaussian derivatives reject much of the high-frequency noise that triggers raw finite differences.')],
    'tables': [table('Convolution equivalence and noise measurements', ['Measurement', 'Value'], [
        ['Same/same vs single DoG · max error', f'{same_error:.6g}'],
        ['Interior same/same vs single DoG · max error', f'{interior_error:.2e}'],
        ['Halo-preserved sequential vs single DoG · max error', f'{halo_error:.2e}'],
        ['Raw gradient noise RMS', f'{raw_noise_rms:.6f}'],
        ['DoG gradient noise RMS', f'{dog_noise_rms:.6f}']])],
    'code': [{'title': 'Build Gaussian derivative kernels', 'text': 'g1 = cv2.getGaussianKernel(13, 2.0)\nG = g1 @ g1.T\nKx = convolve2d(G, DX, mode="full")\nKy = convolve2d(G, DY, mode="full")\ngx = convolve2d(image, Kx, mode="same", boundary="fill")\ngy = convolve2d(image, Ky, mode="same", boundary="fill")'}]}
    angles = orientation_without_angles(singlex, singley)
    hsv = np.zeros((*camera.shape, 3))
    hsv[..., 0] = np.mod(angles, 2 * np.pi) / (2 * np.pi)
    hsv[..., 1] = 1
    p995 = np.quantile(crop_interior(dogmag), .995)
    hsv[..., 2] = np.clip(dogmag / p995, 0, 1) ** .7
    hsv[:7, :, 2] = 0; hsv[-7:, :, 2] = 0; hsv[:, :7, 2] = 0; hsv[:, -7:, 2] = 0
    orientation_rgb = hsv_to_rgb(hsv)
    n = 241
    yy, xx = np.mgrid[-1:1:complex(n), -1:1:complex(n)]
    radius = np.sqrt(xx * xx + yy * yy)
    wheel_hsv = np.stack([np.mod(orientation_without_angles(xx, yy), 2 * np.pi) / (2 * np.pi),
                          np.ones_like(xx), np.ones_like(xx)], axis=-1)
    wheel = hsv_to_rgb(wheel_hsv); wheel[radius > 1] = .98; wheel[radius < .5] = .98
    orientation_fig = figure_grid('filters_orientation', [
        (camera, 'Cameraman · source', {'vmin': 0, 'vmax': 1}),
        (orientation_rgb, 'Hue = directed gradient\nBrightness = edge strength'),
        (wheel, 'Direction color wheel\nRight 0° · Down 90° · Left 180° · Up 270°')
    ], cols=3, figsize=(12, 4.6))
    # Independent angle oracle is used only in validation, not image construction.
    angle_error = float(np.max(np.abs(angles - np.arctan2(singley, singlex))))
    orientation = {'id': 'orientation', 'title': 'Mandatory extension · Gradient orientations', 'paragraphs': [
        'The orientation implementation calls no arctangent, atan2, or angle routine. It takes r = min(|gy|,|gx|)/max(|gy|,|gx|), then range-reduces r above √2−1 using atan(r) = π/4 + atan((r−1)/(r+1)). The reduced argument has magnitude at most √2−1, so 18 terms of z − z³/3 + z⁵/5 − … converge accurately. Coordinate swaps and component signs restore all four quadrants; a zero gradient is assigned angle zero and displayed black.',
        f'Hue is θ mod 2π divided by 2π; saturation is one. Value is min(magnitude / p99.5, 1)^0.7, with p99.5 = {p995:.4f}, so stronger gradients appear brighter and faint background responses remain subdued. The colors represent directed intensity change, not the tangent direction of the edge. Since image rows increase downward, 90° points down. NumPy atan2 is used only as an independent validation reference: maximum angular error on this figure is {angle_error:.2e} radians.'
    ], 'figures': [figref(orientation_fig, 'HSV orientation visualization computed without built-in angle functions. Direction follows image coordinates; the seven-pixel border is excluded.')],
    'tables': [], 'code': [{'title': 'Arithmetic-only orientation implementation', 'text': inspect.getsource(orientation_without_angles)}]}
    return [part12, part13, orientation], {'cameraman_crop': list(box), 'camera_shape': list(camera.shape),
        'raw_threshold': .16, 'dog_threshold': .08, 'gaussian_size': size, 'gaussian_sigma': sigma,
        'dog_halo_max_error': halo_error, 'dog_naive_boundary_max_error': same_error,
        'dog_interior_max_error': interior_error, 'raw_noise_rms': raw_noise_rms,
        'dog_noise_rms': dog_noise_rms, 'orientation_max_error_radians': angle_error}


def sharpening_section():
    g = gaussian(13, 2.0)
    alphas = [.5, 1., 2.]
    figures = []
    rows = []
    comparison_errors = []
    for filename, label in [('taj.jpg', 'Taj Mahal'), ('sharp.jpg', 'Original street photograph')]:
        original = load(filename, max_side=640)
        blur = channel_convolution(original, g)
        high = original - blur
        sharpened = [channel_convolution(original, unsharp_kernel(g, a)) for a in alphas]
        identity_error = float(np.max(np.abs(sharpened[1] - (original + high))))
        comparison_errors.append(identity_error)
        clip_fractions = [float(np.mean((result < 0) | (result > 1))) for result in sharpened]
        hf_display = np.clip(.5 + 2 * high, 0, 1)
        stem = 'taj' if filename == 'taj.jpg' else 'street'
        path = figure_grid(f'sharpen_{stem}_sweep', [
            (original, f'{label} · original'),
            (blur, 'Gaussian low frequencies · σ = 2'),
            (hf_display, 'High frequencies · 0.5 + 2(I − G∗I)'),
            *[(np.clip(result, 0, 1), f'α = {a:g} · clipped samples {fraction:.2%}')
              for a, result, fraction in zip(alphas, sharpened, clip_fractions)]
        ], cols=3, figsize=(12, 8))
        figures.append(figref(path, f'{label}: original, blurred image, high-frequency residual (mid-gray means zero, amplified 2×), and unsharp results at α = 0.5, 1, 2. RGB channels are filtered separately; final display values are clipped to [0,1].'))
        for a, fraction in zip(alphas, clip_fractions):
            rows.append([label, a, f'{fraction:.3%}'])
    # Recovery test must start from an actually sharp source, keep all float data
    # until final display, and compare against that exact pre-blur source.
    sharp = load('sharp.jpg', max_side=640)
    blur = channel_convolution(sharp, g)
    results = [(a, channel_convolution(blur, unsharp_kernel(g, a))) for a in alphas]
    metric_rows = [['Original', '—', '0', '∞', '0', '∞']]
    metric_rows.append(['Blurred', '—', f'{mse(sharp, blur):.6f}', f'{psnr(sharp, blur):.2f}',
                        f'{mse(sharp, blur):.6f}', f'{psnr(sharp, blur):.2f}'])
    for alpha, recovered in results:
        clipped = np.clip(recovered, 0, 1)
        metric_rows.append(['Resharpened', alpha, f'{mse(sharp, recovered):.6f}', f'{psnr(sharp, recovered):.2f}',
                            f'{mse(sharp, clipped):.6f}', f'{psnr(sharp, clipped):.2f}'])
    best_alpha, recovered = min(results, key=lambda item: mse(sharp, np.clip(item[1], 0, 1)))
    recovered_clip = np.clip(recovered, 0, 1)
    h, w = sharp.shape[:2]
    # Fixed central region includes fine street / building / foliage structures.
    y0, y1, x0, x1 = int(h * .3), int(h * .7), int(w * .25), int(w * .65)
    crop = (slice(y0, y1), slice(x0, x1))
    error = np.mean(np.abs(recovered_clip - sharp), axis=-1)
    recover_fig = figure_grid('sharpen_blur_recovery', [
        (sharp, 'Sharp source · reference'), (blur, 'Artificially blurred · σ = 2'),
        (recovered_clip, f'Resharpened blur · α = {best_alpha:g}'),
        (sharp[crop], 'Reference · fixed crop'), (blur[crop], 'Blurred · same crop'),
        (recovered_clip[crop], 'Resharpened · same crop')
    ], cols=3, figsize=(12, 8.4))
    figures.append(figref(recover_fig, f'Blur-and-resharpen experiment on the original street photograph. The lower row enlarges exactly the same fixed region from each output. α = {best_alpha:g} is the best of the three tested settings by clipped RGB MSE against the original; it does not reproduce the source.'))
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), constrained_layout=True)
    f = np.linspace(0, .5, 300)
    # 1-D transfer through horizontal frequency, exactly sampled finite G.
    axis = np.arange(g.shape[1]) - g.shape[1] // 2
    transfer = np.real(np.exp(-2j * np.pi * f[:, None] * axis[None, :]) @ g.sum(axis=0))
    axes[0].plot(f, np.ones_like(f), '--', color='#64748b', label='Original response = 1')
    axes[0].plot(f, transfer, label='Blur: G(f)', color='#257b94')
    for a in alphas:
        axes[0].plot(f, transfer * (1 + a - a * transfer), label=f'Blur + unsharp, α={a:g}')
    axes[0].set(xlabel='Horizontal frequency (cycles/pixel)', ylabel='Amplitude gain', title='Why sharpening cannot undo blur', ylim=(-.05, 1.25))
    axes[0].grid(alpha=.2); axes[0].legend(fontsize=8)
    display = axes[1].imshow(error, cmap='magma', vmin=0, vmax=.15)
    axes[1].set_title('Mean absolute RGB recovery error'); axes[1].set_axis_off()
    fig.colorbar(display, ax=axes[1], fraction=.04)
    error_path = IMAGES / 'sharpen_recovery_error.jpg'
    fig.savefig(error_path, dpi=150, bbox_inches='tight', pad_inches=0.14, pil_kwargs={'quality': 91}); plt.close(fig)
    figures.append(figref('images/sharpen_recovery_error.jpg', 'Left: horizontal frequency response of the actual discrete Gaussian and the blur-plus-unsharp pipeline. High frequencies that the Gaussian strongly attenuates remain attenuated. Right: residual error against the sharp reference, using the selected recovery setting.'))
    section = {'id': 'part21', 'title': '2.1 · Image sharpening', 'paragraphs': [
        'Let B = G ∗ I be the low-pass image and H = I − B its high-frequency residual. Unsharp masking forms S = I + αH = (1 + α)I − α(G ∗ I). Since I = δ ∗ I and convolution is linear, one convolution suffices: S = [(1 + α)δ − αG] ∗ I. The kernel has unit sum, so a constant image is preserved when the boundary extension also preserves constants.',
        'I use a 13 × 13 Gaussian at σ = 2 pixels, symmetric boundaries to avoid dark zero-padded borders, and independent float64 RGB-channel processing. All computation keeps signed residuals and unclipped sharpened values until display/export. The figures include the Taj Mahal, an additional original street photograph, and α = 0.5, 1, 2. Increasing α strengthens existing edges and texture but also amplifies noise, halos, and values outside the display range.',
        f'The single-convolution expression agrees with I + α(I − G∗I) at α = 1 to a maximum error of {max(comparison_errors):.2e} over these images. High-frequency residuals are displayed as 0.5 + 2H, where middle gray means zero; they are not independently normalized. The clipped-sample table counts RGB channel values outside [0,1] before clipping, exposing a cost hidden by an attractive display.',
        f'For the recovery experiment, I deliberately blur the original street image once, then sharpen that blurred image with the same Gaussian at each tested α. The best tested display result is α = {best_alpha:g}: clipped RGB MSE changes from {mse(sharp, blur):.6f} after blur to {mse(sharp, recovered_clip):.6f} after sharpening, and PSNR changes from {psnr(sharp, blur):.2f} to {psnr(sharp, recovered_clip):.2f} dB. The parameter was selected against this reference and is not a general optimum.',
        'Resharpening makes blurred transitions steeper but does not restore all original detail. If the blur transfer is G(f), the blur-then-unsharp transfer is G(f)[1 + α − αG(f)], which is generally not one. Frequencies reduced nearly to zero cannot be reconstructed by this finite boost, and clipping can discard additional information. The crop, residual map, and nonzero MSE support this limitation; perceptual crispness alone does not establish recovery.'
    ], 'figures': figures, 'tables': [
        table('RGB samples outside display range before clipping', ['Image', 'Alpha', 'Out-of-range samples'], rows),
        table('Recovery relative to sharp street reference (RGB in [0,1])', ['Stage', 'Alpha', 'Float MSE', 'Float PSNR dB', 'Clipped MSE', 'Clipped PSNR dB'], metric_rows)],
    'code': [{'title': 'Single-convolution sharpening kernel', 'text': inspect.getsource(unsharp_kernel)}]}
    return section, {'sharpen_identity_max_error': max(comparison_errors), 'recovery_best_tested_alpha': best_alpha,
                     'recovery_mse_blur': mse(sharp, blur), 'recovery_mse_sharp': mse(sharp, recovered_clip),
                     'recovery_psnr_blur': psnr(sharp, blur), 'recovery_psnr_sharp': psnr(sharp, recovered_clip),
                     'recovery_crop_xyxy': [x0, y0, x1, y1], 'sharpen_gaussian_size': 13, 'sharpen_gaussian_sigma': 2.0}


def main():
    first, m1 = convolution_section()
    camera, m2 = camera_sections()
    sharpen, m3 = sharpening_section()
    result = {'sections': [first, *camera, sharpen], 'measurements': {**m1, **m2, **m3},
              'source_files': ['src/filters.py', 'run_filters.py', 'tests/test_filters.py'],
              'validation': {'command': '.venv/bin/python -m unittest tests.test_filters -v',
                             'test_count': 7, 'note': 'Independent regression tests cover non-symmetric/even kernels, true kernel flip, zero boundaries, halo associativity, all-quadrant orientation, and unsharp identity.'}}
    (RESULTS / 'filters.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result['measurements'], indent=2))
    print(f'Wrote {len(result["sections"])} report sections to results/filters.json')


if __name__ == '__main__':
    main()
