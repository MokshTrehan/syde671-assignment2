#!/usr/bin/env python3
"""Generate all Part 1 / Part 2.1 figures and measured report content.

Run from this directory: .venv/bin/python run_filters.py
Sources are in data/provided; provenance is recorded in data/sources.json.
"""
from __future__ import annotations
import inspect
import json
from pathlib import Path
import time

import cv2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import hsv_to_rgb
import numpy as np
from PIL import Image, ImageOps
from scipy.signal import convolve2d

from src.filters import (DX, DY, _convolution_inputs, convolve_four_loops,
                         convolve_two_loops, gradient_magnitude,
                         orientation_without_angles, unsharp_kernel)

ROOT = Path(__file__).resolve().parent
IMAGES = ROOT / 'site/images'
RESULTS = ROOT / 'results'
DATA = ROOT / 'data/provided'
for directory in [IMAGES, RESULTS]:
    directory.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                     'figure.facecolor': '#f9fafb', 'axes.titleweight': 'semibold',
                     'axes.titlesize': 11, 'savefig.facecolor': '#f9fafb'})


def load(name, max_side=640, grayscale=False):
    im = ImageOps.exif_transpose(Image.open(DATA / name)).convert('RGB')
    im.thumbnail((max_side, max_side), Image.Resampling.LANCZOS)
    x = np.asarray(im, dtype=np.float64) / 255.0
    if grayscale:
        x = x @ np.array([0.299, 0.587, 0.114])
    return x


def figure_grid(name, items, cols=3, figsize=None, suptitle=None):
    rows = (len(items) + cols - 1) // cols
    if figsize is None:
        figsize = (4 * cols, 3.7 * rows)
    fig, axes = plt.subplots(rows, cols, figsize=figsize, squeeze=False,
                             constrained_layout=True)
    for ax, item in zip(axes.flat, items):
        arr, title, *options = item
        kwargs = options[0] if options else {}
        if arr.ndim == 2:
            kwargs = {'cmap': 'gray', **kwargs}
        ax.imshow(arr, **kwargs)
        ax.set_title(title, pad=8)
        ax.set_axis_off()
    for ax in list(axes.flat)[len(items):]:
        ax.set_axis_off()
    if suptitle:
        fig.suptitle(suptitle, fontsize=14, fontweight='bold')
    path = IMAGES / f'{name}.jpg'
    fig.savefig(path, dpi=150, bbox_inches='tight', pad_inches=0.14, pil_kwargs={'quality': 91})
    plt.close(fig)
    return f'images/{name}.jpg'


def table(title, columns, rows):
    return {'title': title, 'columns': columns, 'rows': rows}


def figref(path, caption):
    return {'path': path, 'caption': caption, 'alt': caption}


def gaussian(size, sigma):
    g1 = cv2.getGaussianKernel(size, sigma)
    return g1 @ g1.T


def channel_convolution(image, kernel, boundary='symm'):
    if image.ndim == 2:
        return convolve2d(image, kernel, mode='same', boundary=boundary)
    return np.stack([convolve2d(image[..., c], kernel, mode='same', boundary=boundary)
                     for c in range(image.shape[2])], axis=-1)


def edge_mask(magnitude, threshold, rim=7):
    mask = magnitude > threshold
    mask[:rim] = False; mask[-rim:] = False
    mask[:, :rim] = False; mask[:, -rim:] = False
    return mask


def crop_interior(x, rim=7):
    return x[rim:-rim, rim:-rim]


def mse(a, b):
    return float(np.mean((a - b) ** 2))


def psnr(a, b):
    error = mse(a, b)
    return float(10 * np.log10(1 / error)) if error else None


def convolution_section():
    selfie = load('selfie.jpg', max_side=512, grayscale=True)
    box = np.ones((9, 9), float) / 81
    smooth = convolve_two_loops(selfie, box)
    gx, gy = convolve_two_loops(selfie, DX), convolve_two_loops(selfie, DY)
    limit = max(np.quantile(np.abs(gx), .995), np.quantile(np.abs(gy), .995))
    path = figure_grid('filters_selfie', [
        (selfie, 'Self portrait · grayscale', {'vmin': 0, 'vmax': 1}),
        (smooth, '9 × 9 box convolution · zero padding', {'vmin': 0, 'vmax': 1}),
        (gx, 'Dₓ = [1, 0, −1] · signed response', {'cmap': 'RdBu_r', 'vmin': -limit, 'vmax': limit}),
        (gy, 'Dᵧ = Dₓᵀ · signed response', {'cmap': 'RdBu_r', 'vmin': -limit, 'vmax': limit})
    ], cols=4, figsize=(14, 5.1))
    rng = np.random.default_rng(671)
    cases = [('3×5 asymmetric', rng.normal(size=(3, 5))),
             ('2×4 asymmetric (even)', rng.normal(size=(2, 4))),
             ('9×9 box', box), ('1×3 derivative', DX)]
    sample = np.asarray(Image.fromarray(np.uint8(selfie * 255)).resize((96, 96)), float) / 255
    benchmark = []
    max_error = 0.0
    for label, kernel in cases:
        reference = convolve2d(sample, kernel, mode='same', boundary='fill', fillvalue=0)
        for name, method in [('Four loops', convolve_four_loops), ('Two loops', convolve_two_loops),
                             ('SciPy convolve2d', lambda i, k: convolve2d(i, k, mode='same', boundary='fill'))]:
            method(sample, kernel)  # Warm-up, excluded.
            timings = []
            for _ in range(3):
                t = time.perf_counter(); result = method(sample, kernel)
                timings.append((time.perf_counter() - t) * 1000)
            error = float(np.max(np.abs(result - reference)))
            max_error = max(max_error, error)
            benchmark.append([label, name, round(float(np.median(timings)), 3), f'{error:.2e}'])
    constant = np.ones((25, 25))
    boundary_rows = []
    for boundary in ['fill', 'symm', 'wrap']:
        result = convolve2d(constant, box, mode='same', boundary=boundary)
        boundary_rows.append([boundary, round(float(result[0, 0]), 6),
                              round(float(result[0, 12]), 6), round(float(result[12, 12]), 6)])
    section = {'id': 'part11', 'title': '1.1 · Convolutions from scratch', 'paragraphs': [
        'Convolution flips the kernel in both dimensions and sums the products of overlapping samples. Both implementations use zero padding outside the image. The four-loop implementation iterates over image rows, image columns, kernel rows, and kernel columns. The two-loop implementation keeps the two kernel loops and operates on a complete shifted image slice at each step. Neither implementation uses a convolution routine, FFT, window-view helper, or image-processing library.',
        'For a kernel of height Kh and width Kw, let K denote the kernel size along one axis. The padding is floor(K/2) samples before that axis and floor((K−1)/2) after it. For even kernels, this asymmetry matches SciPy’s “same” output convention. Comparisons use non-symmetric odd and even kernels because a symmetric Gaussian alone cannot reveal a reversed kernel or a one-pixel offset.',
        f'The self portrait is converted to grayscale using 0.299R + 0.587G + 0.114B, with RGB values in [0, 1]. The working image is {selfie.shape[1]} × {selfie.shape[0]} pixels. A normalized 9 × 9 box filter and the derivative kernels Dₓ and Dᵧ are applied separately.',
        'The box filter removes fine texture. Dₓ and Dᵧ emphasize changes across columns and rows, respectively; their signed responses share a symmetric color scale. Zero padding darkens the outer rim of the smoothed image and can produce derivative responses at the frame.',
        f'The runtime comparison uses a fixed 96 × 96 image resized from the self portrait. Each method uses float64 values, zero padding, and “same” output. The table reports the median of three calls after one warm-up, with a maximum absolute error of {max_error:.2e} across all comparisons.',
        'For an H × W image and a Kh × Kw kernel, both manual methods require O(HWKhKw) arithmetic. Operating on image slices removes Python’s per-pixel loop overhead. The reported times describe performance on this computer.',
        'The boundary comparison uses a constant 25 × 25 image with value one and a normalized 9 × 9 box filter. Zero padding gives 25/81 at a corner and 5/9 at the midpoint of an edge; symmetric and periodic extension preserve one everywhere. The “same” setting controls output size, while the boundary setting supplies values outside the image.'
    ], 'paragraph_headings': {0: 'Convolution method', 2: 'Self-portrait results', 4: 'Runtime and numerical agreement', 6: 'Boundary conditions'},
    'figures': [figref(path, 'Self portrait, box-filtered image, and signed horizontal and vertical derivatives. Red indicates positive responses and blue indicates negative responses. The shared derivative scale clips the strongest responses for display.')],
    'tables': [table('Runtime and numerical agreement · 96 × 96 float64 input', ['Kernel', 'Method', 'Median time (ms)', 'Max. absolute error'], benchmark),
               table('Boundary values for a constant image', ['SciPy boundary setting', 'Corner', 'Top edge midpoint', 'Center'], boundary_rows)],
    'code': [{'title': 'Input validation, kernel reversal, and padding', 'text': inspect.getsource(_convolution_inputs)},
             {'title': 'Four-loop convolution', 'text': inspect.getsource(convolve_four_loops)},
             {'title': 'Two-loop convolution', 'text': inspect.getsource(convolve_two_loops)}]}
    return section, {'convolution_max_error': max_error, 'benchmark': benchmark}


def camera_sections():
    raw = Image.open(DATA / 'cameraman.png').convert('RGB')
    a = np.asarray(raw)
    ys, xs = np.nonzero(np.any(a < 250, axis=2))
    box = (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1)
    camera = np.asarray(raw.crop(box).resize((256, 256), Image.Resampling.LANCZOS), float) / 255
    camera = camera @ np.array([.299, .587, .114])
    Image.fromarray(np.uint8(np.clip(camera, 0, 1) * 255)).save(IMAGES / 'filters_cameraman_input.png')
    gx = convolve_two_loops(camera, DX); gy = convolve_two_loops(camera, DY)
    mag = gradient_magnitude(gx, gy)
    limit = .65
    gradient_fig = figure_grid('filters_finite_difference', [
        (camera, 'Cameraman · 256 × 256', {'vmin': 0, 'vmax': 1}),
        (gx, 'Horizontal derivative I ∗ Dₓ', {'cmap': 'RdBu_r', 'vmin': -limit, 'vmax': limit}),
        (gy, 'Vertical derivative I ∗ Dᵧ', {'cmap': 'RdBu_r', 'vmin': -limit, 'vmax': limit}),
        (mag, 'Magnitude √(gₓ² + gᵧ²)', {'vmin': 0, 'vmax': .65})
    ], cols=4, figsize=(14, 4.2))
    thresholds = [.08, .16, .24]
    masks = [edge_mask(mag, t) for t in thresholds]
    fractions = [float(crop_interior(m).mean()) for m in masks]
    threshold_fig = figure_grid('filters_thresholds', [
        (m, f'T = {t:.2f} · {fraction:.1%} retained' + ('\nSelected' if t == .16 else ''), {'vmin': 0, 'vmax': 1})
        for m, t, fraction in zip(masks, thresholds, fractions)], cols=3, figsize=(12, 4.4))
    part12 = {'id': 'part12', 'title': '1.2 · Finite difference operator', 'paragraphs': [
        'Let I be the grayscale image. Its horizontal and vertical derivative responses are gx = I ∗ [1, 0, −1] and gy = I ∗ [1, 0, −1]ᵀ, where ∗ denotes convolution. Reversing the kernel during convolution makes a left-to-right increase in intensity produce positive gx. The gradient magnitude, √(gx² + gy²), combines the two responses into an unsigned measure of edge strength.',
        f'The supplied cameraman image has a thin white border. The crop {box}, given as (left, top, right, bottom) with the right and bottom coordinates excluded, removes that border. The remaining square is resized to 256 × 256 pixels with Lanczos interpolation. Calculations use floating-point intensities in [0, 1] without further normalization before thresholding.',
        'A pixel is classified as an edge when its gradient magnitude exceeds the threshold T. A seven-pixel frame is excluded from binary maps and edge-fraction measurements throughout Part 1. This margin excludes responses caused by zero padding and covers the largest Gaussian derivative support used below. The signed derivative and magnitude images show the complete responses.',
        f'Thresholds of 0.08, 0.16, and 0.24 retain {fractions[0]:.1%}, {fractions[1]:.1%}, and {fractions[2]:.1%} of the evaluated interior, respectively. The selected threshold, 0.16, preserves the person, camera, and tripod more clearly than 0.24 while rejecting much of the ground texture retained at 0.08. Selection is based on this visual balance; detection accuracy is not measured against annotated edges.'
    ], 'paragraph_headings': {0: 'Gradient calculation', 3: 'Threshold comparison'},
    'figures': [figref(gradient_fig, 'Cameraman finite differences and gradient magnitude. Signed derivatives share the range [−0.65, 0.65]; magnitude uses [0, 0.65].'),
                   figref(threshold_fig, 'Threshold comparison for the finite-difference magnitude. The selected threshold is 0.16. The black outer frame is excluded from evaluation.')],
    'tables': [table('Threshold sensitivity', ['Threshold', 'Interior edge fraction', 'Selection'],
                     [[t, f'{f:.2%}', 'Selected' if t == .16 else 'Comparison'] for t, f in zip(thresholds, fractions)])],
    'code': [{'title': 'Gradient and edge magnitude', 'text': 'gx = convolve_two_loops(image, DX)\ngy = convolve_two_loops(image, DY)\nmagnitude = np.sqrt(gx * gx + gy * gy)\nedges = magnitude > threshold'}]}
    size, sigma = 13, 2.0
    g = gaussian(size, sigma)
    blurred = convolve2d(camera, g, mode='same', boundary='fill')
    seqx = convolve2d(blurred, DX, mode='same'); seqy = convolve2d(blurred, DY, mode='same')
    dogx = convolve2d(g, DX, mode='full'); dogy = convolve2d(g, DY, mode='full')
    singlex = convolve2d(camera, dogx, mode='same'); singley = convolve2d(camera, dogy, mode='same')
    dogmag = gradient_magnitude(singlex, singley)
    full_blur = convolve2d(camera, g, mode='full')
    def halo_derivative(d, dog):
        full = convolve2d(full_blur, d, mode='full')
        y0, x0 = (np.array(dog.shape) - 1) // 2
        return full[y0:y0 + camera.shape[0], x0:x0 + camera.shape[1]]
    halox, haloy = halo_derivative(DX, dogx), halo_derivative(DY, dogy)
    halo_error = max(float(np.max(np.abs(singlex - halox))), float(np.max(np.abs(singley - haloy))))
    same_error = max(float(np.max(np.abs(singlex - seqx))), float(np.max(np.abs(singley - seqy))))
    interior_error = max(float(np.max(np.abs(crop_interior(singlex - seqx)))), float(np.max(np.abs(crop_interior(singley - seqy)))))
    kernel_fig = figure_grid('filters_dog_kernels', [
        (g, 'G · 13 × 13 · σ = 2 px', {'cmap': 'viridis'}),
        (dogx, 'G ∗ Dₓ · 13 × 15', {'cmap': 'RdBu_r', 'vmin': -np.abs(dogx).max(), 'vmax': np.abs(dogx).max()}),
        (dogy, 'G ∗ Dᵧ · 15 × 13', {'cmap': 'RdBu_r', 'vmin': -np.abs(dogy).max(), 'vmax': np.abs(dogy).max()})
    ], cols=3, figsize=(12, 4.5))
    smoothed_derivatives_fig = figure_grid('filters_smoothed_derivatives', [
        (seqx, 'Smoothed horizontal derivative\n(I ∗ G) ∗ Dₓ', {'cmap': 'RdBu_r', 'vmin': -.35, 'vmax': .35}),
        (seqy, 'Smoothed vertical derivative\n(I ∗ G) ∗ Dᵧ', {'cmap': 'RdBu_r', 'vmin': -.35, 'vmax': .35}),
        (gradient_magnitude(seqx, seqy), 'Smoothed gradient magnitude\n√(gₓ² + gᵧ²)', {'vmin': 0, 'vmax': .35})
    ], cols=3, figsize=(12, 4.5))
    dog_fig = figure_grid('filters_dog_comparison', [
        (blurred, 'Gaussian-smoothed image', {'vmin': 0, 'vmax': 1}),
        (dogmag, 'Single DoG gradient magnitude', {'vmin': 0, 'vmax': .35}),
        (edge_mask(mag, .16), 'Raw derivative edges · T = 0.16', {'vmin': 0, 'vmax': 1}),
        (edge_mask(dogmag, .08), 'DoG edges · T = 0.08', {'vmin': 0, 'vmax': 1}),
        (np.abs(singlex - seqx), 'Naïve same/same discrepancy\nBoundary only', {'cmap': 'magma', 'vmin': 0, 'vmax': max(same_error, 1e-15)}),
        (np.abs(singlex - halox), f'Halo-preserved discrepancy\nmax = {halo_error:.1e}', {'cmap': 'magma', 'vmin': 0, 'vmax': 1e-12})
    ], cols=3, figsize=(12, 8))
    rng = np.random.default_rng(671)
    noisy = np.clip(camera + rng.normal(0, .08, camera.shape), 0, 1)
    ngx = convolve2d(noisy, DX, mode='same'); ngy = convolve2d(noisy, DY, mode='same')
    ndx = convolve2d(noisy, dogx, mode='same'); ndy = convolve2d(noisy, dogy, mode='same')
    raw_noise_rms = float(np.sqrt(np.mean(crop_interior(ngx - gx) ** 2 + crop_interior(ngy - gy) ** 2)))
    dog_noise_rms = float(np.sqrt(np.mean(crop_interior(ndx - singlex) ** 2 + crop_interior(ndy - singley) ** 2)))
    noise_fig = figure_grid('filters_noise', [
        (noisy, 'Added noise · σ = 0.08 · clipped [0,1]', {'vmin': 0, 'vmax': 1}),
        (edge_mask(gradient_magnitude(ngx, ngy), .16), 'Noisy finite differences · T = 0.16', {'vmin': 0, 'vmax': 1}),
        (edge_mask(gradient_magnitude(ndx, ndy), .08), 'Noisy DoG · T = 0.08', {'vmin': 0, 'vmax': 1})
    ], cols=3, figsize=(12, 4.3))
    part13 = {'id': 'part13', 'title': '1.3 · Derivative of Gaussian', 'paragraphs': [
        'A 13 × 13 Gaussian kernel G with σ = 2 pixels is formed from the outer product of cv2.getGaussianKernel(13, 2) with itself. The image is first smoothed with G, then differentiated with Dₓ and Dᵧ.',
        'Alternatively, Kx = G ∗ Dₓ and Ky = G ∗ Dᵧ combine smoothing and differentiation into one image convolution per direction. These finite-difference derivatives of the sampled Gaussian have supports of 13 × 15 and 15 × 13 pixels because full kernel convolution retains the extra two samples.',
        'Convolution associativity gives I ∗ (G ∗ D) = (I ∗ G) ∗ D for an image extended with zeros. Applying “same” output after each stage crops the intermediate blurred image and removes values beyond the original frame. These removed values affect the subsequent derivative near the boundary.',
        f'The two successive “same” convolutions differ from a single Gaussian derivative convolution by at most {same_error:.3g} over the complete image, while the evaluated interior agrees to {interior_error:.2e}. Retaining the full blurred image, applying the derivative, and cropping once reduces the maximum difference to {halo_error:.2e}. The difference images show where the intermediate crop affects the result.',
        'The derivative of Gaussian (DoG) suppresses fine grass texture and produces smoother, wider contours than finite differences on the original image. Smoothing can also merge nearby edges and remove weak detail. The selected thresholds are T = 0.08 for DoG and T = 0.16 for the original gradients because smoothing reduces response amplitudes. These thresholds support a visual comparison at separately chosen settings; they do not establish a difference in detection accuracy.',
        'The noise experiment adds Gaussian noise with σ = 0.08 using a fixed random seed, then clips intensities to [0, 1]. Each noisy gradient is compared with the same method applied to the clean image. This comparison measures the change caused by noise while retaining each method’s smoothing effect.',
        f'The root mean square (RMS) of the interior vector-gradient residual decreases from {raw_noise_rms:.5f} for finite differences to {dog_noise_rms:.5f} for DoG, a factor of {raw_noise_rms / dog_noise_rms:.1f}. Gaussian smoothing therefore reduces sensitivity to the added noise in this experiment. The measurement describes this image and noise realization; it does not measure recovery of detail removed by smoothing.'
    ], 'paragraph_headings': {0: 'Gaussian derivative kernels', 2: 'Boundary conditions', 4: 'Edge comparison', 5: 'Noise sensitivity'},
    'figures': [figref(kernel_fig, 'Gaussian kernel and its sampled horizontal and vertical derivatives. The derivative kernels share a signed scale; the Gaussian uses a separate nonnegative scale.'),
                   figref(smoothed_derivatives_fig, 'Finite differences after Gaussian smoothing, using two successive “same” convolutions with zero padding. Signed derivatives share [−0.35, 0.35]; magnitude uses [0, 0.35].'),
                   figref(dog_fig, 'Gaussian derivative results, thresholded edges, and boundary differences. Retaining the complete intermediate blurred image restores agreement between sequential and combined convolution.'),
                   figref(noise_fig, 'Cameraman image with added Gaussian noise and the resulting edge maps. Gaussian smoothing suppresses many of the noise responses visible with finite differences.')],
    'tables': [table('Convolution agreement and noise sensitivity', ['Measurement', 'Value'], [
        ['Two successive “same” convolutions vs. DoG · maximum error', f'{same_error:.6g}'],
        ['Two successive “same” convolutions vs. DoG · interior maximum error', f'{interior_error:.2e}'],
        ['Full intermediate image vs. DoG · maximum error', f'{halo_error:.2e}'],
        ['Finite-difference gradient residual RMS', f'{raw_noise_rms:.6f}'],
        ['DoG gradient residual RMS', f'{dog_noise_rms:.6f}']])],
    'code': [{'title': 'Build Gaussian derivative kernels', 'text': 'g1 = cv2.getGaussianKernel(13, 2.0)\nG = g1 @ g1.T\nKx = convolve2d(G, DX, mode="full")\nKy = convolve2d(G, DY, mode="full")\ngx = convolve2d(image, Kx, mode="same", boundary="fill")\ngy = convolve2d(image, Ky, mode="same", boundary="fill")'}]}
    angles = orientation_without_angles(singlex, singley)
    hsv = np.zeros((*camera.shape, 3))
    hsv[..., 0] = np.mod(angles, 2 * np.pi) / (2 * np.pi)
    hsv[..., 1] = 1
    p995 = np.quantile(crop_interior(dogmag), .995)
    hsv[..., 2] = np.clip(dogmag / p995, 0, 1) ** .7
    hsv[:7, :, 2] = 0; hsv[-7:, :, 2] = 0; hsv[:, :7, 2] = 0; hsv[:, -7:, 2] = 0
    orientation_rgb = hsv_to_rgb(hsv)
    n = 241
    yy, xx = np.mgrid[-1:1:complex(n), -1:1:complex(n)]
    radius = np.sqrt(xx * xx + yy * yy)
    wheel_hsv = np.stack([np.mod(orientation_without_angles(xx, yy), 2 * np.pi) / (2 * np.pi),
                          np.ones_like(xx), np.ones_like(xx)], axis=-1)
    wheel = hsv_to_rgb(wheel_hsv); wheel[radius > 1] = .98; wheel[radius < .5] = .98
    orientation_fig = figure_grid('filters_orientation', [
        (camera, 'Cameraman · source', {'vmin': 0, 'vmax': 1}),
        (orientation_rgb, 'Hue = directed gradient\nBrightness = edge strength'),
        (wheel, 'Direction color wheel\nRight 0° · Down 90° · Left 180° · Up 270°')
    ], cols=3, figsize=(12, 4.6))
    # Independent angle oracle is used only in validation, not image construction.
    angle_error = float(np.max(np.abs(angles - np.arctan2(singley, singlex))))
    orientation = {'id': 'orientation', 'title': 'Gradient orientations', 'paragraphs': [
        'Gradient orientation is computed from gx and gy using arithmetic operations without calling an arctangent, atan2, or angle routine. First, r = min(|gy|, |gx|)/max(|gy|, |gx|) gives a ratio between zero and one. For r > √2−1, the identity atan(r) = π/4 + atan((r−1)/(r+1)) reduces the magnitude of the series argument to at most √2−1.',
        'The arctangent is approximated with 18 terms of z − z³/3 + z⁵/5 − …, where z is the reduced argument. Coordinate swaps and the signs of the gradient components determine the quadrant. A zero gradient is assigned orientation zero and displayed black.',
        f'The HSV display maps orientation θ to hue (θ mod 2π)/(2π), with saturation one. Brightness is min(magnitude / p99.5, 1)^0.7, where p99.5 = {p995:.4f} is the 99.5th percentile of gradient magnitude in the evaluated interior. Stronger gradients appear brighter, while weak background responses remain subdued. The seven-pixel boundary margin is displayed black.',
        f'Color indicates the direction of increasing intensity, perpendicular to the edge tangent. Image rows increase downward, so 90° points down. Comparison with NumPy atan2, used only for validation, gives a maximum angular error of {angle_error:.2e} radians for this image.'
    ], 'paragraph_headings': {0: 'Orientation calculation', 2: 'Color representation and validation'},
    'figures': [figref(orientation_fig, 'Gradient orientation and direction color wheel. Hue represents direction in image coordinates; brightness represents edge strength. The seven-pixel boundary margin is excluded.')],
    'tables': [], 'code': [{'title': 'Arithmetic-only orientation implementation', 'text': inspect.getsource(orientation_without_angles)}]}
    return [part12, part13, orientation], {'cameraman_crop': list(box), 'camera_shape': list(camera.shape),
        'raw_threshold': .16, 'dog_threshold': .08, 'gaussian_size': size, 'gaussian_sigma': sigma,
        'dog_halo_max_error': halo_error, 'dog_naive_boundary_max_error': same_error,
        'dog_interior_max_error': interior_error, 'raw_noise_rms': raw_noise_rms,
        'dog_noise_rms': dog_noise_rms, 'orientation_max_error_radians': angle_error}


def sharpening_section():
    g = gaussian(13, 2.0)
    alphas = [.5, 1., 2.]
    figures = []
    rows = []
    comparison_errors = []
    for filename, label in [('taj.jpg', 'Taj Mahal'), ('sharp.jpg', 'Original street photograph')]:
        original = load(filename, max_side=640)
        blur = channel_convolution(original, g)
        high = original - blur
        sharpened = [channel_convolution(original, unsharp_kernel(g, a)) for a in alphas]
        identity_error = float(np.max(np.abs(sharpened[1] - (original + high))))
        comparison_errors.append(identity_error)
        clip_fractions = [float(np.mean((result < 0) | (result > 1))) for result in sharpened]
        hf_display = np.clip(.5 + 2 * high, 0, 1)
        stem = 'taj' if filename == 'taj.jpg' else 'street'
        path = figure_grid(f'sharpen_{stem}_sweep', [
            (original, f'{label} · original'),
            (blur, 'Gaussian low frequencies · σ = 2'),
            (hf_display, 'High frequencies · 0.5 + 2(I − G∗I)'),
            *[(np.clip(result, 0, 1), f'α = {a:g} · clipped samples {fraction:.2%}')
              for a, result, fraction in zip(alphas, sharpened, clip_fractions)]
        ], cols=3, figsize=(12, 8))
        figures.append(figref(path, f'{label}: original image, Gaussian blur, high-frequency residual, and sharpening at α = 0.5, 1, and 2. The residual is displayed as 0.5 + 2H. Final display values are clipped to [0, 1].'))
        for a, fraction in zip(alphas, clip_fractions):
            rows.append([label, a, f'{fraction:.3%}'])
    # Recovery test must start from an actually sharp source, keep all float data
    # until final display, and compare against that exact pre-blur source.
    sharp = load('sharp.jpg', max_side=640)
    blur = channel_convolution(sharp, g)
    results = [(a, channel_convolution(blur, unsharp_kernel(g, a))) for a in alphas]
    metric_rows = [['Original', '—', '0', '∞', '0', '∞']]
    metric_rows.append(['Blurred', '—', f'{mse(sharp, blur):.6f}', f'{psnr(sharp, blur):.2f}',
                        f'{mse(sharp, blur):.6f}', f'{psnr(sharp, blur):.2f}'])
    for alpha, recovered in results:
        clipped = np.clip(recovered, 0, 1)
        metric_rows.append(['Resharpened', alpha, f'{mse(sharp, recovered):.6f}', f'{psnr(sharp, recovered):.2f}',
                            f'{mse(sharp, clipped):.6f}', f'{psnr(sharp, clipped):.2f}'])
    best_alpha, recovered = min(results, key=lambda item: mse(sharp, np.clip(item[1], 0, 1)))
    recovered_clip = np.clip(recovered, 0, 1)
    h, w = sharp.shape[:2]
    # Fixed central region includes fine street / building / foliage structures.
    y0, y1, x0, x1 = int(h * .3), int(h * .7), int(w * .25), int(w * .65)
    crop = (slice(y0, y1), slice(x0, x1))
    error = np.mean(np.abs(recovered_clip - sharp), axis=-1)
    recover_fig = figure_grid('sharpen_blur_recovery', [
        (sharp, 'Sharp source · reference'), (blur, 'Artificially blurred · σ = 2'),
        (recovered_clip, f'Resharpened blur · α = {best_alpha:g}'),
        (sharp[crop], 'Reference · fixed crop'), (blur[crop], 'Blurred · same crop'),
        (recovered_clip[crop], 'Resharpened · same crop')
    ], cols=3, figsize=(12, 8.4))
    figures.append(figref(recover_fig, f'Blur and sharpening of the original street photograph. The lower row shows the same fixed region from each image. α = {best_alpha:g} gives the lowest clipped RGB MSE among the three tested settings.'))
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), constrained_layout=True)
    f = np.linspace(0, .5, 300)
    # 1-D transfer through horizontal frequency, exactly sampled finite G.
    axis = np.arange(g.shape[1]) - g.shape[1] // 2
    transfer = np.real(np.exp(-2j * np.pi * f[:, None] * axis[None, :]) @ g.sum(axis=0))
    axes[0].plot(f, np.ones_like(f), '--', color='#64748b', label='Original response = 1')
    axes[0].plot(f, transfer, label='Blur: G(f)', color='#257b94')
    for a in alphas:
        axes[0].plot(f, transfer * (1 + a - a * transfer), label=f'Blur + unsharp, α={a:g}')
    axes[0].set(xlabel='Horizontal frequency (cycles/pixel)', ylabel='Amplitude gain', title='Why sharpening cannot undo blur', ylim=(-.05, 1.25))
    axes[0].grid(alpha=.2); axes[0].legend(fontsize=8)
    display = axes[1].imshow(error, cmap='magma', vmin=0, vmax=.15)
    axes[1].set_title('Mean absolute RGB recovery error'); axes[1].set_axis_off()
    fig.colorbar(display, ax=axes[1], fraction=.04)
    error_path = IMAGES / 'sharpen_recovery_error.jpg'
    fig.savefig(error_path, dpi=150, bbox_inches='tight', pad_inches=0.14, pil_kwargs={'quality': 91}); plt.close(fig)
    figures.append(figref('images/sharpen_recovery_error.jpg', 'Left: horizontal frequency response of the discrete Gaussian and the combined blur and sharpening operations. Right: mean absolute RGB error against the sharp reference at the selected setting.'))
    section = {'id': 'part21', 'title': '2.1 · Image sharpening', 'paragraphs': [
        'For an input image I and Gaussian kernel G, let B = G ∗ I be the low-pass image and H = I − B its high-frequency residual. Unsharp masking adds a scaled residual: S = I + αH, where α controls the sharpening amount.',
        'Expanding the residual gives S = (1 + α)I − α(G ∗ I). The equivalent convolution kernel is K = (1 + α)δ − αG, where δ is the unit impulse, so S = K ∗ I requires one convolution. K sums to one and preserves a constant image when the boundary extension also preserves constants.',
        'The experiment uses a 13 × 13 Gaussian with σ = 2 pixels and symmetric boundary extension. Each RGB channel is processed independently in float64, retaining signed residuals and values outside [0, 1] until display export. Symmetric extension avoids the dark borders introduced by zero padding. The Taj Mahal and an original street photograph are processed at α = 0.5, 1, and 2.',
        'Increasing α strengthens existing edges and texture, but also amplifies noise and halos and increases values outside the display range. Residuals are displayed as 0.5 + 2H, with middle gray representing zero and a fixed amplification of two. No independent normalization is applied to these residuals. The table reports the fraction of scalar RGB values outside [0, 1] before display clipping.',
        f'The single-convolution result agrees with S = I + α(I − G ∗ I) at α = 1 to a maximum absolute error of {max(comparison_errors):.2e} across the two images. This comparison checks the equivalence of the residual and kernel formulations.',
        'The recovery experiment first blurs the original street image, then sharpens that blurred image with the same Gaussian at each tested α. Mean squared error (MSE) is measured over RGB values relative to the original image, both before and after display clipping. For the reference range [0, 1], peak signal-to-noise ratio is PSNR = 10 log10(1/MSE), in decibels.',
        f'Among the tested settings, α = {best_alpha:g} gives the lowest clipped RGB MSE. The MSE changes from {mse(sharp, blur):.6f} after blurring to {mse(sharp, recovered_clip):.6f} after sharpening, while PSNR changes from {psnr(sharp, blur):.2f} to {psnr(sharp, recovered_clip):.2f} dB. This parameter is selected against the original reference and applies to this comparison.',
        'Sharpening makes blurred transitions steeper but leaves differences from the original image. If G(f) is the Gaussian frequency response, the combined blur and sharpening response is G(f)[1 + α − αG(f)], which generally differs from one. Frequencies strongly attenuated by the blur remain attenuated after this finite amplification, and clipping can remove additional information. The enlarged crop, residual map, and nonzero MSE show that increased edge contrast does not restore all original detail.'
    ], 'paragraph_headings': {0: 'Unsharp masking', 3: 'Sharpening results', 5: 'Recovery after blurring'},
    'figures': figures, 'tables': [
        table('RGB values outside the display range', ['Image', 'α', 'Values outside [0, 1]'], rows),
        table('Recovery relative to the original street image · RGB reference in [0, 1]', ['Stage', 'α', 'Unclipped MSE', 'Unclipped PSNR (dB)', 'Clipped MSE', 'Clipped PSNR (dB)'], metric_rows)],
    'code': [{'title': 'Single-convolution sharpening kernel', 'text': inspect.getsource(unsharp_kernel)}]}
    return section, {'sharpen_identity_max_error': max(comparison_errors), 'recovery_best_tested_alpha': best_alpha,
                     'recovery_mse_blur': mse(sharp, blur), 'recovery_mse_sharp': mse(sharp, recovered_clip),
                     'recovery_psnr_blur': psnr(sharp, blur), 'recovery_psnr_sharp': psnr(sharp, recovered_clip),
                     'recovery_crop_xyxy': [x0, y0, x1, y1], 'sharpen_gaussian_size': 13, 'sharpen_gaussian_sigma': 2.0}


def main():
    first, m1 = convolution_section()
    camera, m2 = camera_sections()
    sharpen, m3 = sharpening_section()
    result = {'sections': [first, *camera, sharpen], 'measurements': {**m1, **m2, **m3},
              'source_files': ['src/filters.py', 'run_filters.py', 'tests/test_filters.py'],
              'validation': {'command': '.venv/bin/python -m unittest tests.test_filters -v',
                             'test_count': 7, 'note': 'Independent regression tests cover non-symmetric/even kernels, true kernel flip, zero boundaries, halo associativity, all-quadrant orientation, and unsharp identity.'}}
    (RESULTS / 'filters.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result['measurements'], indent=2))
    print(f'Wrote {len(result["sections"])} report sections to results/filters.json')


if __name__ == '__main__':
    main()
