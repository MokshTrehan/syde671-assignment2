"""Build the static assignment report from measured experiment results."""
from pathlib import Path
import html
import ast
import json
import shutil

ROOT = Path(__file__).resolve().parent
SITE = ROOT / 'site'
URL = 'https://mokshtrehan.github.io/syde671-assignment2/'

def esc(value):
    return html.escape(str(value), quote=True)

def figure(f):
    path = f['path']
    if path.startswith('site/'):
        path = path[5:]
    caption = f.get('caption', '')
    heading = f'<h3>{esc(f["heading"])}</h3>' if f.get('heading') else ''
    layout = f.get('layout', 'standard')
    return heading + f'<figure class="figure-{esc(layout)}"><a href="{esc(path)}" title="Open full-size figure"><img src="{esc(path)}" alt="{esc(caption)}" loading="lazy"></a><figcaption>{esc(caption)}</figcaption></figure>'

def table(t):
    head = ''.join(f'<th scope="col">{esc(x)}</th>' for x in t['columns'])
    rows = ''.join('<tr>' + ''.join(f'<td>{esc(x)}</td>' for x in row) + '</tr>' for row in t['rows'])
    return f'<div class="table-wrap"><table><caption>{esc(t.get("title", ""))}</caption><thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table></div>'

def section(s):
    headings = {int(i): title for i, title in s.get('paragraph_headings', {}).items()}
    content = ''.join((f'<h3 class="method-heading">{esc(headings[i])}</h3>' if i in headings else '')
                      + f'<p>{esc(p)}</p>' for i, p in enumerate(s.get('paragraphs', [])))
    content += ''.join(table(t) for t in s.get('tables', []))
    if s['id']=='part22':
        content += '''<div class="hybrid-viewer" data-hybrid-viewer><div class="viewer-controls"><label for="hybrid-choice">Choose a hybrid</label><select id="hybrid-choice"><option value="astronaut_chelsea">Astronaut + portrait cat</option><option value="derek_nutmeg">Derek + Nutmeg</option><option value="obama_tabby">Obama + tabby</option></select><div class="viewer-presets"><button type="button" data-view-size="512">Near view</button><button type="button" data-view-size="96">Far view</button></div></div><label for="hybrid-size">Display width: <output>512 px</output></label><input id="hybrid-size" type="range" min="48" max="512" value="512"><div class="hybrid-stage"><img src="images/hybrid_astronaut_chelsea_final.jpg" alt="Astronaut and portrait cat hybrid at an adjustable display size"></div><p>Reduce the display size or move farther away to emphasize the human face. Enlarge it to inspect the cat detail. The slider is a qualitative viewing aid; monitor size and viewing distance both affect the result.</p></div>'''
    supplements=[]
    for f in s.get('figures', []):
        if f.get('supplement'):
            supplements.append(f)
        else:
            content += figure(f)
    for code in s.get('code', []):
        shown=code['text']
        title=code.get('title', 'Implementation')
        if s['id']=='orientation':
            tree=ast.parse(shown)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef) and node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) and isinstance(node.body[0].value.value, str):
                    node.body.pop(0)
            shown=ast.unparse(tree)
        elif s['id']=='part21':
            title='Single-convolution sharpening core (each RGB channel)'
            shown='K = -alpha * G\nK[G.shape[0] // 2, G.shape[1] // 2] += 1 + alpha\nfor c in range(3):\n    sharp[..., c] = convolve2d(image[..., c], K, mode="same", boundary="symm")'
        content += f'<div class="code-block"><h3>{esc(title)}</h3><pre><code>{esc(shown)}</code></pre></div>'
    if supplements:
        ident=esc(s['id'])+'-extras'
        content += f'<details class="supplement" id="{ident}"><summary>Additional experiments and comparison figures ({len(supplements)})</summary>' + ''.join(figure(f) for f in supplements) + '</details>'
        content += f'<p class="supplement-note">Additional parameter comparisons are available in the <a href="{URL}#{ident}">online supplement</a>.</p>'
    return f'<section id="{esc(s["id"])}"><h2>{esc(s["title"])}</h2>{content}</section>'

def source_rows(sources):
    if isinstance(sources, dict):
        sources = sources.get('assets', sources.get('sources', []))
    if isinstance(sources, dict):
        sources = [dict(v, asset=k) if isinstance(v, dict) else {'asset': k, 'source': v} for k,v in sources.items()]
    rows=[]
    for s in sources:
        name=s.get('title',s.get('name',s.get('asset',s.get('file',s.get('path','Image')))))
        credit=s.get('attribution',s.get('credit',s.get('creator',s.get('author',''))))
        license_=s.get('license',s.get('rights',''))
        url=s.get('source_url',s.get('source_page',s.get('page_url',s.get('url',s.get('source','')))))
        if isinstance(url,list): url=url[0] if url else ''
        source = f'<a href="{esc(url)}">Source</a>' if str(url).startswith('http') else esc(s.get('source_label', 'Supplied photograph'))
        if s.get('license_url'):source+=f'<br><a href="{esc(s["license_url"])}">License</a>'
        if license_.startswith('Course-distributed'): license_ = 'Course sample; see note below.'
        elif license_.startswith('User-provided'): license_ = 'User-provided photograph.'
        rows.append(f'<tr><td>{esc(name)}</td><td>{esc(credit)}</td><td>{esc(license_)}</td><td>{source}</td></tr>')
    return ''.join(rows)

def main():
    SITE.mkdir(exist_ok=True)
    results=[json.loads((ROOT/'results'/p).read_text()) for p in ['filters.json','frequencies.json']]
    sections=[s for result in results for s in result['sections']]
    sources=json.loads((ROOT/'data/sources.json').read_text())
    config=json.loads((ROOT/'frequencies_config.json').read_text())
    active={'provided/selfie.jpg','provided/sharp.jpg','provided/taj.jpg','provided/cameraman.png'}
    def collect_paths(value):
        if isinstance(value, dict):
            for item in value.values(): collect_paths(item)
        elif isinstance(value, list):
            for item in value: collect_paths(item)
        elif isinstance(value, str) and value.startswith('data/'):
            active.add(value[5:])
    collect_paths(config)
    sources=dict(sources, assets=[a for a in sources['assets'] if a['file'] in active])
    nav=''.join(f'<a href="#{esc(s["id"])}">{esc(s["title"])}</a>' for s in sections)
    downloads='''<div class="downloads"><a href="downloads/syde671-assignment2-report.pdf">Report PDF</a><a href="downloads/syde671-assignment2-code.zip">Code + inputs</a><a href="downloads/measurements.json">Measurements</a></div>'''
    body=''.join(section(s) for s in sections)
    document=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="description" content="SYDE 671 Assignment 2: reproducible experiments in convolution, edges, sharpening, hybrid images and multiresolution blending."><title>SYDE 671 · Assignment 2 · Spatial Filtering and Multiresolution Blending</title><link rel="stylesheet" href="style.css"></head><body>
<header class="site-header"><a href="#top">SYDE 671 / Assignment 2</a><a href="#contents">Contents</a><a href="#reproduce">Code &amp; sources</a></header>
<main><section class="cover" id="top"><p class="eyebrow">SYDE 671 · Assignment 2 · Fall 2026</p><h1>Spatial Filtering and<br>Multiresolution Blending</h1><p class="byline">Moksh Trehan · Assignment 2 · Updated October 19, 2026</p><p class="abstract">This report examines convolution, image gradients, unsharp masking, hybrid images, and multiresolution blending. Numerical comparisons and visual results are used to evaluate the implementations.</p>{downloads}<div class="scope"><strong>Experiments</strong><p>NumPy convolution · Finite differences · Derivatives of Gaussians · HSV gradient orientations · Unsharp masking · Three hybrid images · Gaussian and Laplacian stacks · Oraple and two custom blends · Color comparisons</p></div><p class="online">Online report: <a href="{URL}">{URL}</a></p></section>
<section id="contents" class="contents"><h2>Contents</h2><nav>{nav}<a href="#reflection">Summary and observations</a><a href="#reproduce">Reproduction and image credits</a></nav></section>
{body}
<section id="reflection"><h2>Summary and observations</h2><p>The main lesson from these experiments is that spatial scale determines which image structures are preserved. Smoothing reduces fine variation before differentiation. Hybrid images combine the low-frequency structure of one source with high-frequency detail from another. Multiresolution blending uses narrow transitions for fine detail and wider transitions for brightness and color differences.</p><p>The numerical tests establish consistency of filtering and reconstruction. Visual comparisons also show that these operations cannot fully resolve differences in facial geometry or source texture. Image registration and parameter selection therefore remain important even when reconstruction errors are close to floating-point precision.</p></section>
<section id="reproduce"><h2>Reproduction and image credits</h2><p>The source package contains the input images, implementation, parameters, unit tests, recorded measurements, and report builder. The custom examples use the credited source photographs. The self-portrait and street photograph are from the supplied Assignment 1 images. The apple and orange inputs are the original PNGs from the supplied Part 2 image package. The Taj Mahal and Derek/Nutmeg photographs are also supplied course images. Source records, complete rights statements, and hashes are included in <a href="downloads/sources.json">the image manifest</a>.</p><pre><code>python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run_filters.py
python run_frequencies.py
python build_report.py
python -m http.server 8000 --directory site</code></pre><p>See README.md for image replacement, environment details, and PDF export. Numerical errors, recorded runtimes, and experiment settings are available in <a href="downloads/measurements.json">measurements.json</a>.</p>{downloads}<div class="table-wrap"><table class="credits"><thead><tr><th>Image</th><th>Credit</th><th>Rights / provenance</th><th>Link</th></tr></thead><tbody>{source_rows(sources)}</tbody></table></div><p class="rights-note">Course samples are supplied for this assignment; no general open license is asserted. Personal photographs are user-provided. Adapted figures containing the Moon photograph by Gregory H. Revera or the tabby photograph by Alvesgaspar remain under CC BY-SA 3.0, with full attribution recorded in the image manifest.</p>
<h3>References</h3><ol><li>A. Oliva, A. Torralba, and P. G. Schyns. <a href="https://doi.org/10.1145/1141911.1141919">Hybrid images</a>. ACM Transactions on Graphics 25(3), 527–532, 2006.</li><li>P. J. Burt and E. H. Adelson. <a href="https://doi.org/10.1145/245.247">A multiresolution spline with application to image mosaics</a>. ACM Transactions on Graphics 2(4), 217–236, 1983.</li><li>R. Szeliski. <a href="https://szeliski.org/Book/">Computer Vision: Algorithms and Applications, second edition</a>. Figure 3.42.</li><li>SYDE 671 Assignment 2, “Fun with Filters and Frequencies.” Required experiments and extensions follow the supplied handout, adapted from Berkeley CS180.</li></ol></section></main><footer>Moksh Trehan · SYDE 671 · Assignment 2 <a href="#top">Back to top ↑</a></footer><script src="report.js"></script></body></html>'''
    (SITE/'index.html').write_text(document)
    (SITE/'.nojekyll').write_text('')
    (SITE/'downloads').mkdir(exist_ok=True)
    (SITE/'downloads/measurements.json').write_text(json.dumps({'filters':results[0], 'frequencies':results[1]},indent=2))
    shutil.copy2(ROOT/'data/sources.json',SITE/'downloads/sources.json')
    print(f'Built {len(sections)} experiment sections: {SITE / "index.html"}')

if __name__=='__main__':main()
