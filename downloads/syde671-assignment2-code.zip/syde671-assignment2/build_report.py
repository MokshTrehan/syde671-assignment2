"""Build the static assignment report from measured experiment results."""
from pathlib import Path
import html
import json
import shutil

ROOT = Path(__file__).resolve().parent
SITE = ROOT / 'site'
URL = 'https://mokshtrehan.github.io/syde671-assignment2/'

def esc(value):
    return html.escape(str(value), quote=True)

def figure(f):
    path = f['path']
    if path.startswith('site/'):
        path = path[5:]
    caption = f.get('caption', '')
    return f'<figure><a href="{esc(path)}" title="Open full-size figure"><img src="{esc(path)}" alt="{esc(caption)}" loading="lazy"></a><figcaption>{esc(caption)}</figcaption></figure>'

def table(t):
    head = ''.join(f'<th scope="col">{esc(x)}</th>' for x in t['columns'])
    rows = ''.join('<tr>' + ''.join(f'<td>{esc(x)}</td>' for x in row) + '</tr>' for row in t['rows'])
    return f'<div class="table-wrap"><table><caption>{esc(t.get("title", ""))}</caption><thead><tr>{head}</tr></thead><tbody>{rows}</tbody></table></div>'

def section(s):
    content = ''.join(f'<p>{esc(p)}</p>' for p in s.get('paragraphs', []))
    content += ''.join(table(t) for t in s.get('tables', []))
    if s['id']=='part22':
        content += '''<div class="hybrid-viewer" data-hybrid-viewer><label for="hybrid-size">Explore viewing size: <output>350 px</output></label><input id="hybrid-size" type="range" min="48" max="512" value="350"><div class="hybrid-stage"><img src="images/hybrid_astronaut_chelsea_final.jpg" alt="Astronaut and portrait cat hybrid at an adjustable display size"></div><p>Reduce the image size or move farther from the screen to emphasize the human face. Increase it to inspect the cat's fine detail. Display size is a qualitative aid, not a calibrated viewing-distance experiment.</p></div>'''
    for f in s.get('figures', []):
        if s['id']=='part22':
            title=None
            for key,name in [('derek_nutmeg_alignment','Supplied pair: Derek + Nutmeg'),('astronaut_chelsea_alignment','Custom pair 1: Astronaut + portrait cat'),('obama_tabby_alignment','Custom pair 2: Obama + tabby'),('earth_moon_alignment','Additional experiment: Earth + Moon'),('fourier_process','Frequency analysis: Astronaut + portrait cat')]:
                if key in f['path']:title=name
            if title:content+=f'<h3>{esc(title)}</h3>'
        content += figure(f)
    for code in s.get('code', []):
        content += f'<div class="code-block"><h3>{esc(code.get("title", "Implementation"))}</h3><pre><code>{esc(code["text"])}</code></pre></div>'
    return f'<section id="{esc(s["id"])}"><h2>{esc(s["title"])}</h2>{content}</section>'

def source_rows(sources):
    if isinstance(sources, dict):
        sources = sources.get('assets', sources.get('sources', []))
    if isinstance(sources, dict):
        sources = [dict(v, asset=k) if isinstance(v, dict) else {'asset': k, 'source': v} for k,v in sources.items()]
    rows=[]
    for s in sources:
        name=s.get('title',s.get('name',s.get('asset',s.get('file',s.get('path','Image')))))
        credit=s.get('attribution',s.get('credit',s.get('creator',s.get('author',''))))
        license_=s.get('license',s.get('rights',''))
        url=s.get('source_url',s.get('source_page',s.get('page_url',s.get('url',s.get('source','')))))
        if isinstance(url,list): url=url[0] if url else ''
        source = f'<a href="{esc(url)}">Source</a>' if str(url).startswith('http') else 'Supplied photograph'
        if s.get('license_url'):source+=f'<br><a href="{esc(s["license_url"])}">License</a>'
        if s.get('derivative_credit'):license_ += ' '+s['derivative_credit']
        rows.append(f'<tr><td>{esc(name)}</td><td>{esc(credit)}</td><td>{esc(license_)}</td><td>{source}</td></tr>')
    return ''.join(rows)

def main():
    SITE.mkdir(exist_ok=True)
    results=[json.loads((ROOT/'results'/p).read_text()) for p in ['filters.json','frequencies.json']]
    sections=[s for result in results for s in result['sections']]
    sources=json.loads((ROOT/'data/sources.json').read_text())
    nav=''.join(f'<a href="#{esc(s["id"])}">{esc(s["title"])}</a>' for s in sections)
    downloads='''<div class="downloads"><a href="downloads/syde671-assignment2-report.pdf">Report PDF</a><a href="downloads/syde671-assignment2-code.zip">Code + inputs</a><a href="downloads/measurements.json">Measurements</a></div>'''
    body=''.join(section(s) for s in sections)
    document=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="description" content="SYDE 671 Assignment 2: reproducible experiments in convolution, edges, sharpening, hybrid images and multiresolution blending."><title>SYDE 671 · Assignment 2 · Filters and Frequencies</title><link rel="stylesheet" href="style.css"></head><body>
<header class="site-header"><a href="#top">SYDE 671 / Assignment 2</a><a href="#contents">Contents</a><a href="#reproduce">Code &amp; sources</a></header>
<main><section class="cover" id="top"><p class="eyebrow">Computational photography · Fall 2026</p><h1>Fun with Filters<br>and Frequencies</h1><p class="byline">Moksh Trehan · Assignment 2 · October 2, 2026</p><p class="abstract">Convolution isolates edges, separates image detail by spatial scale, and combines photographs in ways that change with viewing distance. This report follows those connections through explicit implementations, numerical checks, and visual experiments.</p>{downloads}<div class="scope"><strong>Included</strong><p>NumPy convolution · Finite differences · Derivatives of Gaussians · HSV gradient orientations · Unsharp masking · Three hybrid images · Gaussian and Laplacian stacks · Oraple and two custom blends · Mandatory color experiments</p></div><p class="online">Online report: <a href="{URL}">{URL}</a></p></section>
<section id="contents" class="contents"><h2>Contents</h2><nav>{nav}<a href="#reflection">What these experiments show</a><a href="#reproduce">Reproduction and image credits</a></nav></section>
{body}
<section id="reflection"><h2>What these experiments show</h2><p>The main lesson from these experiments is that image structure depends on the scale at which it is examined. A derivative exposes abrupt changes but also amplifies noise. Smoothing first selects a broader scale for those changes. In a hybrid, large structures and fine edges can describe different subjects. In a blend, fine detail needs a narrow transition while broad illumination needs a wider one.</p><p>Boundary conditions and display choices also matter. Padding can introduce artificial border edges, high-pass images contain negative values, and sharpening can exceed the display range. Numerical checks therefore use floating-point arrays before clipping; figure captions state how signed quantities are displayed. Visual quality is assessed on the actual rendered results, with limitations recorded alongside the chosen parameters.</p></section>
<section id="reproduce"><h2>Reproduction and image credits</h2><p>The source package includes the input images, explicit algorithms, saved parameters, meaningful numerical tests, measured results, and report builder. The custom examples use sourced photographs that can be retained as the final examples or replaced. The self-portrait is from the supplied Assignment 1 photographs. Source records and hashes are included in <a href="downloads/sources.json">the image manifest</a>.</p><pre><code>python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run_filters.py
python run_frequencies.py
python build_report.py
python -m http.server 8000 --directory site</code></pre><p>See README.md for image replacement, environment details, and PDF export. Measured errors, timings, and experiment settings are available in <a href="downloads/measurements.json">measurements.json</a>.</p>{downloads}<div class="table-wrap"><table class="credits"><thead><tr><th>Image</th><th>Credit</th><th>Rights / provenance</th><th>Link</th></tr></thead><tbody>{source_rows(sources)}</tbody></table></div>
<h3>References</h3><ol><li>A. Oliva, A. Torralba, and P. G. Schyns. <a href="https://doi.org/10.1145/1141911.1141919">Hybrid images</a>. ACM Transactions on Graphics 25(3), 527–532, 2006.</li><li>P. J. Burt and E. H. Adelson. <a href="https://doi.org/10.1145/245.247">A multiresolution spline with application to image mosaics</a>. ACM Transactions on Graphics 2(4), 217–236, 1983.</li><li>R. Szeliski. <a href="https://szeliski.org/Book/">Computer Vision: Algorithms and Applications, second edition</a>. Figure 3.42.</li><li>SYDE 671 Assignment 2, “Fun with Filters and Frequencies.” Required experiments and extensions follow the supplied handout, adapted from Berkeley CS180.</li></ol></section></main><footer>Moksh Trehan · SYDE 671 · Assignment 2 <a href="#top">Back to top ↑</a></footer><script src="report.js"></script></body></html>'''
    (SITE/'index.html').write_text(document)
    (SITE/'.nojekyll').write_text('')
    (SITE/'downloads').mkdir(exist_ok=True)
    (SITE/'downloads/measurements.json').write_text(json.dumps({'filters':results[0], 'frequencies':results[1]},indent=2))
    shutil.copy2(ROOT/'data/sources.json',SITE/'downloads/sources.json')
    print(f'Built {len(sections)} experiment sections: {SITE / "index.html"}')

if __name__=='__main__':main()
