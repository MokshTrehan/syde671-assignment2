"""Compose the report as figure-led topic pages, using recorded experiment data."""
from pathlib import Path
import ast
import html
import json
import shutil
from src.filter_layout import filter_pages
from src.frequency_layout import frequency_pages
from src.audit_layout import add_audit_pages

ROOT = Path(__file__).resolve().parent
SITE = ROOT / 'site'
URL = 'https://mokshtrehan.github.io/syde671-assignment2/'


def esc(value):
    return html.escape(str(value), quote=True)


def figure(f, *, caption=None, height=None):
    path = f['path'].removeprefix('site/')
    caption = f.get('caption', '') if caption is None else caption
    klass = 'figure-tall' if height else 'figure-standard'
    size = f' style="--figure-height:{float(height):g}mm"' if height else ''
    return (f'<figure class="{klass}"{size}><a href="{esc(path)}" title="Open full-size figure">'
            f'<img src="{esc(path)}" alt="{esc(f.get("alt", caption))}" loading="lazy"></a>'
            f'<figcaption>{esc(caption)}</figcaption></figure>')


def table(t, *, rows=None, title=None):
    selected = t['rows'] if rows is None else [t['rows'][i] for i in rows]
    head = ''.join(f'<th scope="col">{esc(x)}</th>' for x in t['columns'])
    body = ''.join('<tr>' + ''.join(f'<td>{esc(x)}</td>' for x in row) + '</tr>' for row in selected)
    title = t.get('title', '') if title is None else title
    klass = 'table-wrap keep-together' if len(selected) <= 6 else 'table-wrap'
    return f'<div class="{klass}"><table><caption>{esc(title)}</caption><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def viewer():
    return '''<div class="hybrid-viewer" data-hybrid-viewer><div class="viewer-controls"><label for="hybrid-choice">Choose a hybrid</label><select id="hybrid-choice"><option value="astronaut_chelsea">Astronaut + portrait cat</option><option value="derek_nutmeg">Derek + Nutmeg</option><option value="obama_tabby">Obama + tabby</option></select><div class="viewer-presets"><button type="button" data-view-size="512">Near view</button><button type="button" data-view-size="64">Far view</button></div></div><label for="hybrid-size">Display width: <output>512 px</output></label><input id="hybrid-size" type="range" min="48" max="512" value="512"><div class="hybrid-stage"><img src="images/hybrid_astronaut_chelsea_final.jpg" alt="Astronaut and portrait cat hybrid at an adjustable display size"></div><p>Reduce the display width or move farther away to emphasize the human face. Enlarge the image to inspect the cat detail. This is a qualitative viewing aid; screen size and viewing distance both affect the result.</p></div>'''


def render_block(block, sections):
    kind = block['type']
    if kind in {'p', 'note', 'heading'}:
        tag = 'h3' if kind == 'heading' else 'p'
        klass = ' class="note"' if kind == 'note' else ''
        return f'<{tag}{klass}>{esc(block["text"])}</{tag}>'
    if kind == 'equation':
        return f'<div class="equation"><div class="equation-label">{esc(block["label"])}</div><div>{block["html"]}</div></div>'
    if kind == 'figure':
        return figure(sections[block['section']]['figures'][block['index']],
                      caption=block.get('caption'), height=block.get('height'))
    if kind == 'table':
        return table(sections[block['section']]['tables'][block['index']],
                     rows=block.get('rows'), title=block.get('title'))
    if kind == 'viewer':
        return viewer()
    if kind == 'code':
        record = sections[block['section']]['code'][block['index']]
        source = record['text']
        # Docstrings repeat the surrounding prose; executable lines remain complete.
        tree = ast.parse(source)
        for node in ast.walk(tree):
            if (isinstance(node, ast.FunctionDef) and node.body
                    and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                node.body.pop(0)
        source = ast.unparse(tree)
        return f'<div class="code-block"><h3>{esc(record.get("title", "Implementation"))}</h3><pre><code>{esc(source)}</code></pre></div>'
    if kind == 'supplements':
        section = sections[block['section']]
        figures = [f for i, f in enumerate(section.get('figures', []))
                   if f.get('supplement') and i not in block.get('exclude', [])]
        if not figures:
            return ''
        ident = section['id'] + '-extras'
        return (f'<details class="supplement" id="{esc(ident)}"><summary>Additional experiments and comparison figures ({len(figures)})</summary>'
                + ''.join(figure(f) for f in figures) + '</details>'
                + f'<p class="supplement-note">Additional parameter trials and diagnostic figures are available in the <a href="{URL}#{ident}">online supplement</a>.</p>')
    if kind == 'html':
        return block['html']
    raise ValueError(f'Unknown block type: {kind}')


def render_page(page, sections):
    klass = 'report-section' + (' code-page' if page.get('code') else '')
    kicker = f'<p class="eyebrow">{esc(page["kicker"])}</p>' if page.get('kicker') else ''
    return (f'<section class="{klass}" id="{esc(page["id"])}">{kicker}'
            f'<div class="section-title"><span class="section-number">{esc(page["number"])}</span>'
            f'<h2>{esc(page["title"])}</h2></div>'
            + ''.join(render_block(b, sections) for b in page['blocks']) + '</section>')


def appendix_pages():
    def p(text): return dict(type='p', text=text)
    def note(text): return dict(type='note', text=text)
    def code(section, index): return dict(type='code', section=section, index=index)
    def eq(label, html): return dict(type='equation', label=label, html=html)
    def page(ident, number, title, blocks):
        return dict(id=ident, number=number, title=title, kicker='Implementation appendix', code=True, blocks=blocks)
    return [
        page('appendix-a', 'A', 'Convolution implementation', [
            p('The shared helper validates the inputs, reverses the kernel, and pads the image with zeros. Both implementations return the same image shape and use the same padding convention.'),
            code('part11', 0), code('part11', 1),
        ]),
        page('appendix-b', 'B', 'Vectorization and image gradients', [
            p('The two-loop version accumulates a complete shifted image slice for each kernel element. This changes the Python loop structure without changing the convolution sum.'),
            code('part11', 2), code('part12', 0),
            dict(type='heading', text='Cameraman input preparation'),
            p('The supplied image has a thin white border. The crop (1, 7, 535, 541), in (left, top, right, bottom) coordinates with the right and bottom bounds excluded, removes it. The square crop is resized to 256 × 256 pixels with Lanczos interpolation.'),
            note('Calculations use floating-point intensities in [0, 1] with no further normalization before thresholding. The seven-pixel evaluation margin covers the largest Gaussian-derivative support used in Part 1.'),
        ]),
        page('appendix-c', 'C', 'Orientation without angle routines', [
            p('For nonzero gradients, the ratio below lies in [0, 1]. When it exceeds √2−1, range reduction bounds the series argument by √2−1. Eighteen terms approximate arctangent; component swaps and signs recover the quadrant.'),
            eq('Range reduction', 'r = min(|g<sub>y</sub>|, |g<sub>x</sub>|) / max(|g<sub>y</sub>|, |g<sub>x</sub>|)<br>atan(r) = π/4 + atan((r − 1)/(r + 1)) &nbsp; for r &gt; √2 − 1<br>atan(z) ≈ z − z<sup>3</sup>/3 + z<sup>5</sup>/5 − …'),
            code('orientation', 0),
            note('A zero gradient is assigned orientation zero and displayed black. NumPy atan2 is used only as an independent validation reference.'),
        ]),
        page('appendix-d', 'D', 'Gaussian derivatives and sharpening', [
            p('Full convolution retains the complete Gaussian-derivative support. The sharpening kernel combines the identity and Gaussian terms into one image convolution.'),
            code('part13', 0), code('part21', 0),
            note('The sharpening kernel is convolved with each RGB channel using “same” output and symmetric boundary extension. All intermediate arrays use float64; clipping is deferred until display export.'),
        ]),
        page('appendix-e', 'E', 'Hybrids and multiresolution stacks', [
            p('The hybrid combines a low-pass source with a scaled high-pass source. The stack construction keeps every level at the original resolution; the last Gaussian level is retained as the coarse residual.'),
            code('part22', 0), code('part23', 0),
            dict(type='heading', text='Numerical representation'),
            p('Hybrid filtering uses reflected boundaries and signed float64 values. Intermediate bands are neither clipped nor contrast-normalized. Display exports clamp to [0, 1] and quantize to 8 bits; the settings table counts clipped scalar channel values. The signed high-pass display is shifted by 0.5 and includes the synthesis gain, without additional display amplification.'),
            note('These excerpts show the filtering and reconstruction steps. The source ZIP contains the complete alignment, masking, validation, and figure-generation code.'),
        ]),
    ]
def source_rows(sources):
    if isinstance(sources, dict):
        sources = sources.get('assets', sources.get('sources', []))
    if isinstance(sources, dict):
        sources = [dict(v, asset=k) if isinstance(v, dict) else {'asset': k, 'source': v} for k,v in sources.items()]
    rows=[]
    for s in sources:
        name=s.get('title',s.get('name',s.get('asset',s.get('file',s.get('path','Image')))))
        credit=s.get('attribution',s.get('credit',s.get('creator',s.get('author',''))))
        license_=s.get('license',s.get('rights',''))
        url=s.get('source_url',s.get('source_page',s.get('page_url',s.get('url',s.get('source','')))))
        if isinstance(url,list): url=url[0] if url else ''
        source = f'<a href="{esc(url)}">Source</a>' if str(url).startswith('http') else esc(s.get('source_label', 'Supplied photograph'))
        if s.get('license_url'):source+=f'<br><a href="{esc(s["license_url"])}">License</a>'
        if license_.startswith('Course-distributed'): license_ = 'Course sample; see note below.'
        elif license_.startswith('User-provided'): license_ = 'User-provided photograph.'
        rows.append(f'<tr><td>{esc(name)}</td><td>{esc(credit)}</td><td>{esc(license_)}</td><td>{source}</td></tr>')
    return ''.join(rows)


def main():
    SITE.mkdir(exist_ok=True)
    results = [json.loads((ROOT/'results'/p).read_text()) for p in ['filters.json', 'frequencies.json']]
    section_list = [s for result in results for s in result['sections']]
    sections = {s['id']: s for s in section_list}
    audit = json.loads((ROOT/'results/audit.json').read_text())
    sources = json.loads((ROOT/'data/sources.json').read_text())
    config = json.loads((ROOT/'frequencies_config.json').read_text())
    active = {'provided/selfie.jpg', 'provided/sharp.jpg', 'provided/taj.jpg', 'provided/cameraman.png'}

    def collect_paths(value):
        if isinstance(value, dict):
            for item in value.values(): collect_paths(item)
        elif isinstance(value, list):
            for item in value: collect_paths(item)
        elif isinstance(value, str) and value.startswith('data/'):
            active.add(value[5:])

    collect_paths(config)
    assets = [a for a in sources['assets'] if a['file'] in active]
    downloads = '''<div class="downloads"><a href="downloads/syde671-assignment2-report.pdf">Report PDF</a><a href="downloads/syde671-assignment2-code.zip">Code + inputs</a><a href="downloads/measurements.json">Measurements</a></div>'''
    pages = filter_pages(sections) + add_audit_pages(frequency_pages(sections), sections, audit) + appendix_pages()
    referenced = [(b['section'], b['index']) for page in pages for b in page['blocks'] if b['type'] == 'figure']
    for page in pages:
        for block in page['blocks']:
            if block['type'] == 'supplements':
                block['exclude'] = [i for s, i in referenced if s == block['section']]
    required = [(s['id'], i) for s in sections.values() for i, f in enumerate(s.get('figures', [])) if not f.get('supplement')]
    for key in required:
        if referenced.count(key) != 1:
            raise ValueError(f'Required figure {key} must appear once, got {referenced.count(key)}')
    body = ''.join(render_page(page, sections) for page in pages)
    contents = '''<nav id="contents" aria-label="Report contents"><h2>Contents</h2><ol>
<li><strong>Part One · Filters</strong><ol><li><a href="#part11">Convolutions from scratch</a></li><li><a href="#part12">Finite differences and thresholding</a></li><li><a href="#part13">Derivatives of Gaussians</a></li><li><a href="#orientation">Gradient orientations</a></li></ol></li>
<li><strong>Part Two · Frequencies</strong><ol><li><a href="#part21">Image sharpening</a></li><li><a href="#part22">Hybrid images</a></li><li><a href="#part23">Gaussian and Laplacian stacks</a></li><li><a href="#part24">Multiresolution blending</a></li></ol></li></ol>
<p><a href="#appendix-a">Implementation appendix</a> · <a href="#reproduce">Reproduction</a> · <a href="#credits">Image credits</a></p></nav>'''
    ending = dict(id='reproduce', number='R', title='Reproduction and observations', kicker='Supporting information', blocks=[
        dict(type='html', html='<h3 id="reflection">Observations</h3>'),
        dict(type='p', text='Spatial scale determines which structures are preserved. Smoothing suppresses fine variation before differentiation; hybrid images separate broad shape from fine detail; multiresolution blending uses broader transitions for brightness and color than for texture. Numerical agreement checks confirm the implementations, but alignment and source geometry still limit the visual results.'),
        dict(type='heading', text='Reproduce the experiments'),
        dict(type='p', text='The source ZIP includes the original inputs, parameters, implementations, tests, measurements, and report builder. The following commands regenerate the experiments and webpage. README.md describes PDF export and image replacement.'),
        dict(type='html', html='''<pre><code>python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run_filters.py
python run_frequencies.py
python build_report.py
python -m http.server 8000 --directory site</code></pre>'''),
        dict(type='html', html=downloads),
        dict(type='html', html='''<p class="note">Submit the report PDF and code + inputs ZIP together, and include the website URL. <a href="downloads/measurements.json">Measurements</a> include the comparison diagnostics and level trace; <a href="downloads/sources.json">the image manifest</a> records source URLs, rights, dimensions and hashes.</p>'''),
        dict(type='heading', text='References'),
        dict(type='html', html='''<ol class="references"><li>A. Oliva, A. Torralba, and P. G. Schyns. <a href="https://doi.org/10.1145/1141911.1141919">Hybrid images</a>. ACM Transactions on Graphics 25(3), 527–532, 2006.</li><li>P. J. Burt and E. H. Adelson. <a href="https://doi.org/10.1145/245.247">A multiresolution spline with application to image mosaics</a>. ACM Transactions on Graphics 2(4), 217–236, 1983.</li><li>R. Szeliski. <a href="https://szeliski.org/Book/">Computer Vision: Algorithms and Applications, second edition</a>. Figure 3.42.</li><li>SYDE 671 Assignment 2, “Fun with Filters and Frequencies.” The required experiments follow the supplied handout, adapted from Berkeley CS180.</li></ol>'''),
    ])
    body += render_page(ending, sections)
    # Keep the credits readable rather than compressing seventeen entries onto one page.
    for i, chunk in enumerate([assets[:9], assets[9:]]):
        credit_table = ('<div class="table-wrap"><table class="credits"><thead><tr><th>Image</th><th>Credit</th><th>Rights / provenance</th><th>Link</th></tr></thead><tbody>'
                        + source_rows(chunk) + '</tbody></table></div>')
        intro = ('The self portrait and street photograph are the supplied Assignment 1 images. The Taj Mahal, Derek/Nutmeg pair, and original apple and orange PNGs are supplied course samples. The custom examples use the credited source photographs.' if i == 0 else
                 'The following source records complete the input-image manifest. Adapted figures retain the applicable attribution and license information.')
        note = ('Course samples are supplied for this assignment; no general open license is asserted. Personal photographs are user-provided.' if i == 0 else
                'Adapted figures containing the Moon photograph by Gregory H. Revera or the tabby photograph by Alvesgaspar remain under CC BY-SA 3.0. Complete attribution and modification records accompany the code and image manifest.')
        body += render_page(dict(id='credits' if i == 0 else 'credits-continued', number='S', title='Image credits' if i == 0 else 'Image credits, continued', kicker='Sources and attribution', blocks=[dict(type='p', text=intro), dict(type='html', html=credit_table), dict(type='note', text=note)]), sections)

    document = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="description" content="SYDE 671 Assignment 2: convolution, edges, sharpening, hybrid images and multiresolution blending."><title>SYDE 671 · Assignment 2 · Spatial Filtering and Multiresolution Blending</title><link rel="stylesheet" href="style.css"></head><body>
<header class="site-header"><a href="#top">SYDE 671 / Assignment 2</a><a href="#contents">Contents</a><a href="#reproduce">Code &amp; sources</a></header>
<main><section class="assignment-cover" id="top"><p class="eyebrow">SYDE 671 · Assignment 2 · Fall 2026</p><h1>Spatial Filtering and<br>Multiresolution Blending</h1><p class="byline">Moksh Trehan · October 19, 2026</p><p class="abstract">Experiments in convolution, image gradients, sharpening, hybrid images, and multiresolution blending. Each section presents the method, visual results, and observations.</p>{contents}{downloads}<p class="online">Online report: <a href="{URL}">{URL}</a></p></section>
{body}</main><footer>Moksh Trehan · SYDE 671 · Assignment 2 <a href="#top">Back to top ↑</a></footer><script src="report.js"></script></body></html>'''
    (SITE/'index.html').write_text(document)
    (SITE/'.nojekyll').write_text('')
    (SITE/'downloads').mkdir(exist_ok=True)
    (SITE/'downloads/measurements.json').write_text(json.dumps({'filters': results[0], 'frequencies': results[1], 'audit': audit}, indent=2))
    shutil.copy2(ROOT/'data/sources.json', SITE/'downloads/sources.json')
    print(f'Built {len(pages) + 4} composed pages: {SITE / "index.html"}')


if __name__ == '__main__':
    main()
