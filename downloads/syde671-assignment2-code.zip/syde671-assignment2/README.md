# SYDE 671 - Assignment 2

Reproducible experiments for **Spatial Filtering and Multiresolution Blending**: explicit NumPy convolution, finite differences, Gaussian derivatives, gradient orientations, sharpening, hybrid images, and full-resolution multiresolution blending.

## Reproduce the report

Python 3.12 was used for the recorded run. From this directory:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run_filters.py
python run_frequencies.py
python build_report.py
python -m http.server 8000 --directory site
```

On Windows activate `.venv\Scripts\activate` instead. Open `http://localhost:8000`. The complete submission ZIP includes a ready-to-read report at `webpage/index.html`, which works without installing Python. The code ZIP contains source and inputs; the commands above regenerate its `site/index.html` and figures. Experiments run entirely on the CPU. No remote service or model is required to regenerate the image-processing results.

## Files

- `src/filters.py`: both explicit convolution implementations, gradient magnitude, quadrant-correct orientation without built-in angle functions, and unsharp kernel.
- `run_filters.py`: Parts 1.1-1.3, mandatory orientation extension, and Part 2.1; exports figures and actual measurements.
- `src/frequencies.py`: explicit Gaussian and Laplacian stacks, landmark alignment, hybrid images, and mask-weighted reconstruction.
- `frequencies_config.json`: source paths, original-image landmarks, sigmas, gains, color choices, and object/mask coordinates.
- `run_frequencies.py`: orchestrates the hybrid, stack, and custom-blend experiments.
- `src/hybrid_report.py` and `src/blend_report.py`: reproducible image experiments and measured report content.
- `src/report_figures.py`: consistently scaled, labeled figure exports.
- `tests/`: deterministic numerical checks for convolution, quadrants, derivative equivalence, reconstruction, alignment, and masks. SciPy/NumPy angle functions are allowed only as independent test references for the custom implementations.
- `data/sources.json`: source URLs, rights, credits, original dimensions and SHA-256 hashes.
- `data/acquire_sources.py`: verify the included original assets and recover missing downloadable originals.
- `results/`: measured parameters, numerical checks and report content.
- `build_report.py`: render the webpage from recorded experiment results.
- `site/`: self-contained static webpage, images and downloads.
- `export_and_check.mjs`: headless-browser PDF export, image/anchor checks and mobile-layout checks.
- `package_submission.py`: code+input ZIP and complete hand-in ZIP.

## Replace the custom examples

The downloaded examples are usable final inputs, not empty placeholders. Three required hybrid results use Derek/Nutmeg, astronaut/portrait cat, and Obama/tabby. Custom blends combine a tabby face with a portrait cat using an irregular polygon, and Earth with the Moon using a curved seam. Keep the examples or replace the sources in `frequencies_config.json`.

For each new hybrid, set both source paths and two corresponding landmarks in **original image (x,y) pixels** (left and right eye centers work well). By default both images map to the same target points by uniform scale, rotation and translation. Optional `low_target_points` and `high_target_points` record deliberate per-source geometry refinements while preserving the true original landmarks. Derek and the astronaut use a 0.85 human-image scale about the common eye midpoint and an 8-pixel upward shift, composed into one similarity warp; this reduces the separation between the human mouth and cat muzzle. The two-by-two report controls separate geometry and filtering changes. Tune `sigma_low`, `sigma_high`, and `gain` after alignment. Color toggles choose whether each component uses RGB or luminance. The blur standard deviations are measured in pixels on the aligned output canvas.

For a custom blend, update the two input paths, registration settings, output shape, and polygon vertices or curved-seam parameters. The cat example uses two corresponding eye landmarks and a similarity transform. The planet example fits the largest external contour above luminance 0.04 with an ellipse, then maps it affinely to a common circle; the small differential axis scaling and fitted geometry are recorded in the results. Thresholding measures registration geometry only, while the warp samples the complete original RGB photographs. Both source photographs are registered independently onto a common canvas. A binary selection defines the blend. Both custom blends set `mask_sigma=8` to smooth the finest selection weights before forming the Gaussian mask stack; the canonical oraple retains a binary finest mask. The cat uses a 24-vertex contour following the crown, temples, cheeks and chin, keeping the core facial features inside the selection. This softens local fur or limb transitions without blurring the source images. Mask-smoothing trials and the nominal equivalent Gaussian widths are recorded in the report. Each feather baseline uses the exact coarsest multiscale mask; the figure compares the same registered inputs with a hard cut, single-scale feathering, and multiresolution blending. Rerun both the experiment and report scripts after any changes. Update `data/sources.json` with the new source credits.

The supplied personal portrait and street photograph are reused from Assignment 1. Input originals are preserved at their original size; computation uses documented medium-resolution arrays. Signed floating-point bands are not clipped before analysis or reconstruction. Display exports alone use the stated normalization and clipping.

## PDF and packaging

The PDF is a print export of the same webpage, with all required figure panels and code snippets visible. Additional diagnostic trials are expandable on the webpage and linked from the PDF. For a manual export use the browser's Print / Save as PDF with background graphics enabled. For the automated export install Node.js and Playwright, start the local server above, then:

```sh
npm install --no-save playwright
npx playwright install chromium
node export_and_check.mjs http://localhost:8000
python package_submission.py
```

Set `CHROME_PATH` to use a specific Chromium/Chrome executable. Set `PLAYWRIGHT_MODULE` only if Playwright is installed outside the usual Node module path. Automated export uses `qa/` for review screenshots and diagnostics. `output/` contains the final PDF and ZIP files.

## Supplied course image package

The October 19 update uses `data/provided/burt_apple.png` and `burt_orange.png` from the supplied Part 2 image ZIP for the apple/orange stacks and blend. Both originals are 740x530 pixels and are preserved unchanged; processing preserves their aspect ratio. The package's Taj Mahal image and all hybrid ZIP files exactly match the earlier input originals. The hybrid results use the revised, per-pair cutoff and gain settings in the saved configuration. Earlier 300x300 apple/orange JPEGs are retained as unused alternate inputs. Course-only originals are bundled in the code ZIP and cannot be restored from a public download URL.

## References and rights

Methods follow the assignment handout and the cited Oliva-Torralba-Schyns (2006), Burt-Adelson (1983), and Szeliski (second edition) references. Image-specific credits and links are printed in the report. The Moon photograph is by Gregory H. Revera and the tabby photograph is by Joaquim Alves Gaspar (Alvesgaspar), both CC BY-SA 3.0; their modified figures are distributed under that same license, as recorded in the manifest. No blanket license is asserted over the course samples or user-supplied photographs.

Timings are measured on the recorded local machine and depend on hardware and image size. Perceptual conclusions are visual observations, not results of a human-subject study. Correct reconstruction and agreement tests establish implementation consistency; they do not alone prove perceptual quality.
