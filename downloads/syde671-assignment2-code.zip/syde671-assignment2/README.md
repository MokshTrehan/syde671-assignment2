# SYDE 671 - Assignment 2

Reproducible experiments for **Spatial Filtering and Multiresolution Blending**: explicit NumPy convolution, finite differences, Gaussian derivatives, gradient orientations, sharpening, hybrid images, and full-resolution multiresolution blending.

## Reproduce the report

Python 3.12 was used for the recorded run. From this directory:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run_filters.py
python run_frequencies.py
python build_report.py
python -m http.server 8000 --directory site
```

On Windows activate `.venv\Scripts\activate` instead. Open `http://localhost:8000`. The complete submission ZIP includes a ready-to-read report at `webpage/index.html`, which works without installing Python. The code ZIP contains source and inputs; the commands above regenerate its `site/index.html` and figures. Experiments run entirely on the CPU. No remote service or model is required to regenerate the image-processing results.

## Files

- `src/filters.py`: both explicit convolution implementations, gradient magnitude, quadrant-correct orientation without built-in angle functions, and unsharp kernel.
- `run_filters.py`: Parts 1.1-1.3, mandatory orientation extension, and Part 2.1; exports figures and actual measurements.
- `src/frequencies.py`: explicit Gaussian and Laplacian stacks, landmark alignment, hybrid images, and mask-weighted reconstruction.
- `frequencies_config.json`: source paths, original-image landmarks, sigmas, gains, color choices, and object/mask coordinates.
- `run_frequencies.py`: orchestrates the hybrid, stack, and custom-blend experiments, then regenerates the diagnostic audit.
- `run_audit.py` and `src/audit_metrics.py`: reproduce the matched hybrid controls, all-example comparisons, and complete six-level reconstruction trace in `results/audit.json`. Run `python run_audit.py` separately to refresh these diagnostics from the saved configuration.
- `src/hybrid_report.py` and `src/blend_report.py`: reproducible image experiments and measured report content.
- `src/report_figures.py`: consistently scaled, labeled figure exports.
- `tests/`: deterministic numerical checks for convolution, quadrants, derivative equivalence, reconstruction, alignment, and masks. SciPy/NumPy angle functions are allowed only as independent test references for the custom implementations.
- `data/sources.json`: source URLs, rights, credits, original dimensions and SHA-256 hashes.
- `data/acquire_sources.py`: verify the included original assets and recover missing downloadable originals.
- `results/`: measured parameters, numerical checks and report content.
- `build_report.py`: compose the webpage from recorded experiment results.
- `src/filter_layout.py`, `src/frequency_layout.py`, and `src/audit_layout.py`: figure-led page order, report prose, and tables drawn from the measured diagnostics, with long implementations in a separate appendix.
- `site/`: self-contained static webpage, images and downloads.
- `export_and_check.mjs`: headless-browser PDF export, image/anchor checks and mobile-layout checks.
- `package_submission.py`: code+input ZIP and complete hand-in ZIP.

## Replace the custom examples

The three primary hybrids are the required Derek/Nutmeg pair, Obama/Biden, and Monroe/Einstein. Obama/Biden uses similar near-frontal smiling portraits. Monroe/Einstein implements the classic pairing with separately sourced originals; a softly lit Monroe photograph reduces strong mouth and neck shadows. The favorite custom blend places an alpine lake in a sandstone arch opening; the second joins Earth and Moon with a curved seam. An additional Earth/Moon hybrid is discussed as a limitation study, not counted as a successful primary example. Original source credits and hashes are recorded in `data/sources.json`.

For each hybrid, set both source paths and two corresponding landmarks in **original image (x,y) pixels**. A similarity transform maps both custom portraits to common eye targets, using uniform scale, rotation and translation. Obama/Biden uses targets (181,205) and (331,205); Monroe/Einstein uses (191,215) and (321,215). Einstein is horizontally mirrored before alignment: x becomes 4516−x and the two eye correspondences swap. His reflected left-to-right points are (1716,1897) and (2347,1896). The reflection and similarity are composed into a single warp of the unchanged original. A controlled supplementary figure holds eye targets and filter settings fixed to compare both orientations. These custom pairs use no relative face scaling or local deformation.

The required Derek/Nutmeg pair uses common eye targets (186,235) and (326,235), preserving a more coherent cat eye and cheek region. A two-by-two control tests a reduced-human alternative against common-eye alignment using both reference (6,1.5,2.5) and selected (10,5,2) filter settings. In the alternative, Derek is uniformly reduced by 0.70 about the common eye midpoint and moved upward 12 pixels, giving eye targets (207,223) and (305,223). The cat framing stays fixed. This is a controlled alternative on the final framing, not an exact reproduction of an earlier crop. The final synthesis uses no separate human reduction. The wider high-pass band and greater gain make Nutmeg’s eyes, muzzle and fur more prominent. Its 64-pixel view remains cat-dominant or mixed; a 32-pixel endpoint makes Derek clearer. The former 8/3/gain 1.25 settings are retained in the cutoff trials. Broad human hair and neck shading remains.

Final (low sigma, high sigma, gain) settings in output pixels are (10,5,2) for Derek/Nutmeg, (12,3,2) for Obama/Biden, and (12,5,1.75) for Monroe/Einstein. Cutoff trials and near/intermediate/far views document the choices. The Obama/Biden pair supplies the Fourier and four-way color analyses. For Monroe/Einstein, broadening the high-pass width from 3 to 5 and increasing gain from 1.25 to 1.75 strengthens Einstein's eye sockets, nose, moustache and wrinkles at 512 pixels. The 64-pixel view remains mixed; Monroe becomes clearer at 32 pixels. The cutoff trials isolate width and gain changes, retain the earlier setting, and show stronger alternatives. Broad cheek and jaw shading remains mixed. These are scale-dependent visual observations, not recognition measurements. Each original is sampled once by the composed alignment transform; no local deformation or independent neck adjustment is used.

For the landscape blend, input A is Lake McDonald and input B is the sandstone arch. The saved framing points specify independent crops and uniform scales, not corresponding features in one scene. A 122-vertex polygon selects the lake within the opening. The initial mask sigma is 1 pixel; four detail bands plus a coarse residual give nominal Gaussian mask widths of 1, 2.2, 4.1, 8.1 and 16 pixels. The source RGB values receive no photometric gains. The original arch photograph is a photographer-stitched panorama, as documented in the source record; the assignment composite is generated from the included originals.

The planet example fits each bright disk contour with an ellipse, then maps it to a common circle; fitted geometry and differential axis scaling are recorded. Its initial mask sigma remains 8 pixels with six detail bands. Thresholding measures planetary geometry only; the warps sample the original photographs.

For each blend, the same prepared inputs and binary selection are used for the hard cut, single-scale feathering, and multiresolution comparison. Feathering applies the exact coarsest multiscale mask to the full images. The stack applies scale-matched weights to signed image bands. Mask smoothing changes selection weights only. Band-count and mask-width sweeps are included for both custom examples. The arch/lake result retains slight lower-left seam lightening. These composites do not establish shared illumination or physical scene consistency. Rerun the experiment and report scripts after changes, and update `data/sources.json` with the source credits.

The supplied personal portrait and street photograph are reused from Assignment 1. Input originals are preserved at their original size; computation uses documented medium-resolution arrays. Signed floating-point bands are not clipped before analysis or reconstruction. Display exports alone use the stated normalization and clipping.

## PDF and packaging

The PDF is a print export of the same webpage, with all required figure panels and code snippets visible. Additional diagnostic trials are expandable on the webpage and linked from the PDF. For a manual export use the browser's Print / Save as PDF with background graphics enabled. For the automated export install Node.js and Playwright, start the local server above, then:

```sh
npm install --no-save playwright
npx playwright install chromium
node export_and_check.mjs http://localhost:8000
python package_submission.py
```

Set `CHROME_PATH` to use a specific Chromium/Chrome executable. Set `PLAYWRIGHT_MODULE` only if Playwright is installed outside the usual Node module path. Automated export uses `qa/` for review screenshots and diagnostics. `output/` contains the final PDF and ZIP files.

## Supplied course image package

The October 19 update uses `data/provided/burt_apple.png` and `burt_orange.png` from the supplied Part 2 image ZIP for the apple/orange stacks and blend. Both originals are 740x530 pixels and are preserved unchanged; processing preserves their aspect ratio. The package's Taj Mahal image and all hybrid ZIP files exactly match the earlier input originals. The hybrid results use the revised, per-pair cutoff and gain settings in the saved configuration. Earlier 300x300 apple/orange JPEGs are retained as unused alternate inputs. Course-only originals are bundled in the code ZIP and cannot be restored from a public download URL.

## References and rights

Methods follow the assignment handout and the cited Oliva-Torralba-Schyns (2006), Burt-Adelson (1983), and Szeliski (second edition) references. Image-specific credits and links are printed in the report. The White House portraits have public-domain source records. The Monroe portrait is credited to Gene Kornman / 20th Century Fox and has US public-domain status through nonrenewal in its source record. Einstein is credited to Orren Jack Turner / Library of Congress, whose record reports no known publication restrictions. No worldwide public-domain claim is made for these historical portraits. The classic pairing is credited to Aude Oliva (2013); the included code constructs a new hybrid from the separate original photographs. The arch photograph is by Thomas Wolf under CC BY-SA 3.0, and the lake photograph is by David Restivo / National Park Service under CC BY 2.0. Their adapted composite figures are distributed under CC BY-SA 3.0 with both credits. The Moon photograph is by Gregory H. Revera under CC BY-SA 3.0; its adapted figures retain that license. Unused alternate inputs remain credited in the manifest. No blanket license is asserted over the course samples or user-supplied photographs.

Timings are measured on the recorded local machine and depend on hardware and image size. Perceptual conclusions are visual observations, not results of a human-subject study. Correct reconstruction and agreement tests establish implementation consistency; they do not alone prove perceptual quality.
