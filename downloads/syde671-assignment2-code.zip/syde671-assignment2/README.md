# SYDE 671 - Assignment 2

Reproducible experiments for **Fun with Filters and Frequencies**: explicit NumPy convolution, finite differences, Gaussian derivatives, gradient orientations, sharpening, hybrid images, and full-resolution multiresolution blending.

## Reproduce the report

Python 3.12 was used for the recorded run. From this directory:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run_filters.py
python run_frequencies.py
python build_report.py
python -m http.server 8000 --directory site
```

On Windows activate `.venv\Scripts\activate` instead. Open `http://localhost:8000`. The included report can also be read directly from `site/index.html` without installing Python. Experiments run entirely on the CPU. No remote service or model is required to regenerate the image-processing results.

## Files

- `src/filters.py`: both explicit convolution implementations, gradient magnitude, quadrant-correct orientation without built-in angle functions, and unsharp kernel.
- `run_filters.py`: Parts 1.1-1.3, mandatory orientation extension, and Part 2.1; exports figures and actual measurements.
- `src/frequencies.py`: explicit Gaussian and Laplacian stacks, landmark alignment, hybrid images, and mask-weighted reconstruction.
- `frequencies_config.json`: source paths, original-image landmarks, sigmas, gains, color choices, and object/mask coordinates.
- `run_frequencies.py`: three required hybrids, color/cutoff studies, oraple and two custom blends, including decomposition figures.
- `tests/`: deterministic numerical checks for convolution, quadrants, derivative equivalence, reconstruction, alignment, and masks. SciPy/NumPy angle functions are allowed only as independent test references for the custom implementations.
- `data/sources.json`: source URLs, rights, credits, original dimensions and SHA-256 hashes.
- `data/acquire_sources.py`: verify the included original assets and recover missing downloadable originals.
- `results/`: measured parameters, numerical checks and report content.
- `build_report.py`: render the webpage from recorded experiment results.
- `site/`: self-contained static webpage, images and downloads.
- `export_and_check.mjs`: headless-browser PDF export, image/anchor checks and mobile-layout checks.
- `package_submission.py`: code+input ZIP and complete hand-in ZIP.

## Replace the custom examples

The downloaded examples are usable final inputs, not empty placeholders. Three required hybrid results use Derek/Nutmeg, astronaut/portrait cat, and Obama/tabby. Custom blends use Earth/coffee and Moon/rocket. Keep the examples or replace the sources in `frequencies_config.json`.

For each new hybrid, set both source paths and two corresponding landmarks in **original image (x,y) pixels** (left and right eye centers work well). Both images map to the same target points by uniform scale, rotation and translation. Tune `sigma_low`, `sigma_high`, and `gain` after alignment. Color toggles choose whether each component uses RGB or luminance. The blur standard deviations are measured in pixels on the aligned output canvas.

For an object blend, update the foreground/background paths, source object center/radii, target center/radii and mask radii. The nonrectangular masks select a curved object region; Gaussian filtering produces a transition at each spatial scale. Rerun both the experiment and report scripts after any changes. Update `data/sources.json` with the new source credits.

The supplied personal portrait and street photograph are reused from Assignment 1. Input originals are preserved at their original size; computation uses documented medium-resolution arrays. Signed floating-point bands are not clipped before analysis or reconstruction. Display exports alone use the stated normalization and clipping.

## PDF and packaging

The PDF is a print export of the same webpage, with all figure panels and code snippets visible. For a manual export use the browser's Print / Save as PDF with background graphics enabled. For the automated export install Node.js and Playwright, start the local server above, then:

```sh
npm install --no-save playwright
npx playwright install chromium
node export_and_check.mjs http://localhost:8000
python package_submission.py
```

Set `CHROME_PATH` to use a specific Chromium/Chrome executable. Set `PLAYWRIGHT_MODULE` only if Playwright is installed outside the usual Node module path. Automated export uses `qa/` for review screenshots and diagnostics. `output/` contains the final PDF and ZIP files.

## Supplied course image package

The October 19 update uses `data/provided/burt_apple.png` and `burt_orange.png` from the supplied Part 2 image ZIP for the apple/orange stacks and blend. Both originals are 740x530 pixels and are preserved unchanged; processing preserves their aspect ratio. The package's Taj Mahal image and all hybrid ZIP files exactly match the earlier inputs, so their results are unchanged. Earlier 300x300 apple/orange JPEGs are retained as unused alternate inputs. Course-only originals are bundled in the code ZIP and cannot be restored from a public download URL.

## References and rights

Methods follow the assignment handout and the cited Oliva-Torralba-Schyns (2006), Burt-Adelson (1983), and Szeliski (second edition) references. Image-specific credits and links are printed in the report. The Moon photograph is by Gregory H. Revera and the tabby photograph is by Joaquim Alves Gaspar (Alvesgaspar), both CC BY-SA 3.0; their modified figures are distributed under that same license, as recorded in the manifest. No blanket license is asserted over the course samples or user-supplied photographs.

Timings are measured on the recorded local machine and depend on hardware and image size. Perceptual conclusions are visual observations, not results of a human-subject study. Correct reconstruction and agreement tests establish implementation consistency; they do not alone prove perceptual quality.
