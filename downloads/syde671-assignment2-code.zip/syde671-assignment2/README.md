# SYDE 671 - Assignment 2

Reproducible experiments for **Spatial Filtering and Multiresolution Blending**: explicit NumPy convolution, finite differences, Gaussian derivatives, gradient orientations, sharpening, hybrid images, and full-resolution multiresolution blending.

## Reproduce the report

Python 3.12 was used for the recorded run. From this directory:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run_filters.py
python run_frequencies.py
python build_report.py
python -m http.server 8000 --directory site
```

On Windows activate `.venv\Scripts\activate` instead. Open `http://localhost:8000`. The complete submission ZIP includes a ready-to-read report at `webpage/index.html`, which works without installing Python. The code ZIP contains source and inputs; the commands above regenerate its `site/index.html` and figures. Experiments run entirely on the CPU. No remote service or model is required to regenerate the image-processing results.

## Files

- `src/filters.py`: both explicit convolution implementations, gradient magnitude, quadrant-correct orientation without built-in angle functions, and unsharp kernel.
- `run_filters.py`: Parts 1.1-1.3, mandatory orientation extension, and Part 2.1; exports figures and actual measurements.
- `src/frequencies.py`: explicit Gaussian and Laplacian stacks, landmark alignment, hybrid images, and mask-weighted reconstruction.
- `frequencies_config.json`: source paths, original-image landmarks, sigmas, gains, color choices, and object/mask coordinates.
- `run_frequencies.py`: orchestrates the hybrid, stack, and custom-blend experiments, then regenerates the diagnostic audit.
- `run_audit.py` and `src/audit_metrics.py`: reproduce the matched hybrid controls, all-example comparisons, and complete six-level reconstruction trace in `results/audit.json`. Run `python run_audit.py` separately to refresh these diagnostics from the saved configuration.
- `src/hybrid_report.py` and `src/blend_report.py`: reproducible image experiments and measured report content.
- `src/report_figures.py`: consistently scaled, labeled figure exports.
- `tests/`: deterministic numerical checks for convolution, quadrants, derivative equivalence, reconstruction, alignment, and masks. SciPy/NumPy angle functions are allowed only as independent test references for the custom implementations.
- `data/sources.json`: source URLs, rights, credits, original dimensions and SHA-256 hashes.
- `data/acquire_sources.py`: verify the included original assets and recover missing downloadable originals.
- `results/`: measured parameters, numerical checks and report content.
- `build_report.py`: compose the webpage from recorded experiment results.
- `src/filter_layout.py`, `src/frequency_layout.py`, and `src/audit_layout.py`: figure-led page order, report prose, and tables drawn from the measured diagnostics, with long implementations in a separate appendix.
- `site/`: self-contained static webpage, images and downloads.
- `export_and_check.mjs`: headless-browser PDF export, image/anchor checks and mobile-layout checks.
- `package_submission.py`: code+input ZIP and complete hand-in ZIP.

## Replace the custom examples

The three required hybrid results use Derek/Nutmeg, astronaut/portrait cat, and Obama/Einstein. The first custom blend combines Mount Rainier terrain and its foreground cloud with a Denali sunset sky. The second joins Earth and Moon with a curved seam. The additional Earth/Moon hybrid remains an explicitly discussed limitation study. Original source credits and hashes are recorded in `data/sources.json`.

For each new hybrid, set both source paths and two corresponding landmarks in **original image (x,y) pixels**. By default both images map to common eye targets using uniform scale, rotation and translation. Derek and the astronaut use optional `low_target_points` to refine the human scale to 0.70 about (250,210), with vertical shifts of -12 and 0 output pixels, respectively. This reduces the separate mouth below the cat muzzle while relaxing exact eye coincidence. The Obama/Einstein pair uses common eye targets (196,205) and (316,205), without a separate geometry refinement. Each source is sampled once. The favorite pair's two-by-two controls separate geometry and filtering. Tune `sigma_low`, `sigma_high`, and `gain` after alignment; their widths are in output pixels. Color toggles choose RGB or luminance for each component.

For a custom blend, update the input paths, framing or registration settings, output shape, and selection mask. The landscape uses independent crop-and-uniform-scale transforms. Its two saved points specify framing, not corresponding features of one scene. A 38-vertex polygon preserves Rainier's terrain, summit and warm foreground cloud. The initial mask sigma is 2 pixels and the image stack has five detail bands plus the residual. The planet example fits each bright disk contour with an ellipse, then maps it to a common circle; fitted geometry and differential axis scaling are recorded. Its initial mask sigma remains 8 pixels with six detail bands. Thresholding measures planetary geometry only; the warps sample the original photographs.

The same prepared inputs and binary selection are used for the hard cut, single-scale feathering, and multiresolution comparison. Feathering applies the exact coarsest multiscale mask to the full images. The stack applies scale-matched weights to signed image bands. The initial mask smoothing changes selection weights only. Band-count and mask-width sweeps are included for both custom examples. These are illustrative composites of different sources; blending does not establish shared lighting or physical scene consistency. Rerun the experiment and report scripts after any changes, and update `data/sources.json` with the new source credits.

The supplied personal portrait and street photograph are reused from Assignment 1. Input originals are preserved at their original size; computation uses documented medium-resolution arrays. Signed floating-point bands are not clipped before analysis or reconstruction. Display exports alone use the stated normalization and clipping.

## PDF and packaging

The PDF is a print export of the same webpage, with all required figure panels and code snippets visible. Additional diagnostic trials are expandable on the webpage and linked from the PDF. For a manual export use the browser's Print / Save as PDF with background graphics enabled. For the automated export install Node.js and Playwright, start the local server above, then:

```sh
npm install --no-save playwright
npx playwright install chromium
node export_and_check.mjs http://localhost:8000
python package_submission.py
```

Set `CHROME_PATH` to use a specific Chromium/Chrome executable. Set `PLAYWRIGHT_MODULE` only if Playwright is installed outside the usual Node module path. Automated export uses `qa/` for review screenshots and diagnostics. `output/` contains the final PDF and ZIP files.

## Supplied course image package

The October 19 update uses `data/provided/burt_apple.png` and `burt_orange.png` from the supplied Part 2 image ZIP for the apple/orange stacks and blend. Both originals are 740x530 pixels and are preserved unchanged; processing preserves their aspect ratio. The package's Taj Mahal image and all hybrid ZIP files exactly match the earlier input originals. The hybrid results use the revised, per-pair cutoff and gain settings in the saved configuration. Earlier 300x300 apple/orange JPEGs are retained as unused alternate inputs. Course-only originals are bundled in the code ZIP and cannot be restored from a public download URL.

## References and rights

Methods follow the assignment handout and the cited Oliva-Torralba-Schyns (2006), Burt-Adelson (1983), and Szeliski (second edition) references. Image-specific credits and links are printed in the report. The Moon photograph is by Gregory H. Revera under CC BY-SA 3.0; its adapted figures retain that license. The Einstein portrait is credited to Orren Jack Turner / Library of Congress, and the landscape originals to the National Park Service and NPS / Emily Mesner. Their source records document the publication rights. Unused alternate inputs remain credited in the manifest. No blanket license is asserted over the course samples or user-supplied photographs.

Timings are measured on the recorded local machine and depend on hardware and image size. Perceptual conclusions are visual observations, not results of a human-subject study. Correct reconstruction and agreement tests establish implementation consistency; they do not alone prove perceptual quality.
