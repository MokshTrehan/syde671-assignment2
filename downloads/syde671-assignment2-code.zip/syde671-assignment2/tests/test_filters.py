"""Independent regression tests; run with python -m unittest discover -s tests."""
import unittest
import numpy as np
from scipy.signal import convolve2d
from src.filters import (convolve_four_loops, convolve_two_loops,
                         orientation_without_angles, unsharp_kernel)


class ConvolutionTests(unittest.TestCase):
    def test_nonsymmetric_kernels_and_even_same_alignment(self):
        rng = np.random.default_rng(671)
        image = rng.normal(size=(8, 11))
        for shape in [(1, 1), (1, 3), (3, 1), (3, 5), (2, 4), (4, 3), (11, 14)]:
            kernel = rng.normal(size=shape)
            expected = convolve2d(image, kernel, mode='same', boundary='fill')
            for method in [convolve_four_loops, convolve_two_loops]:
                with self.subTest(shape=shape, method=method.__name__):
                    np.testing.assert_allclose(method(image, kernel), expected, atol=2e-14)

    def test_true_convolution_flips_kernel(self):
        image = np.zeros((7, 7)); image[3, 3] = 1
        kernel = np.arange(1, 10).reshape(3, 3)
        np.testing.assert_array_equal(convolve_two_loops(image, kernel)[2:5, 2:5], kernel)

    def test_zero_boundary_not_reflection(self):
        result = convolve_two_loops(np.ones((8, 9)), np.ones((3, 3)) / 9)
        self.assertAlmostEqual(result[0, 0], 4 / 9)
        self.assertAlmostEqual(result[0, 4], 2 / 3)
        self.assertAlmostEqual(result[4, 4], 1)

    def test_invalid_dimensions(self):
        for method in [convolve_four_loops, convolve_two_loops]:
            with self.assertRaises(ValueError):
                method(np.zeros((2, 2, 3)), [[1]])
            with self.assertRaises(ValueError):
                method(np.zeros((2, 2)), np.zeros((0, 1)))

    def test_dog_associativity_requires_halo(self):
        rng = np.random.default_rng(99)
        image = rng.normal(size=(21, 26))
        g = np.outer([1., 2, 1], [1., 2, 1]) / 16
        dx = np.array([[1., 0, -1]])
        combined = convolve2d(g, dx, mode='full')
        single = convolve2d(image, combined, mode='same')
        full_seq = convolve2d(convolve2d(image, g, mode='full'), dx, mode='full')
        y0, x0 = (np.array(combined.shape) - 1) // 2
        halo = full_seq[y0:y0 + image.shape[0], x0:x0 + image.shape[1]]
        np.testing.assert_allclose(single, halo, atol=1e-15)
        truncated = convolve2d(convolve2d(image, g, mode='same'), dx, mode='same')
        np.testing.assert_allclose(single[:, 1:-1], truncated[:, 1:-1], atol=1e-15)
        self.assertGreater(np.max(np.abs(single - truncated)), 0.01)

    def test_orientation_all_quadrants_axes_and_dynamic_range(self):
        rng = np.random.default_rng(889)
        gx, gy = rng.normal(size=(2, 10000))
        gx = np.r_[gx, 1, -1, 0, 0, 0, 1e-200, 1e200]
        gy = np.r_[gy, 0, 0, 1, -1, 0, 1e-200, -1e200]
        # np.arctan2 is only a test oracle, never used in submitted orientation implementation.
        expected = np.arctan2(gy, gx)
        np.testing.assert_allclose(orientation_without_angles(gx, gy), expected, atol=2e-14)

    def test_unsharp_single_convolution_identity(self):
        rng = np.random.default_rng(670)
        image = rng.uniform(size=(16, 17))
        g = np.outer([1., 2, 1], [1., 2, 1]) / 16
        for alpha in [0, .5, 1, 2]:
            kernel = unsharp_kernel(g, alpha)
            expected = image + alpha * (image - convolve2d(image, g, mode='same', boundary='symm'))
            actual = convolve2d(image, kernel, mode='same', boundary='symm')
            np.testing.assert_allclose(actual, expected, atol=1e-15)
            self.assertAlmostEqual(kernel.sum(), 1.0)


if __name__ == '__main__':
    unittest.main()
