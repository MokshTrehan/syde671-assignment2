"""Numerical invariants: these detect lost residuals, wrong masks and transforms."""
import unittest
import numpy as np
from src.frequencies import (gaussian_kernel, gaussian, laplacian_stack,
    reconstruct, multiresolution_blend, similarity_matrix, hybrid, disk_mask,
    apply_rgb_gain, align)


class FrequencyTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(671)
        self.a = rng.random((37, 43, 3))
        self.b = rng.random((37, 43, 3))
        self.mask = disk_mask(self.a.shape[:2], (21, 18), (13, 11))

    def test_gaussian_constant_and_channel_separation(self):
        np.testing.assert_allclose(gaussian_kernel(2.4).sum(), 1, atol=1e-14)
        a = np.ones((19, 23, 3)) * [0.2, 0.6, 0.9]
        np.testing.assert_allclose(gaussian(a, 3), a, atol=1e-14)

    def test_laplacian_exact_reconstruction(self):
        for a in (self.a, self.a[..., 0]):
            ls, gs = laplacian_stack(a, bands=5)
            self.assertEqual(len(ls), 6)
            self.assertTrue(all(g.shape == a.shape for g in gs))
            np.testing.assert_allclose(reconstruct(ls), a, atol=1e-14)
            np.testing.assert_allclose(ls[-1], gs[-1], atol=0)

    def test_blend_identity_endpoints_and_symmetry(self):
        same, _ = multiresolution_blend(self.a, self.a, self.mask)
        all_a, _ = multiresolution_blend(self.a, self.b, np.ones_like(self.mask))
        all_b, _ = multiresolution_blend(self.a, self.b, np.zeros_like(self.mask))
        ab, _ = multiresolution_blend(self.a, self.b, self.mask)
        ba, _ = multiresolution_blend(self.b, self.a, 1-self.mask)
        np.testing.assert_allclose(same, self.a, atol=1e-14)
        np.testing.assert_allclose(all_a, self.a, atol=1e-14)
        np.testing.assert_allclose(all_b, self.b, atol=1e-14)
        np.testing.assert_allclose(ab, ba, atol=1e-14)

    def test_two_landmarks_map_exactly(self):
        source = np.array([[30, 20], [180, 34]])
        target = np.array([[195, 170], [310, 170]])
        matrix = similarity_matrix(source, target)
        np.testing.assert_allclose(np.c_[source, np.ones(2)] @ matrix.T, target, atol=1e-12)
        linear = matrix[:, :2]
        gram = linear.T @ linear
        np.testing.assert_allclose(gram, np.eye(2)*gram[0,0], atol=1e-14)
        self.assertGreater(np.linalg.det(linear), 0)

    def test_hybrid_constant_high_source_has_no_detail(self):
        out, low, high = hybrid(self.a, np.ones_like(self.a)*0.4, 3, 4)
        np.testing.assert_allclose(high, 0, atol=1e-14)
        np.testing.assert_allclose(out, low, atol=1e-14)

    def test_reflection_reverses_pixels_and_eye_correspondences(self):
        # An asymmetric image catches upside-down rotation or a no-op mirror.
        image = np.arange(35, dtype=float).reshape(5, 7)
        source = np.array([[1., 2.], [5., 2.]])
        for original in (image, np.repeat(image[..., None], 3, axis=2)):
            reflected, matrix = align(original, source, source, image.shape,
                                      horizontal_flip=True)
            np.testing.assert_array_equal(reflected, original[:, ::-1])
            np.testing.assert_allclose(matrix, [[-1, 0, 6], [0, 1, 0]], atol=1e-14)
        source = np.array([[1., 1.], [4., 2.]])
        target = np.array([[2., 2.], [5., 2.]])
        _, matrix = align(image, source, target, image.shape, horizontal_flip=True)
        # The original right eye becomes the left target after reflection.
        np.testing.assert_allclose(np.c_[source[::-1], np.ones(2)] @ matrix.T,
                                   target, atol=1e-12)
        linear = matrix[:, :2]
        gram = linear.T @ linear
        np.testing.assert_allclose(gram, np.eye(2)*gram[0, 0], atol=1e-14)
        self.assertLess(np.linalg.det(linear), 0)

    def test_rgb_gain_remains_signed_through_blending(self):
        source = np.full((9, 11, 3), [0.95, -0.2, 0.4])
        corrected = apply_rgb_gain(source, [1.2, 0.5, 2.0])
        np.testing.assert_allclose(corrected, np.full_like(source, [1.14, -0.1, 0.8]))
        result, _ = multiresolution_blend(np.zeros_like(source), corrected,
                                          np.zeros(source.shape[:2]), bands=2)
        np.testing.assert_allclose(result, corrected, atol=1e-14)
        self.assertGreater(result.max(), 1)
        self.assertLess(result.min(), 0)
        np.testing.assert_array_equal(apply_rgb_gain(source), source)
        np.testing.assert_array_equal(source, np.full_like(source, [0.95, -0.2, 0.4]))

    def test_invalid_rgb_gains(self):
        for gains in ([1, 2], [[1, 1, 1]], [1, 0, 1], [1, -1, 1],
                      [1, np.nan, 1], [1, np.inf, 1]):
            with self.subTest(gains=gains), self.assertRaises(ValueError):
                apply_rgb_gain(self.a, gains)
        with self.assertRaises(ValueError):
            apply_rgb_gain(self.a[..., 0], [1, 1, 1])

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            gaussian_kernel(-2)
        with self.assertRaises(ValueError):
            similarity_matrix([[1,1],[1,1]], [[0,0],[1,1]])
        with self.assertRaises(ValueError):
            multiresolution_blend(self.a, self.b, self.mask+1)

if __name__ == '__main__':
    unittest.main()
