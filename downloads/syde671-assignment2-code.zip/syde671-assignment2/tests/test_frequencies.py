"""Numerical invariants: these detect lost residuals, wrong masks and transforms."""
import unittest
import numpy as np
from src.frequencies import (gaussian_kernel, gaussian, laplacian_stack,
    reconstruct, multiresolution_blend, similarity_matrix, hybrid, disk_mask)


class FrequencyTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(671)
        self.a = rng.random((37, 43, 3))
        self.b = rng.random((37, 43, 3))
        self.mask = disk_mask(self.a.shape[:2], (21, 18), (13, 11))

    def test_gaussian_constant_and_channel_separation(self):
        np.testing.assert_allclose(gaussian_kernel(2.4).sum(), 1, atol=1e-14)
        a = np.ones((19, 23, 3)) * [0.2, 0.6, 0.9]
        np.testing.assert_allclose(gaussian(a, 3), a, atol=1e-14)

    def test_laplacian_exact_reconstruction(self):
        for a in (self.a, self.a[..., 0]):
            ls, gs = laplacian_stack(a, bands=5)
            self.assertEqual(len(ls), 6)
            self.assertTrue(all(g.shape == a.shape for g in gs))
            np.testing.assert_allclose(reconstruct(ls), a, atol=1e-14)
            np.testing.assert_allclose(ls[-1], gs[-1], atol=0)

    def test_blend_identity_endpoints_and_symmetry(self):
        same, _ = multiresolution_blend(self.a, self.a, self.mask)
        all_a, _ = multiresolution_blend(self.a, self.b, np.ones_like(self.mask))
        all_b, _ = multiresolution_blend(self.a, self.b, np.zeros_like(self.mask))
        ab, _ = multiresolution_blend(self.a, self.b, self.mask)
        ba, _ = multiresolution_blend(self.b, self.a, 1-self.mask)
        np.testing.assert_allclose(same, self.a, atol=1e-14)
        np.testing.assert_allclose(all_a, self.a, atol=1e-14)
        np.testing.assert_allclose(all_b, self.b, atol=1e-14)
        np.testing.assert_allclose(ab, ba, atol=1e-14)

    def test_two_landmarks_map_exactly(self):
        source = np.array([[30, 20], [180, 34]])
        target = np.array([[195, 170], [310, 170]])
        matrix = similarity_matrix(source, target)
        np.testing.assert_allclose(np.c_[source, np.ones(2)] @ matrix.T, target, atol=1e-12)
        linear = matrix[:, :2]
        gram = linear.T @ linear
        np.testing.assert_allclose(gram, np.eye(2)*gram[0,0], atol=1e-14)
        self.assertGreater(np.linalg.det(linear), 0)

    def test_hybrid_constant_high_source_has_no_detail(self):
        out, low, high = hybrid(self.a, np.ones_like(self.a)*0.4, 3, 4)
        np.testing.assert_allclose(high, 0, atol=1e-14)
        np.testing.assert_allclose(out, low, atol=1e-14)

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            gaussian_kernel(-2)
        with self.assertRaises(ValueError):
            similarity_matrix([[1,1],[1,1]], [[0,0],[1,1]])
        with self.assertRaises(ValueError):
            multiresolution_blend(self.a, self.b, self.mask+1)

if __name__ == '__main__':
    unittest.main()
