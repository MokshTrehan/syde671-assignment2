# SYDE 671 - Assignment 2 hand-in

**Moksh Trehan - Spatial Filtering and Multiresolution Blending**

Webpage: https://mokshtrehan.github.io/syde671-assignment2/

Upload the report PDF and the code-and-input ZIP together, and include the website URL.

Files for LEARN:

- `syde671-assignment2-report.pdf`: print version of the complete webpage.
- `syde671-assignment2-code.zip`: Python source, tests, all input photographs, parameters, source credits and measured results.
- The webpage URL above.

The complete submission archive includes `webpage/index.html` and all web assets. Its `webpage/downloads/` directory contains the PDF and code ZIP, so each large file is included only once. The webpage works offline when `webpage/index.html` is opened in a browser.

## Coverage

- 1.1: NumPy-only four-loop and two-loop convolution, zero padding, SciPy correctness/runtime/boundary comparison, self-portrait box and derivative filtering, displayed code.
- 1.2: cameraman x/y derivatives, magnitude and justified threshold sweep.
- 1.3: Gaussian constructed with `cv2.getGaussianKernel`, smoothed derivatives, DoG filters, equivalence verification and noise comparison.
- Mandatory extension: HSV gradient orientations, computed without built-in angle functions.
- 2.1: Taj Mahal and original photograph sharpening, single-kernel derivation, alpha sweep, signed high frequencies, clipping analysis, and blur/resharpen comparison.
- 2.2: supplied Derek/Nutmeg plus two custom person/cat pairs; alignment, Fourier analysis, cutoff experiments, viewing scales, and four-way color exploration. Additional Earth/Moon limitation example.
- 2.3: explicit Gaussian/Laplacian stacks, residual reconstruction, apple/orange/mask stacks, Figure 3.42 (a)-(l) decomposition.
- 2.4: full-color oraple, hard-seam comparison, two custom blends with an irregular facial polygon and a curved planetary seam, a favorite masked-band process, and grayscale/color comparison.
- Reflection, source credits, reproducibility instructions and numerical tests.

The custom photographs are sourced examples that can be used as delivered. To substitute your own selections, edit `frequencies_config.json` and regenerate; see README.md inside the code ZIP.

Updated October 19, 2026: Parts 2.3-2.4 use the apple and orange PNG originals from the supplied Part 2 image package. The PDF, measured results, code ZIP and webpage all reflect these inputs.

Visual refinement: hybrid cutoffs and gains are selected per pair. The custom examples are cat face blending and Earth-Moon blending, with explicit hard-cut and single-scale-feather baselines. All required results remain in the PDF; optional diagnostic trials are available in the webpage supplements.

The final planet blend smooths its finest selection mask at sigma 8 pixels, chosen from a controlled 0-16 pixel sweep. This removes the abrupt limb join while keeping the original photographs and Laplacian image bands unchanged.

Final visual refinement: all three portrait–cat hybrids use documented similarity-scale/position adjustments to place the broad human mouth within the cat muzzle. Derek uses low/high Gaussian widths 8/1.5 and gain 2.25; the astronaut uses 10/1.5 and gain 2.7; Obama uses 8/2 and gain 2. The cat dominates the larger views while the human remains recognizable at 64 pixels; intermediate views retain both identities. The favorite cat blend uses a crown/cheek/chin contour and an 8-pixel initial mask Gaussian. Controlled comparisons, final measurements and exact parameters are regenerated from the included code.
