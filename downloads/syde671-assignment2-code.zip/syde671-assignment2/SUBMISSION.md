# SYDE 671 - Assignment 2 hand-in

**Moksh Trehan - Spatial Filtering and Multiresolution Blending**

Webpage: https://mokshtrehan.github.io/syde671-assignment2/

Upload the report PDF and the code-and-input ZIP together, and include the website URL.

Files for LEARN:

- `syde671-assignment2-report.pdf`: print version of the complete webpage.
- `syde671-assignment2-code.zip`: Python source, tests, all input photographs, parameters, source credits and measured results.
- The webpage URL above.

The complete submission archive includes `webpage/index.html` and all web assets. Its `webpage/downloads/` directory contains the PDF and code ZIP, so each large file is included only once. The webpage works offline when `webpage/index.html` is opened in a browser.

## Coverage

- 1.1: NumPy-only four-loop and two-loop convolution, zero padding, SciPy correctness/runtime/boundary comparison, self-portrait box and derivative filtering, displayed code.
- 1.2: cameraman x/y derivatives, magnitude and justified threshold sweep.
- 1.3: Gaussian constructed with `cv2.getGaussianKernel`, smoothed derivatives, DoG filters, equivalence verification and noise comparison.
- Mandatory extension: HSV gradient orientations, computed without built-in angle functions.
- 2.1: Taj Mahal and original photograph sharpening, single-kernel derivation, alpha sweep, signed high frequencies, clipping analysis, and blur/resharpen comparison.
- 2.2: supplied Derek/Nutmeg, Obama/Biden, and Monroe/Einstein; alignment, Fourier analysis, cutoff experiments, viewing scales, and four-way color exploration. Additional Earth/Moon limitation example.
- 2.3: explicit Gaussian/Laplacian stacks, residual reconstruction, apple/orange/mask stacks, Figure 3.42 (a)-(l) decomposition.
- 2.4: full-color oraple, hard-seam comparison, two custom blends with an irregular arch-opening polygon and a curved planetary seam, a favorite masked-band process, and grayscale/color comparison.
- Reflection, source credits, reproducibility instructions and numerical tests.

The custom photographs are sourced examples that can be used as delivered. To substitute your own selections, edit `frequencies_config.json` and regenerate; see README.md inside the code ZIP.

Updated October 19, 2026: Parts 2.3-2.4 use the apple and orange PNG originals from the supplied Part 2 image package. The PDF, measured results, code ZIP and webpage all reflect these inputs.

The custom blends are a sandstone arch with Lake McDonald, and Earth with the Moon. Both include hard-cut and single-scale-feather baselines, mask-width and band-count trials, and color comparisons. The landscape uses a 122-vertex aperture polygon, an initial mask sigma of 1 pixel, and four detail bands plus the residual. Its independent framing controls specify crops, not corresponding features of one scene. All baselines use the same prepared RGB inputs without photometric gains or intermediate clipping. Earth/Moon retains its corrected disk alignment and initial mask sigma of 8 pixels. The additional Earth/Moon hybrid remains a limitation study.

The custom hybrids are Obama/Biden and the classic Monroe/Einstein pairing. Obama/Biden uses low/high Gaussian widths 12/3 and gain 2; Monroe/Einstein uses 12/3 and gain 1.25. Both use common eye alignment. The Monroe/Einstein result is generated from the separately credited original photographs, with the classic concept attributed to Aude Oliva. Biden's facial detail and Einstein's wrinkles and moustache distinguish the close views; Obama and Monroe emerge in the small views.

The required Derek/Nutmeg pair uses common eye alignment, widths 8/3 and gain 1.25. A controlled comparison shows why separately shrinking Derek produces less coherent cat eye and cheek contours. The final 64-pixel view remains mixed, while the additional 32-pixel view makes Derek clearer. The report discusses remaining shading, documents exact parameters and provides reproducible measurements rather than treating the visual results as perfect.
