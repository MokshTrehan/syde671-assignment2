# SYDE 671 - Assignment 2 hand-in

**Moksh Trehan - Fun with Filters and Frequencies**

Webpage: https://mokshtrehan.github.io/syde671-assignment2/

Files for LEARN:

- `syde671-assignment2-report.pdf`: print version of the complete webpage.
- `syde671-assignment2-code.zip`: Python source, tests, all input photographs, parameters, source credits and measured results.
- The webpage URL above.

The complete submission archive includes `webpage/index.html` and all web assets. Its `webpage/downloads/` directory contains the PDF and code ZIP, so each large file is included only once. The webpage works offline when `webpage/index.html` is opened in a browser.

## Coverage

- 1.1: NumPy-only four-loop and two-loop convolution, zero padding, SciPy correctness/runtime/boundary comparison, self-portrait box and derivative filtering, displayed code.
- 1.2: cameraman x/y derivatives, magnitude and justified threshold sweep.
- 1.3: Gaussian constructed with `cv2.getGaussianKernel`, smoothed derivatives, DoG filters, equivalence verification and noise comparison.
- Mandatory extension: HSV gradient orientations, computed without built-in angle functions.
- 2.1: Taj Mahal and original photograph sharpening, single-kernel derivation, alpha sweep, signed high frequencies, clipping analysis, and blur/resharpen comparison.
- 2.2: supplied Derek/Nutmeg plus two custom person/cat pairs; alignment, Fourier analysis, cutoff experiments, viewing scales, and four-way color exploration. Additional Earth/Moon limitation example.
- 2.3: explicit Gaussian/Laplacian stacks, residual reconstruction, apple/orange/mask stacks, Figure 3.42 (a)-(l) decomposition.
- 2.4: full-color oraple, hard-seam comparison, two custom blends with curved masks, a favorite masked-band process, and grayscale/color comparison.
- Reflection, source credits, reproducibility instructions and numerical tests.

The custom photographs are sourced examples that can be used as delivered. To substitute your own selections, edit `frequencies_config.json` and regenerate; see README.md inside the code ZIP.

Updated October 19, 2026: Parts 2.3-2.4 use the apple and orange PNG originals from the supplied Part 2 image package. The PDF, measured results, code ZIP and webpage all reflect these inputs.
