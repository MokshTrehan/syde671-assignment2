"""Restore missing downloaded inputs using the adjacent provenance manifest.

Run with Python 3: python data/acquire_sources.py
Existing files are verified but never overwritten. Personal photographs and course-only originals
are bundled with the submission and cannot be recovered from a public URL.
All processing takes place in the assignment pipeline, not in this downloader.
"""

from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from urllib.request import Request, urlopen
from zipfile import ZipFile


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "sources.json").read_text())
    downloaded = {}
    problems = []
    for asset in manifest["assets"]:
        target = root / asset["file"]
        if not target.exists():
            url = asset.get("download_url")
            if not url:
                problems.append(f"Missing bundled input (restore from the submission or supplied course package): {asset['file']}")
                continue
            if url not in downloaded:
                request = Request(url, headers={"User-Agent": "SYDE671-assignment2/1.0"})
                with urlopen(request, timeout=30) as response:
                    downloaded[url] = response.read()
            payload = downloaded[url]
            member = asset.get("archive_member")
            if member:
                with ZipFile(BytesIO(payload)) as archive:
                    candidates = [name for name in archive.namelist()
                                  if not name.startswith("__MACOSX/")
                                  and Path(name).name == Path(member).name]
                    if len(candidates) != 1:
                        raise ValueError(f"Ambiguous archive member: {member}")
                    payload = archive.read(candidates[0])
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
        actual = sha256(target.read_bytes()).hexdigest()
        if actual != asset["sha256"]:
            problems.append(f"Hash differs (file retained): {asset['file']}")
        else:
            print(f"Verified {asset['file']}")
    if problems:
        raise SystemExit("\n".join(problems))


if __name__ == "__main__":
    main()
