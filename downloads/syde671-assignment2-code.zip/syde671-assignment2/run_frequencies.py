#!/usr/bin/env python3
"""Generate every Part 2.2–2.4 image and the report metadata from saved inputs.

Run from any directory: python /path/to/assignment2/run_frequencies.py
Edit frequencies_config.json to replace images/landmarks or tune cutoffs/masks.
"""
from pathlib import Path
import json
import textwrap
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps
import cv2
from src.frequencies import (gaussian, grayscale, rgb, align, hybrid,
    gaussian_stack, laplacian_stack, reconstruct, multiresolution_blend,
    disk_mask, log_spectrum, clip_fraction)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'site/images'
OUT.mkdir(parents=True, exist_ok=True)
BG = (247, 247, 244)
FONT_PATHS = ['/System/Library/Fonts/Supplemental/Arial.ttf',
              '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']

def font(size=17):
    for path in FONT_PATHS:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default(size=size)


def read(path):
    return np.asarray(ImageOps.exif_transpose(Image.open(ROOT/path)).convert('RGB'), dtype=np.float64)/255


def pil(a):
    if isinstance(a, Image.Image):
        return a.convert('RGB')
    return Image.fromarray(np.uint8(np.rint(np.clip(rgb(a), 0, 1)*255)))


def save(a, name):
    path = OUT / (name + '.jpg')
    pil(a).save(path, quality=88, optimize=True)
    # Keep report panels comfortable to load without hiding data processing.
    if path.stat().st_size > 790000:
        pil(a).save(path, quality=76, optimize=True)
    return 'images/' + path.name


def grid(items, name, cols=3, size=(320,320)):
    w,h = size
    rowh = h+66
    canvas = Image.new('RGB', (cols*(w+16)+16, ((len(items)+cols-1)//cols)*rowh+16), BG)
    draw = ImageDraw.Draw(canvas)
    for i,(a,label) in enumerate(items):
        thumb = ImageOps.contain(pil(a), (w,h), Image.Resampling.LANCZOS)
        x=16+(i%cols)*(w+16); y=16+(i//cols)*rowh
        canvas.paste(thumb,(x+(w-thumb.width)//2,y+(h-thumb.height)//2))
        for j,line in enumerate(textwrap.wrap(label, max(18,int(w/8.8)))[:3]):
            draw.text((x,y+h+8+j*18),line,font=font(16),fill=(31,40,49))
    return save(canvas,name)


def mark(a, points):
    im = pil(a)
    d=ImageDraw.Draw(im)
    radius=max(4,int(min(im.size)*.010))
    for i,(x,y) in enumerate(points):
        d.ellipse((x-radius,y-radius,x+radius,y+radius), outline=(0,255,255),width=max(2,radius//3))
        d.text((x+radius+3,y-radius),str(i+1),fill=(0,255,255),font=font(max(16,radius*2)))
    return im


def near_far(a, name):
    canvas=Image.new('RGB',(1056,572),BG)
    d=ImageDraw.Draw(canvas)
    x=16
    for width in [512,256,128,64]:
        im=pil(a).resize((width,width),Image.Resampling.LANCZOS)
        canvas.paste(im,(x,24+(512-width)//2))
        d.text((x,544),str(width)+' px',font=font(16),fill=(31,40,49))
        x+=width+20
    return save(canvas,name)


def spectrum_panel(a, vmax):
    return log_spectrum(a)/max(vmax,1e-12)


def signed_row(arrays):
    # Same scaling across A, B and sum within a band; no independent contrast.
    scale=max(float(np.quantile(np.abs(a),.995)) for a in arrays)
    scale=max(scale,1e-8)
    return [0.5 + .45*a/scale for a in arrays], scale


def contribution_figure(details,name,levels=(0,2,4)):
    items=[]; scales=[]
    for level in levels:
        arrays=[details['ca'][level],details['cb'][level],details['sum'][level]]
        shown,scale=signed_row(arrays); scales.append(scale)
        for a,col in zip(shown,['masked A','masked B','sum']):
            items.append((a,f'({chr(97+len(items))}) L{level}: {col}'))
    for arr,label in [(reconstruct(details['ca']),'Reconstructed A contribution'),
                      (reconstruct(details['cb']),'Reconstructed B contribution'),
                      (reconstruct(details['sum']),'Final reconstruction')]:
        items.append((arr,f'({chr(97+len(items))}) {label}'))
    return grid(items,name,3,(300,240)),scales


def describe(fig,caption):
    return {'path':fig,'caption':caption}


def section(id,title,paragraphs=None,figures=None,tables=None,code=None):
    return {'id':id,'title':title,'paragraphs':paragraphs or [],'figures':figures or [],'tables':tables or [],'code':code or []}


def hybrid_experiments(a,b,cfg):
    pairs=[(5,2),(5,8),(10,2),(10,5),(10,8),(18,5)]
    lows={s:gaussian(rgb(grayscale(a)),s) for s in set(x[0] for x in pairs)}
    highs={s:rgb(grayscale(b))-gaussian(rgb(grayscale(b)),s) for s in set(x[1] for x in pairs)}
    items=[]
    for sl,sh in pairs:
        result=lows[sl]+cfg['gain']*highs[sh]
        chosen=' [selected]' if sl==cfg['sigma_low'] and sh==cfg['sigma_high'] else ''
        items.append((result,f'low sigma={sl}; high sigma={sh}{chosen}'))
    return grid(items,'hybrid_'+cfg['id']+'_sweep',3,(270,270))


def make_hybrids(config):
    figs=[]; data=[]; color_figs=[]; rows=[]
    favorite=None
    for cfg in config['hybrids']:
        ident=cfg['id']; print('Hybrid:',ident,flush=True)
        raw_a=read(cfg['low_path']); raw_b=read(cfg['high_path'])
        a,ma=align(raw_a,cfg['low_points'],cfg['target_points'],cfg['shape'])
        b,mb=align(raw_b,cfg['high_points'],cfg['target_points'],cfg['shape'])
        result,low,high=hybrid(a,b,cfg['sigma_low'],cfg['sigma_high'],cfg['gain'],cfg['low_color'],cfg['high_color'])
        final=save(result,'hybrid_'+ident+'_final')
        near=near_far(result,'hybrid_'+ident+'_distance')
        alignment=grid([(mark(raw_a,cfg['low_points']),'Original low source: two landmarks'),
                        (mark(raw_b,cfg['high_points']),'Original high source: two landmarks'),
                        (mark(a,cfg['target_points']),'Aligned low source: 512 x 512'),
                        (mark(b,cfg['target_points']),'Aligned high source: 512 x 512')],
                        'hybrid_'+ident+'_alignment',4,(260,300))
        comps=grid([(a,'Aligned low-frequency source'),(b,'Aligned high-frequency source'),
                    (low,'Gaussian low pass'),(.5+2.5*high,'Signed high pass: 0.5 + 2.5H'),
                    (result,'Hybrid = low + high')],'hybrid_'+ident+'_components',5,(230,250))
        figs.extend([describe(alignment,cfg['title']+': original inputs and two-point similarity alignment. Cyan circles identify the manually selected original landmarks and their shared destination. Rotation, uniform scale and translation are applied; interpolation is bilinear, with edge replication outside the source crop (filter boundaries use reflection).'),
                     describe(comps,cfg['title']+f': low-pass sigma {cfg["sigma_low"]} px, high-pass sigma {cfg["sigma_high"]} px, detail gain {cfg["gain"]}. Signed high frequencies are contrast-amplified around midgray only in this display.'),
                     describe(near,cfg['title']+': the same hybrid shown at 512, 256, 128 and 64 pixels. Smaller display size suppresses visible fine detail; use the largest panel or open the figure to examine the near view.')])
        if ident in ('derek_nutmeg','astronaut_chelsea','obama_tabby'):
            figs.append(describe(hybrid_experiments(a,b,cfg),cfg['title']+': six spatial-cutoff trials. Small high-pass sigma retains only very fine edges; large high-pass sigma leaks more cat structure into the distance view. A stronger low-pass blur also removes facial identity cues.'))
        if ident=='astronaut_chelsea':
            favorite=(raw_a,raw_b,a,b,low,high,result,cfg)
            color_items=[]
            for lc,hc,label in [(False,False,'Neither source in color'),(True,False,'Low source only in color'),(False,True,'High source only in color'),(True,True,'Both sources in color')]:
                im,_,_=hybrid(a,b,cfg['sigma_low'],cfg['sigma_high'],cfg['gain'],lc,hc)
                color_items.append((im,label))
            color_figs.append(describe(grid(color_items,'hybrid_color_comparison',4,(280,280)),
                'Four controlled color variants use identical alignment, sigma values and gain. Only grayscale conversion changes. Grayscale uses luminance weights 0.2126, 0.7152, 0.0722.'))
        # Kernel has no hard cutoff. This is the amplitude half-response frequency
        # for the continuous Gaussian that the discrete sampled kernel approximates.
        f_low=np.sqrt(2*np.log(2))/(2*np.pi*cfg['sigma_low'])
        f_high=np.sqrt(2*np.log(2))/(2*np.pi*cfg['sigma_high'])
        record=dict(cfg,low_matrix=ma.tolist(),high_matrix=mb.tolist(),
                    clip_fraction=clip_fraction(result),range=[float(result.min()),float(result.max())],
                    low_half_amplitude_cycles_per_pixel=float(f_low),
                    high_half_amplitude_cycles_per_pixel=float(f_high),
                    final=final,alignment=alignment,components=comps,near_far=near)
        data.append(record)
        rows.append([cfg['title'],str(cfg['sigma_low']),str(cfg['sigma_high']),str(cfg['gain']),
                     f'{f_low:.4f}',f'{f_high:.4f}',f'{100*clip_fraction(result):.2f}%'])
    raw_a,raw_b,a,b,low,high,result,cfg=favorite
    source_arrays=[raw_a,raw_b,a,b,low,high,result]
    labels=['Original astronaut','Original cat','Aligned astronaut','Aligned cat','Low-pass component','High-pass component','Final hybrid']
    # FFT normalized by pixel count so differently sized originals are comparable.
    spectra=[]
    for arr in source_arrays:
        gray=grayscale(arr)
        spectra.append(np.log1p(np.abs(np.fft.fftshift(np.fft.fft2(gray)))/gray.size*1000000))
    vmax=max(float(s.max()) for s in spectra)
    top=[(arr if i!=5 else .5+2.5*arr,label) for i,(arr,label) in enumerate(zip(source_arrays,labels))]
    bottom=[(s/vmax,'Log Fourier: '+label) for s,label in zip(spectra,labels)]
    fourier=grid(top+bottom,'hybrid_fourier_process',7,(235,260))
    figs.append(describe(fourier,'Full Fourier workflow for Astronaut + portrait cat. Each bottom panel shows log(1 + 1000000 |fftshift(fft2(luminance))| / N), with one common display maximum for all panels. Division by N compares inputs of different dimensions. No FFT window or mean subtraction is used. The low pass concentrates energy centrally; the high pass suppresses the center and retains outer frequencies. Original, aligned, filtered and final images are all shown.'))
    sec=section('part22','2.2 · Hybrid images',[
        'A hybrid adds a blurred image to the signed detail of a second aligned image: H = G_sigmaL * A + gain (B - G_sigmaH * B). The low-frequency subject should dominate from farther away; fine edges make the high-frequency subject visible nearby. Filtering is performed in floating-point RGB intensity (or replicated luminance), with separable normalized Gaussian kernels and reflected image boundaries.',
        'Derek + Nutmeg is the supplied pair. Astronaut + portrait cat and Obama + tabby are two custom pairs made from downloadable, attributed photographs. Both custom portraits use eye centers to align with the cat eyes. Each input is transformed independently onto a 512 x 512 canvas by a two-point similarity transform. Manual landmarks, original pixel coordinates and complete 2 x 3 matrices are saved in results/frequencies.json; the editable choices are in frequencies_config.json.',
        'The six-panel sweeps compare blur widths in output pixels. The selected facial settings (sigmaL = 10, sigmaH = 5) preserve the broad human face while retaining cat fur, whiskers and eye rims. SigmaH = 2 produces weak, mainly fine texture; sigmaH = 8 introduces more cat shading and makes the distance interpretation less clean. SigmaL = 18 weakens useful human identity. These are visual judgments for these crops, not a universal optimal cutoff.',
        'The Gaussian response has no sharp frequency boundary. The table gives the continuous-Gaussian half-amplitude estimate sqrt(2 ln 2) / (2 pi sigma), in cycles per output pixel. For the high-pass response 1-G, the half-amplitude frequency has the same expression. All actual filters use spatial convolution; the FFT panels diagnose the result.',
        'Earth + Moon is an additional limitation study. Aligning both circular limbs is geometrically easy, but the two subjects share the same silhouette and overlapping spatial structure. The output is better described as a textured planet than a clean categorical switch. Good landmark alignment alone cannot guarantee a strong perceptual hybrid.',
        'No signed band is clipped before addition. Exported display images are clipped to [0,1] and quantized to 8 bits; the table reports the fraction of scalar channel values outside this interval before export. The signed-band visualization uses 0.5 + 2.5H, independently of the numerical synthesis.'],figs,[{'title':'Selected parameters and display clipping','columns':['Pair','sigma low (px)','sigma high (px)','gain','low f_0.5','high f_0.5','values clipped'],'rows':rows}],
        [{'title':'Hybrid synthesis','text':'low = gaussian(A, sigma_low)\nhigh = B - gaussian(B, sigma_high)\nhybrid = low + gain * high'}])
    color=section('hybrid-color','Color · Which frequency band benefits?',[
        'Color is tested in neither image, the low-frequency image only, the high-frequency image only and both images. Low-only color keeps broad skin and background hues associated with the distant astronaut. High-only color contributes local colored edges and cat-eye detail but cannot transfer the cat’s broad coat color, because those low frequencies have been removed.',
        'For Astronaut + portrait cat, low-only color is the most coherent color variant: its large color regions agree with the distant subject, while grayscale cat detail remains readable. Both-color introduces some competing hue at edges; high-only color has a mostly neutral base. The grayscale versions above make the frequency-dependent identity easier to compare without a persistent broad color cue.'],color_figs)
    return [sec,color],data


def make_stacks_and_oraple(config):
    print('Stacks and oraple',flush=True)
    a=read('data/provided/apple.jpg'); b=read('data/provided/orange.jpg')
    a=cv2.resize(a,(512,512),interpolation=cv2.INTER_AREA)
    b=cv2.resize(b,(512,512),interpolation=cv2.INTER_AREA)
    n=config['stack']['bands']; sigma=config['stack']['base_sigma']
    mask=np.zeros(a.shape[:2]); mask[:,:256]=1
    final,details=multiresolution_blend(a,b,mask,n,sigma)
    stack_figs=[]
    for key,label in [('a','Apple'),('b','Orange')]:
        gs=details['g'+key]; ls=details['l'+key]
        items=[(g,f'G{i}: '+('original' if i==0 else f'sigma={sigma*2**(i-1):g} px')) for i,g in enumerate(gs)]
        for i,l in enumerate(ls):
            view= l if i==n else .5+2.5*l
            items.append((view,f'L{i}: '+('coarse residual' if i==n else f'G{i} - G{i+1}')))
        stack_figs.append(describe(grid(items,'stacks_'+label.lower(),6,(200,220)),
            label+': full-resolution Gaussian stack (top) and Laplacian stack (bottom), including the coarse residual. All six arrays have the same 512 x 512 resolution. Signed bands use 0.5 + 2.5L for display; the residual uses its actual intensity.'))
    maskfig=grid([(g,f'Gaussian mask M{i}') for i,g in enumerate(details['gm'])],'stacks_mask',6,(200,220))
    stack_figs.append(describe(maskfig,'The binary left/right mask is blurred at exactly the Gaussian image-stack scales. Fine bands use a sharp transition; coarser bands mix over progressively wider neighborhoods. White selects apple, black selects orange.'))
    process,scales=contribution_figure(details,'stacks_oraple_figure342',(0,2,4))
    stack_figs.append(describe(process,'Reproduction of the Figure 3.42 (a)–(l) layout: rows 1–3 show levels 0, 2 and 4, with masked apple, masked orange and their sum in the three columns. Row 4 reconstructs each contribution and the final oraple by summing ALL five detail bands plus the coarse residual. Detail displays share a symmetric contrast scale across each row; row 4 is shown in actual [0,1] intensity.'))
    hard=mask[...,None]*a+(1-mask[...,None])*b
    comparison=grid([(a,'Apple input'),(b,'Orange input'),(mask,'Binary seam mask'),(hard,'Direct hard seam'),(final,'Multiresolution blend')],'blend_oraple_comparison',5,(240,250))
    save(final,'blend_oraple_final')
    metric={
        'apple_reconstruction_max_abs_error':float(np.max(np.abs(reconstruct(details['la'])-a))),
        'orange_reconstruction_max_abs_error':float(np.max(np.abs(reconstruct(details['lb'])-b))),
        'final_decomposition_max_abs_error':float(np.max(np.abs(reconstruct(details['sum'])-final))),
        'stack_shape':list(a.shape),'bands':n,'coarse_sigma':sigma*2**(n-1),
        'clip_fraction':clip_fraction(final),'figure342_shared_row_scales':scales,
        'mean_boundary_jump_hard':float(np.mean(np.abs(hard[:,256]-hard[:,255]))),
        'mean_boundary_jump_blend':float(np.mean(np.abs(final[:,256]-final[:,255])))}
    stacks=section('part23','2.3 · Gaussian and Laplacian stacks',[
        'A stack keeps every level at full resolution. I set G0 = I, then blur the original independently at sigma = 2, 4, 8, 16 and 32 pixels. The detail bands are Li = Gi - G(i+1) for i = 0,...,4; L5 = G5 is the coarse residual. Independent blurring makes the effective sigma of each level explicit. No image is downsampled and no built-in pyramid routine is used.',
        'The residual is essential: summing only the detail bands would recover I - G5 and lose the large-scale brightness and color. With the residual, the sum telescopes exactly to I up to floating-point rounding. The apple and orange reconstruction errors are reported below.',
        'The mask follows the same Gaussian schedule. Each output level is Si = Mi LAi + (1 - Mi) LBi, including the residual level, and the final image is the sum of all Si. A is selected wherever the initial mask is white. This separates fine texture transitions from broad illumination and color transitions.'],stack_figs,[{'title':'Stack validation','columns':['Invariant','Maximum absolute error'],'rows':[
            ['Apple reconstruction',f'{metric["apple_reconstruction_max_abs_error"]:.3e}'],['Orange reconstruction',f'{metric["orange_reconstruction_max_abs_error"]:.3e}'],['Final equals sum of all mixed bands',f'{metric["final_decomposition_max_abs_error"]:.3e}']]}],
        [{'title':'Explicit stacks and reconstruction','text':'G = [I] + [gaussian(I, 2 * 2**i) for i in range(5)]\nL = [G[i] - G[i+1] for i in range(5)] + [G[-1]]\nS = [M[i] * LA[i] + (1-M[i]) * LB[i] for i in range(6)]\nresult = sum(S)'}])
    blends=section('part24','2.4 · Multiresolution blending',[
        'The standard apple/orange blend uses the apple on the left and the orange on the right. A direct binary cut preserves a conspicuous vertical brightness/color discontinuity; mixing corresponding Laplacian bands with Gaussian mask weights spreads that transition according to scale while retaining local texture.',
        f'For these inputs, the mean absolute RGB difference across the two columns adjoining the seam decreases from {metric["mean_boundary_jump_hard"]:.4f} to {metric["mean_boundary_jump_blend"]:.4f}. This local diagnostic supports the visible seam comparison; it is not a general perceptual-quality score.'],[describe(comparison,'Inputs, selection mask, hard-cut baseline and full-color multiresolution oraple. Both baselines use the same preprocessed 512 x 512 input images and the same initial mask.')])
    return [stacks,blends],metric


def make_custom_blends(config):
    figs=[]; metrics=[]; tables=[]; color_items=[]
    for cfg in config['blends']:
        ident=cfg['id']; print('Blend:',ident,flush=True)
        obj=read(cfg['object']); back=read(cfg['background'])
        h,w=cfg['shape']
        back=cv2.resize(back,(w,h),interpolation=cv2.INTER_AREA)
        sx,sy=np.asarray(cfg['target_radii'])/np.asarray(cfg['source_radii'])
        cx,cy=cfg['source_center']; dx,dy=cfg['target_center']
        matrix=np.array([[sx,0,dx-sx*cx],[0,sy,dy-sy*cy]],dtype=float)
        placed=cv2.warpAffine(obj,matrix,(w,h),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
        mask=disk_mask((h,w),cfg['target_center'],cfg['mask_radii'])
        # Extend the source canvas using the destination outside the actual disk.
        # This avoids importing the photograph's black rectangle into coarse bands.
        support=disk_mask((h,w),cfg['target_center'],cfg['target_radii'])
        a=support[...,None]*placed+(1-support[...,None])*back
        hard=mask[...,None]*a+(1-mask[...,None])*back
        final,details=multiresolution_blend(a,back,mask,cfg['bands'],cfg['base_sigma'])
        finalpath=save(final,'blend_'+ident+'_final')
        gray_final,_=multiresolution_blend(grayscale(a),grayscale(back),mask,cfg['bands'],cfg['base_sigma'])
        color_items.extend([(gray_final,cfg['title']+' / grayscale'),(final,cfg['title']+' / RGB')])
        fig=grid([(obj,'Original object photograph'),(back,'Destination photograph'),(a,'Registered source canvas'),
                  (mask,'Curved binary selection mask'),(hard,'Direct hard cut'),(final,'Color multiresolution result')],
                 'blend_'+ident+'_overview',3,(350,265))
        attribution=(' Derived from Gregory H. Revera’s Moon photograph, CC BY-SA 3.0; this adapted figure is available under the same license.' if 'moon' in ident else '')
        figs.append(describe(fig,cfg['title']+': both custom blends use a nonrectangular mask and three color channels. The object is scaled/placed first. The source canvas uses the destination beyond the object disk, avoiding a black rectangular background in coarse levels.'+attribution))
        maskfig=grid([(m,f'M{i}: '+('binary mask' if i==0 else f'sigma={cfg["base_sigma"]*2**(i-1):g} px')) for i,m in enumerate(details['gm'])],
                      'blend_'+ident+'_maskstack',len(details['gm']),(210,180))
        figs.append(describe(maskfig,cfg['title']+': the initial curved selection becomes smoother at coarser scales. The complete stack includes the residual weight.'))
        record=dict(cfg,placement_matrix=matrix.tolist(),clip_fraction=clip_fraction(final),
                    range=[float(final.min()),float(final.max())],
                    reconstruction_error=float(np.max(np.abs(reconstruct(details['sum'])-final))),
                    final=finalpath,mask_area_pixels=int(mask.sum()))
        if ident=='earth_coffee':
            process,scales=contribution_figure(details,'blend_earth_coffee_process',(0,1,3))
            figs.append(describe(process,'Favorite custom blend, A world in a cup: masked object/source contribution, masked destination contribution and their sum at detail levels 0, 1 and 3; the final row sums ALL detail bands and the coarse residual. This follows the multiscale contribution idea of Burt–Adelson Figure 10. Each detail row uses a common symmetric scale; reconstructed rows use actual intensity.'))
            record['process_shared_row_scales']=scales
        metrics.append(record)
        tables.append([cfg['title'],f'{h} x {w}',str(cfg['target_center']),str(cfg['mask_radii']),
                       str(cfg['bands']),str(cfg['base_sigma']),f'{100*clip_fraction(final):.2f}%'])
    figs.append(describe(grid(color_items,'blend_color_comparison',2,(480,320)),
        'Controlled grayscale-versus-RGB comparison for both custom blends. The grayscale version applies the same stack, mask and placement to luminance inputs; only the presence of color changes.'))
    sec=section('blend-custom','Two custom color blends · Curved masks',[
        'A world in a cup maps NASA’s Earth photograph onto the elliptical coffee surface. Horizontal and vertical scaling are deliberately different to approximate the cup’s viewing angle. The Earth is an imaginative replacement for the crema; the blend adjusts color and low-frequency shading near its elliptical boundary while preserving the continent and cloud texture.',
        'Moon over the launch pad places a full Moon in the open sky beside the rocket. Its circular mask follows the limb. This is a creative composite: scale and placement are artistic choices rather than an astronomical claim. A smaller maximum blur than in the 512-pixel oraple limits how far brightness spreads around this small inserted object.',
        'Both masks have curved boundaries (an ellipse and a circle), satisfying the nonrectangular-mask requirement for both custom examples. The saved configuration exposes the source and target centers, radii, number of detail bands and base sigma. Each blend uses four detail bands at sigma 1.5, 3, 6 and 12 pixels plus the coarse residual, and all RGB channels are processed independently.',
        'For clean placement, the registered source canvas contains the object within its full disk and copies the destination outside that disk. The selection mask is slightly inside the visible disk. This preprocessing avoids blending a black rectangular photo background; the numerical multiresolution method itself is unchanged. The figures show this canvas explicitly so the operation is reproducible.',
        'Color adds useful semantic contrast in the coffee composite: the blue oceans and white clouds remain distinct from the warm brown cup and crema. The grayscale version keeps the cloud texture but makes the Earth resemble a mottled liquid surface. In the rocket scene the Moon itself is nearly neutral; color mainly preserves the cool sky and warm launch-pad lights. I prefer RGB for both finished blends because those contextual colors support the scene without changing the blending algorithm.',
        'The principal limitation is physical consistency: multiresolution blending smooths intensity transitions but cannot synthesize correct reflections, shadows or perspective. The coffee example benefits from an elliptical warp, while the Moon retains a sharper natural limb. All arithmetic remains signed float64 until final display clipping.'],figs,[{'title':'Custom-blend configuration','columns':['Blend','shape H x W','center x,y','mask radii x,y','detail bands','base sigma','values clipped'],'rows':tables}])
    return sec,metrics


def validation():
    rng=np.random.default_rng(671)
    a=rng.random((37,43,3)); b=rng.random((37,43,3))
    m=disk_mask(a.shape[:2],(21,18),(13,11))
    same,_=multiresolution_blend(a,a,m)
    all_a,_=multiresolution_blend(a,b,np.ones_like(m))
    all_b,_=multiresolution_blend(a,b,np.zeros_like(m))
    ab,_=multiresolution_blend(a,b,m)
    ba,_=multiresolution_blend(b,a,1-m)
    metrics={'same_image_max_abs_error':float(np.max(np.abs(same-a))),
             'all_white_mask_max_abs_error':float(np.max(np.abs(all_a-a))),
             'all_black_mask_max_abs_error':float(np.max(np.abs(all_b-b))),
             'complementary_mask_symmetry_max_abs_error':float(np.max(np.abs(ab-ba)))}
    assert max(metrics.values())<1e-12,metrics
    return metrics


def main():
    config=json.loads((ROOT/'frequencies_config.json').read_text())
    sections,hybrids=make_hybrids(config)
    stacksecs,stacks=make_stacks_and_oraple(config)
    sections.extend(stacksecs)
    custom,blends=make_custom_blends(config); sections.append(custom)
    result={'sections':sections,'measurements':{'hybrids':hybrids,'stacks':stacks,'blends':blends},
            'validation':validation(),
            'reproduce':'python run_frequencies.py',
            'config':'frequencies_config.json',
            'implementation':'src/frequencies.py'}
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/frequencies.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Saved results/frequencies.json',flush=True)

if __name__=='__main__':
    main()
