#!/usr/bin/env python3
"""Generate all Part 2.2-2.4 results from frequencies_config.json."""
import json
import numpy as np
import cv2
from src.frequencies import multiresolution_blend, reconstruct, disk_mask, clip_fraction
from src.report_figures import ROOT, read, grid, describe, contribution_figure, save, section
from src.hybrid_report import make_hybrids
from src.blend_report import make_custom_blends

def make_stacks_and_oraple(config):
    print('Stacks and oraple',flush=True)
    cfg=config['oraple']
    a=read(cfg['apple_path']); b=read(cfg['orange_path'])
    source_shape=list(a.shape)
    if a.shape != b.shape:
        raise ValueError('Course apple and orange inputs must have matching dimensions')
    width=int(cfg['width'])
    if width < 2:
        raise ValueError('Oraple working width must be at least two pixels')
    height=max(1,round(a.shape[0]*width/a.shape[1]))
    a=cv2.resize(a,(width,height),interpolation=cv2.INTER_AREA)
    b=cv2.resize(b,(width,height),interpolation=cv2.INTER_AREA)
    n=config['stack']['bands']; sigma=config['stack']['base_sigma']
    seam=width//2
    mask=np.zeros(a.shape[:2]); mask[:,:seam]=1
    final,details=multiresolution_blend(a,b,mask,n,sigma)
    stack_figs=[]
    for key,label in [('a','Apple'),('b','Orange')]:
        gs=details['g'+key]; ls=details['l'+key]
        items=[(g,f'G{i}: '+('original' if i==0 else f'sigma={sigma*2**(i-1):g} px')) for i,g in enumerate(gs)]
        for i,l in enumerate(ls):
            view= l if i==n else .5+2.5*l
            items.append((view,f'L{i}: '+('coarse residual' if i==n else f'G{i} - G{i+1}')))
        stack_figs.append(describe(grid(items,'stacks_'+label.lower(),6,(200,145)),
            label+f': Gaussian stack above and Laplacian stack below, including the coarse residual. Every level retains the working resolution of {width} × {height} pixels. Signed detail bands use 0.5 + 2.5L for display; the residual uses its actual intensity.'))
    maskfig=grid([(g,f'Gaussian mask M{i}') for i,g in enumerate(details['gm'])],'stacks_mask',6,(200,145))
    stack_figs.append(describe(maskfig,'Gaussian stack of the left/right selection mask, using the same scales as the image stacks. The transition widens at coarser levels. White selects apple and black selects orange.'))
    process,scales=contribution_figure(details,'stacks_oraple_figure342',(0,2,4))
    stack_figs.append(describe(process,'Figure 3.42 (a)–(l) layout: rows 1–3 show levels 0, 2, and 4; columns show the masked apple, masked orange, and their sum. Row 4 sums all five detail bands and the coarse residual to reconstruct the two contributions and final oraple. Detail bands share a symmetric display scale within each row; reconstructed images use actual [0, 1] intensity.'))
    hard=mask[...,None]*a+(1-mask[...,None])*b
    comparison=grid([(a,'Apple input'),(b,'Orange input'),(mask,'Binary seam mask'),(hard,'Direct hard seam'),(final,'Multiresolution blend')],'blend_oraple_comparison',5,(240,180))
    save(final,'blend_oraple_final')
    metric={
        'apple_path':cfg['apple_path'],'orange_path':cfg['orange_path'],
        'source_shape':source_shape,'working_width':width,'seam_column':seam,
        'apple_reconstruction_max_abs_error':float(np.max(np.abs(reconstruct(details['la'])-a))),
        'orange_reconstruction_max_abs_error':float(np.max(np.abs(reconstruct(details['lb'])-b))),
        'final_decomposition_max_abs_error':float(np.max(np.abs(reconstruct(details['sum'])-final))),
        'stack_shape':list(a.shape),'bands':n,'coarse_sigma':sigma*2**(n-1),
        'clip_fraction':clip_fraction(final),'range':[float(final.min()),float(final.max())],
        'figure342_shared_row_scales':scales,
        'mean_boundary_jump_hard':float(np.mean(np.abs(hard[:,seam]-hard[:,seam-1]))),
        'mean_boundary_jump_blend':float(np.mean(np.abs(final[:,seam]-final[:,seam-1])))}
    stacks=section('part23','2.3 · Gaussian and Laplacian stacks',[
        f'The supplied apple and orange images are burt_apple.png and burt_orange.png. Each {source_shape[1]} × {source_shape[0]} input is resized once to a common working size of {width} × {height} pixels using area interpolation. This reduces the computational cost while preserving the original aspect ratio to the nearest output pixel.',
        'A Gaussian stack retains the same image dimensions at every level. G0 = I is the original image; G1 through G5 are formed by independently blurring I at σ = 2, 4, 8, 16, and 32 pixels. Each σ therefore describes the smoothing relative to the original image. The stack is constructed explicitly without downsampling or a built-in pyramid routine.',
        'The Laplacian detail bands are Li = Gi − G(i+1) for i = 0, …, 4, and L5 = G5 is the coarse residual. Summing the detail bands gives I − G5; including the residual restores the large-scale brightness and color. The complete sum reconstructs I up to floating-point rounding. The table reports the reconstruction error for each input and for the blended image.',
        'A binary mask selects apple on the left and orange on the right. Its Gaussian stack uses the same smoothing scales as the image stacks. At level i, Mi is the mask and LAi and LBi are the apple and orange Laplacian bands; the combined band is Si = Mi LAi + (1 − Mi) LBi. This expression also applies to the coarse residual, and summing all Si gives the final image.',
        'The mask has a sharp transition at the finest level and progressively wider transitions at coarser levels. Fine texture and broad changes in brightness and color are therefore blended over different spatial ranges. The contribution figure shows selected detail levels and the complete reconstruction.'],stack_figs,[{'title':'Reconstruction accuracy','columns':['Comparison','Maximum absolute error'],'rows':[
            ['Apple reconstruction',f'{metric["apple_reconstruction_max_abs_error"]:.3e}'],['Orange reconstruction',f'{metric["orange_reconstruction_max_abs_error"]:.3e}'],['Final image vs. sum of mixed bands',f'{metric["final_decomposition_max_abs_error"]:.3e}']]}],
        [{'title':'Stack construction and reconstruction','text':'G = [I] + [gaussian(I, 2 * 2**i) for i in range(5)]\nL = [G[i] - G[i+1] for i in range(5)] + [G[-1]]\nS = [M[i] * LA[i] + (1-M[i]) * LB[i] for i in range(6)]\nresult = sum(S)'}],paragraph_headings={0:'Input preparation',1:'Gaussian and Laplacian decomposition',3:'Mask and reconstruction'})
    blends=section('part24','2.4 · Multiresolution blending',[
        'The apple and orange are combined using the same inputs and initial selection mask for both methods. A direct binary cut produces a visible vertical change in brightness and color. Multiresolution blending combines corresponding Laplacian bands with Gaussian mask weights, spreading the transition according to scale while retaining local texture.',
        f'The mean absolute RGB difference between the columns adjoining the seam decreases from {metric["mean_boundary_jump_hard"]:.4f} for the binary cut to {metric["mean_boundary_jump_blend"]:.4f} for the multiresolution blend. This local measurement is consistent with the smoother visible transition. It describes the seam discontinuity rather than overall perceptual quality.',
        f'The seam measurement uses the floating-point reconstruction before clipping. Values remain unclipped throughout stack construction and reconstruction, then are limited to [0, 1] for display export. This affects {100*metric["clip_fraction"]:.2f}% of scalar RGB values.'],[describe(comparison,f'Supplied inputs, selection mask, direct binary cut, and multiresolution oraple. Both methods use the same {width} × {height} images with preserved aspect ratio. The seam lies between zero-based columns {seam-1} and {seam}.')],paragraph_headings={0:'Comparison and results'})
    return [stacks,blends],metric



def validation():
    rng=np.random.default_rng(671)
    a=rng.random((37,43,3)); b=rng.random((37,43,3))
    m=disk_mask(a.shape[:2],(21,18),(13,11))
    same,_=multiresolution_blend(a,a,m)
    all_a,_=multiresolution_blend(a,b,np.ones_like(m))
    all_b,_=multiresolution_blend(a,b,np.zeros_like(m))
    ab,_=multiresolution_blend(a,b,m)
    ba,_=multiresolution_blend(b,a,1-m)
    metrics={'same_image_max_abs_error':float(np.max(np.abs(same-a))),
             'all_white_mask_max_abs_error':float(np.max(np.abs(all_a-a))),
             'all_black_mask_max_abs_error':float(np.max(np.abs(all_b-b))),
             'complementary_mask_symmetry_max_abs_error':float(np.max(np.abs(ab-ba)))}
    assert max(metrics.values())<1e-12,metrics
    return metrics



def main():
    config=json.loads((ROOT/'frequencies_config.json').read_text())
    sections,hybrids=make_hybrids(config)
    stacksecs,stacks=make_stacks_and_oraple(config)
    sections.extend(stacksecs)
    custom,blends=make_custom_blends(config); sections.append(custom)
    result={'sections':sections,'measurements':{'hybrids':hybrids,'stacks':stacks,'blends':blends},
            'validation':validation(),
            'reproduce':'python run_frequencies.py',
            'config':'frequencies_config.json',
            'implementation':'src/frequencies.py'}
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/frequencies.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Saved results/frequencies.json',flush=True)
    # The audit derives comparison metrics and a reconstruction trace from the
    # same source arrays and settings, without changing the experiments.
    from run_audit import main as generate_audit
    generate_audit(config=config, saved=result)


if __name__ == '__main__':
    main()
