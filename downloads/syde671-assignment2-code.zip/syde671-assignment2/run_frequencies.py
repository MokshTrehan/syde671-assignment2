#!/usr/bin/env python3
"""Generate all Part 2.2-2.4 results from frequencies_config.json."""
import json
import numpy as np
import cv2
from src.frequencies import multiresolution_blend, reconstruct, disk_mask, clip_fraction
from src.report_figures import ROOT, read, grid, describe, contribution_figure, save, section
from src.hybrid_report import make_hybrids
from src.blend_report import make_custom_blends

def make_stacks_and_oraple(config):
    print('Stacks and oraple',flush=True)
    cfg=config['oraple']
    a=read(cfg['apple_path']); b=read(cfg['orange_path'])
    source_shape=list(a.shape)
    if a.shape != b.shape:
        raise ValueError('Course apple and orange inputs must have matching dimensions')
    width=int(cfg['width'])
    if width < 2:
        raise ValueError('Oraple working width must be at least two pixels')
    height=max(1,round(a.shape[0]*width/a.shape[1]))
    a=cv2.resize(a,(width,height),interpolation=cv2.INTER_AREA)
    b=cv2.resize(b,(width,height),interpolation=cv2.INTER_AREA)
    n=config['stack']['bands']; sigma=config['stack']['base_sigma']
    seam=width//2
    mask=np.zeros(a.shape[:2]); mask[:,:seam]=1
    final,details=multiresolution_blend(a,b,mask,n,sigma)
    stack_figs=[]
    for key,label in [('a','Apple'),('b','Orange')]:
        gs=details['g'+key]; ls=details['l'+key]
        items=[(g,f'G{i}: '+('original' if i==0 else f'sigma={sigma*2**(i-1):g} px')) for i,g in enumerate(gs)]
        for i,l in enumerate(ls):
            view= l if i==n else .5+2.5*l
            items.append((view,f'L{i}: '+('coarse residual' if i==n else f'G{i} - G{i+1}')))
        stack_figs.append(describe(grid(items,'stacks_'+label.lower(),6,(200,145)),
            label+f': full-resolution Gaussian stack (top) and Laplacian stack (bottom), including the coarse residual. All six arrays preserve the working resolution of {width} x {height} pixels (width x height). Signed bands use 0.5 + 2.5L for display; the residual uses its actual intensity.'))
    maskfig=grid([(g,f'Gaussian mask M{i}') for i,g in enumerate(details['gm'])],'stacks_mask',6,(200,145))
    stack_figs.append(describe(maskfig,'The binary left/right mask is blurred at exactly the Gaussian image-stack scales. Fine bands use a sharp transition; coarser bands mix over progressively wider neighborhoods. White selects apple, black selects orange.'))
    process,scales=contribution_figure(details,'stacks_oraple_figure342',(0,2,4))
    stack_figs.append(describe(process,'Reproduction of the Figure 3.42 (a)–(l) layout: rows 1–3 show levels 0, 2 and 4, with masked apple, masked orange and their sum in the three columns. Row 4 reconstructs each contribution and the final oraple by summing ALL five detail bands plus the coarse residual. Detail displays share a symmetric contrast scale across each row; row 4 is shown in actual [0,1] intensity.'))
    hard=mask[...,None]*a+(1-mask[...,None])*b
    comparison=grid([(a,'Apple input'),(b,'Orange input'),(mask,'Binary seam mask'),(hard,'Direct hard seam'),(final,'Multiresolution blend')],'blend_oraple_comparison',5,(240,180))
    save(final,'blend_oraple_final')
    metric={
        'apple_path':cfg['apple_path'],'orange_path':cfg['orange_path'],
        'source_shape':source_shape,'working_width':width,'seam_column':seam,
        'apple_reconstruction_max_abs_error':float(np.max(np.abs(reconstruct(details['la'])-a))),
        'orange_reconstruction_max_abs_error':float(np.max(np.abs(reconstruct(details['lb'])-b))),
        'final_decomposition_max_abs_error':float(np.max(np.abs(reconstruct(details['sum'])-final))),
        'stack_shape':list(a.shape),'bands':n,'coarse_sigma':sigma*2**(n-1),
        'clip_fraction':clip_fraction(final),'range':[float(final.min()),float(final.max())],
        'figure342_shared_row_scales':scales,
        'mean_boundary_jump_hard':float(np.mean(np.abs(hard[:,seam]-hard[:,seam-1]))),
        'mean_boundary_jump_blend':float(np.mean(np.abs(final[:,seam]-final[:,seam-1])))}
    stacks=section('part23','2.3 · Gaussian and Laplacian stacks',[
        f'The apple and orange are the supplied course originals, burt_apple.png and burt_orange.png. Each {source_shape[1]} x {source_shape[0]} input is resized once to {width} x {height} pixels with area interpolation, retaining its aspect ratio to the nearest output pixel. This common working size keeps the experiment efficient without stretching the fruit into a square.',
        'A stack keeps every level at full resolution. I set G0 = I, then blur the original independently at sigma = 2, 4, 8, 16 and 32 pixels. The detail bands are Li = Gi - G(i+1) for i = 0,...,4; L5 = G5 is the coarse residual. Independent blurring makes the effective sigma of each level explicit. No downsampling occurs between stack levels, and no built-in pyramid routine is used.',
        'The residual is essential: summing only the detail bands would recover I - G5 and lose the large-scale brightness and color. With the residual, the sum telescopes exactly to I up to floating-point rounding. The apple and orange reconstruction errors are reported below.',
        'The mask follows the same Gaussian schedule. Each output level is Si = Mi LAi + (1 - Mi) LBi, including the residual level, and the final image is the sum of all Si. A is selected wherever the initial mask is white. This separates fine texture transitions from broad illumination and color transitions.'],stack_figs,[{'title':'Stack validation','columns':['Invariant','Maximum absolute error'],'rows':[
            ['Apple reconstruction',f'{metric["apple_reconstruction_max_abs_error"]:.3e}'],['Orange reconstruction',f'{metric["orange_reconstruction_max_abs_error"]:.3e}'],['Final equals sum of all mixed bands',f'{metric["final_decomposition_max_abs_error"]:.3e}']]}],
        [{'title':'Explicit stacks and reconstruction','text':'G = [I] + [gaussian(I, 2 * 2**i) for i in range(5)]\nL = [G[i] - G[i+1] for i in range(5)] + [G[-1]]\nS = [M[i] * LA[i] + (1-M[i]) * LB[i] for i in range(6)]\nresult = sum(S)'}])
    blends=section('part24','2.4 · Multiresolution blending',[
        'The standard apple/orange blend uses the apple on the left and the orange on the right. A direct binary cut preserves a conspicuous vertical brightness/color discontinuity; mixing corresponding Laplacian bands with Gaussian mask weights spreads that transition according to scale while retaining local texture.',
        f'For these inputs, the mean absolute RGB difference across the two columns adjoining the seam decreases from {metric["mean_boundary_jump_hard"]:.4f} to {metric["mean_boundary_jump_blend"]:.4f}. This local diagnostic supports the visible seam comparison; it is not a general perceptual-quality score.',
        f'The seam measurement is computed on the unclipped floating-point reconstruction. For display export only, values are clamped to [0,1]; {100*metric["clip_fraction"]:.2f}% of scalar RGB values require this clamp. No clipping occurs within the stack or before reconstruction.'],[describe(comparison,f'Course-provided inputs, selection mask, hard-cut baseline and full-color multiresolution oraple. Both baselines use the same aspect-preserving {width} x {height} input images and the same initial mask; the seam is between columns {seam-1} and {seam} (zero-based).')])
    return [stacks,blends],metric



def validation():
    rng=np.random.default_rng(671)
    a=rng.random((37,43,3)); b=rng.random((37,43,3))
    m=disk_mask(a.shape[:2],(21,18),(13,11))
    same,_=multiresolution_blend(a,a,m)
    all_a,_=multiresolution_blend(a,b,np.ones_like(m))
    all_b,_=multiresolution_blend(a,b,np.zeros_like(m))
    ab,_=multiresolution_blend(a,b,m)
    ba,_=multiresolution_blend(b,a,1-m)
    metrics={'same_image_max_abs_error':float(np.max(np.abs(same-a))),
             'all_white_mask_max_abs_error':float(np.max(np.abs(all_a-a))),
             'all_black_mask_max_abs_error':float(np.max(np.abs(all_b-b))),
             'complementary_mask_symmetry_max_abs_error':float(np.max(np.abs(ab-ba)))}
    assert max(metrics.values())<1e-12,metrics
    return metrics



def main():
    config=json.loads((ROOT/'frequencies_config.json').read_text())
    sections,hybrids=make_hybrids(config)
    stacksecs,stacks=make_stacks_and_oraple(config)
    sections.extend(stacksecs)
    custom,blends=make_custom_blends(config); sections.append(custom)
    result={'sections':sections,'measurements':{'hybrids':hybrids,'stacks':stacks,'blends':blends},
            'validation':validation(),
            'reproduce':'python run_frequencies.py',
            'config':'frequencies_config.json',
            'implementation':'src/frequencies.py'}
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/frequencies.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Saved results/frequencies.json',flush=True)


if __name__ == '__main__':
    main()
