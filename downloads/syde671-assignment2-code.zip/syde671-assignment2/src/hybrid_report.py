"""Hybrid-image experiments and report figures, with explicit scale comparisons."""
import numpy as np
from PIL import Image, ImageDraw, ImageOps
from .frequencies import gaussian, grayscale, rgb, align, hybrid, clip_fraction
from .report_figures import font, read, pil, save, grid, mark, near_far, describe, section, BG


FAVORITE = 'astronaut_chelsea'  # Stable artifact identifier; source is portrait_cat.jpg.
BASELINE = (10, 5, 1)


def _figure(path, caption, heading, supplement=False, group='hybrids'):
    return dict(describe(path, caption), heading=heading,
                supplement=supplement, group=group)


def _band_ratio(low, high, size):
    """Diagnostic band-contrast ratio, not a perceptual identity score.

    Lanczos operates on signed float luminance; no clipping/8-bit conversion is
    used here. This matches the display reduction filter but analyzes the bands.
    """
    bands=[]
    for a in (low, high):
        a=grayscale(a)
        if a.shape != (size,size):
            a=np.asarray(Image.fromarray(a.astype(np.float32)).resize(
                (size,size),Image.Resampling.LANCZOS),dtype=float)
        bands.append(a)
    return float(np.std(bands[1])/max(np.std(bands[0]),1e-12))


def _comparison_card(raw_a, raw_b, result, ident):
    """Two complete originals plus the hybrid at large and reduced sizes."""
    canvas=Image.new('RGB',(1056,574),BG); draw=ImageDraw.Draw(canvas)
    for image,x,label in [(raw_a,16,'Original low source'),(raw_b,256,'Original high source')]:
        thumb=ImageOps.contain(pil(image),(224,280),Image.Resampling.LANCZOS)
        canvas.paste(thumb,(x+(224-thumb.width)//2,16+(280-thumb.height)//2))
        draw.text((x,307),label,font=font(17),fill=(31,40,49))
    im=pil(result)
    canvas.paste(im,(528,16))
    draw.text((528,540),'Hybrid / 512 px',font=font(17),fill=(31,40,49))
    for size,x,y in [(128,56,365),(64,306,397)]:
        canvas.paste(im.resize((size,size),Image.Resampling.LANCZOS),(x,y))
        draw.text((x,y+size+10),f'{size} px',font=font(17),fill=(31,40,49))
    return save(canvas,'hybrid_'+ident+'_summary')


def refinement_comparison(raw_a, a, b, cfg):
    """Separate the effects of geometry and filtering using four saved controls."""
    reference=cfg['refinement_baseline']
    eye_aligned,_=align(raw_a,cfg['low_points'],cfg['target_points'],cfg['shape'])
    original=[reference[k] for k in ('sigma_low','sigma_high','gain')]
    selected=[cfg[k] for k in ('sigma_low','sigma_high','gain')]
    trials=[('Common eye targets / reference filters',eye_aligned,original,cfg['target_points']),
            ('Common eye targets / selected filters',eye_aligned,selected,cfg['target_points']),
            ('Refined geometry / reference filters',a,original,cfg['low_target_points']),
            ('Refined geometry / selected filters',a,selected,cfg['low_target_points'])]
    width,height=744,596
    canvas=Image.new('RGB',(2*width,2*height),BG); draw=ImageDraw.Draw(canvas)
    records=[]
    for i,(label,low_source,settings,targets) in enumerate(trials):
        result,_,_=hybrid(low_source,b,*settings,cfg['low_color'],cfg['high_color'])
        im=pil(result); x=(i%2)*width; y=(i//2)*height
        draw.text((x+16,y+12),label,font=font(20),fill=(31,40,49))
        canvas.paste(im,(x+16,y+46))
        for size,offset in [(128,96),(64,310)]:
            canvas.paste(im.resize((size,size),Image.Resampling.LANCZOS),(x+552,y+offset))
            draw.text((x+552,y+offset+size+8),f'{size} px',font=font(17),fill=(31,40,49))
        sl,sh,gain=settings
        draw.text((x+16,y+566),f'512 px | low {sl:g}, high {sh:g}, gain {gain:g} | clipped {100*clip_fraction(result):.2f}%',font=font(17),fill=(31,40,49))
        records.append(dict(label=label,sigma_low=sl,sigma_high=sh,gain=gain,
                            low_target_points=targets,clip_fraction=clip_fraction(result)))
    return save(canvas,'hybrid_'+cfg['id']+'_refinement'),records


def hybrid_experiments(a,b,cfg):
    """Render the actual cutoff/gain trials, at identical two display sizes."""
    chosen=(cfg['sigma_low'],cfg['sigma_high'],cfg['gain'])
    trials=[tuple(p) for p in cfg.get('trial_settings',[
        BASELINE,(6,1.5,1),(14,1.5,chosen[2]),
        (6,5,chosen[2]),(6,1,4),chosen])]
    if chosen not in trials:
        trials.append(chosen)
    lows={s:gaussian(rgb(grayscale(a)),s) for s in {x[0] for x in trials}}
    highs={s:rgb(grayscale(b))-gaussian(rgb(grayscale(b)),s) for s in {x[1] for x in trials}}
    cols=3; cellw=344; cellh=332
    canvas=Image.new('RGB',(cols*cellw+16,((len(trials)+cols-1)//cols)*cellh+16),BG)
    draw=ImageDraw.Draw(canvas); records=[]
    for i,(sl,sh,gain) in enumerate(trials):
        low=lows[sl]; high=gain*highs[sh]; result=low+high
        x=16+(i%cols)*cellw; y=16+(i//cols)*cellh
        im=pil(result)
        canvas.paste(im.resize((256,256),Image.Resampling.LANCZOS),(x,y))
        canvas.paste(im.resize((64,64),Image.Resampling.LANCZOS),(x+264,y+96))
        selected=(sl,sh,gain)==chosen
        draw.text((x,y+267),f'low {sl:g} / high {sh:g} / gain {gain:g}',font=font(17),fill=(31,40,49))
        suffix='SELECTED' if selected else ('wide-band baseline' if (sl,sh,gain)==BASELINE else 'comparison')
        draw.text((x,y+290),suffix,font=font(16),fill=(31,40,49))
        draw.text((x,y+311),f'clipped {100*clip_fraction(result):.1f}%',font=font(15),fill=(60,68,74))
        records.append({'sigma_low':sl,'sigma_high':sh,'gain':gain,'selected':selected,
                        'clip_fraction':clip_fraction(result),
                        'high_to_low_contrast_ratio_512':_band_ratio(low,high,512),
                        'high_to_low_contrast_ratio_128':_band_ratio(low,high,128)})
    return save(canvas,'hybrid_'+cfg['id']+'_sweep'),records


def _fourier_figures(raw_a,raw_b,a,b,low,high,result,cfg):
    arrays=[raw_a,raw_b,a,b,low,high,result]
    spectra=[]
    for array in arrays:
        gray=grayscale(array)
        spectra.append(np.log1p(1e6*np.abs(np.fft.fftshift(np.fft.fft2(gray)))/gray.size))
    vmax=max(float(s.max()) for s in spectra)
    source_labels=['Original astronaut','Original portrait cat','Aligned astronaut','Aligned portrait cat']
    source_points=[cfg['low_points'],cfg['high_points'],
                   cfg.get('low_target_points',cfg['target_points']),
                   cfg.get('high_target_points',cfg['target_points'])]
    items=[(mark(array,pts),label) for array,pts,label in zip(arrays[:4],source_points,source_labels)]
    items += [(s/vmax,'Log Fourier: '+label) for s,label in zip(spectra[:4],source_labels)]
    sources=grid(items,'hybrid_fourier_sources',4,(280,280))
    process_labels=['Gaussian low pass','Gain-scaled signed high pass','Final hybrid']
    process=[(low,process_labels[0]),(.5+high,process_labels[1]),(result,process_labels[2])]
    process += [(s/vmax,'Log Fourier: '+label) for s,label in zip(spectra[4:],process_labels)]
    filtered=grid(process,'hybrid_fourier_process',3,(320,320))
    return sources,filtered,float(vmax)


def make_hybrids(config):
    primary=[]; extras=[]; data=[]; rows=[]; color_figs=[]
    favorite=None; pair_cards=[]
    for cfg in config['hybrids']:
        ident=cfg['id']; is_favorite=ident==FAVORITE
        optional=cfg.get('supplement',ident=='earth_moon')
        print('Hybrid:',ident,flush=True)
        raw_a=read(cfg['low_path']); raw_b=read(cfg['high_path'])
        low_targets=cfg.get('low_target_points',cfg['target_points'])
        high_targets=cfg.get('high_target_points',cfg['target_points'])
        a,ma=align(raw_a,cfg['low_points'],low_targets,cfg['shape'])
        b,mb=align(raw_b,cfg['high_points'],high_targets,cfg['shape'])
        result,low,high=hybrid(a,b,cfg['sigma_low'],cfg['sigma_high'],cfg['gain'],cfg['low_color'],cfg['high_color'])
        final=save(result,'hybrid_'+ident+'_final')
        distance=near_far(result,'hybrid_'+ident+'_distance')
        alignment=grid([(mark(raw_a,cfg['low_points']),'Original low source: landmarks'),
                        (mark(raw_b,cfg['high_points']),'Original high source: landmarks'),
                        (mark(a,low_targets),'Aligned low source: 512 x 512'),
                        (mark(b,high_targets),'Aligned high source: 512 x 512')],
                        'hybrid_'+ident+'_alignment',4,(260,280))
        comps=grid([(a,'Aligned low-frequency source'),(b,'Aligned high-frequency source'),
                    (low,'Gaussian low pass'),(.5+high,'Signed high pass: 0.5 + gain H'),
                    (result,'Hybrid = low + gain H')],
                   'hybrid_'+ident+'_components',5,(230,250))
        extras.extend([
            _figure(alignment,cfg['title']+': original and aligned images. Cyan circles mark the eye centers (or disk-limb landmarks) and their output positions.',cfg['title']+' · Image registration',True),
            _figure(comps,cfg['title']+f': sigma low = {cfg["sigma_low"]:g} px, sigma high = {cfg["sigma_high"]:g} px and gain = {cfg["gain"]:g}. The signed high-pass display is shifted by 0.5 but receives no additional display amplification.',cfg['title']+' — component detail',True)])
        refinement_records=[]
        if cfg.get('refinement_baseline'):
            refinement_path,refinement_records=refinement_comparison(raw_a,a,b,cfg)
            extras.append(_figure(refinement_path,
                cfg['title']+': a two-by-two comparison of the initial and refined human alignment, each with the reference and selected filter settings. Every result appears at 512, 128 and 64 pixels with the same clipping and Lanczos reduction. The photographs and cat alignment remain fixed.',
                cfg['title']+' · Alignment and filter comparison',True))
        trial_records=[]
        if not optional:
            trialpath,trial_records=hybrid_experiments(a,b,cfg)
            trialfig=_figure(trialpath,
                cfg['title']+': filter-width and gain trials, synthesized at 512 x 512 and displayed at 256 and 64 pixels. The selected panel uses the final settings. Alignment remains fixed across the trials.',
                'Filter widths and detail gain' if is_favorite else cfg['title']+' · Filter and gain comparison',not is_favorite)
            (primary if is_favorite else extras).append(trialfig)
        if is_favorite:
            primary.insert(0,_figure(distance,
                cfg['title']+': the same hybrid at 512, 256, 128 and 64 pixels, reduced with Lanczos. '+cfg['selection_note'],
                'Hybrid appearance at different display sizes'))
            favorite=(raw_a,raw_b,a,b,low,high,result,cfg)
            colors=[]
            for lc,hc,label in [(False,False,'Neither in color'),(True,False,'Low source in color'),(False,True,'High source in color'),(True,True,'Both in color')]:
                image,_,_=hybrid(a,b,cfg['sigma_low'],cfg['sigma_high'],cfg['gain'],lc,hc)
                colors.append((image,label))
            color_figs.append(_figure(grid(colors,'hybrid_color_comparison',4,(280,280)),
                'Four color variants with identical alignment, filter widths and gain. Luminance conversion uses weights 0.2126, 0.7152 and 0.0722. Color in the low-frequency source preserves broad skin and hair regions; color in the high-frequency source remains mainly around cat edges and fur.',
                'Color by frequency band'))
        else:
            summary=_comparison_card(raw_a,raw_b,result,ident)
            fig=_figure(summary,
                cfg['title']+': original sources and the final hybrid at 512, 128 and 64 pixels. '+cfg.get('selection_note','The shared circular outline and overlapping surface detail remain visible at each size. The subject does not change clearly with viewing scale.'),
                cfg['title'],optional)
            (extras if optional else pair_cards).append(fig)
            extras.append(_figure(distance,cfg['title']+': the same hybrid at four display sizes. Intermediate sizes retain features from both sources.',cfg['title']+' · Display-size comparison',True))
        f_low=np.sqrt(2*np.log(2))/(2*np.pi*cfg['sigma_low'])
        f_high=np.sqrt(2*np.log(2))/(2*np.pi*cfg['sigma_high'])
        baseline,baseline_low,baseline_high=hybrid(a,b,*BASELINE,False,False)
        record=dict(cfg,low_matrix=ma.tolist(),high_matrix=mb.tolist(),
                    clip_fraction=clip_fraction(result),range=[float(result.min()),float(result.max())],
                    low_half_amplitude_cycles_per_pixel=float(f_low),
                    high_half_amplitude_cycles_per_pixel=float(f_high),
                    final=final,alignment=alignment,components=comps,near_far=distance,
                    trials=trial_records,refinement_trials=refinement_records,
                    band_contrast_diagnostic={'definition':'std(high luminance) / std(low luminance); signed float Lanczos reduction, no clipping. Not a perceptual score.',
                        'selected_512':_band_ratio(low,high,512),'selected_128':_band_ratio(low,high,128),
                        'baseline_512':_band_ratio(baseline_low,baseline_high,512),
                        'baseline_128':_band_ratio(baseline_low,baseline_high,128)})
        data.append(record)
        if not optional:
            rows.append([cfg['title'],f'{cfg["sigma_low"]:g}',f'{cfg["sigma_high"]:g}',
                         f'{cfg["gain"]:g}',f'{100*clip_fraction(result):.2f}%'])
    raw_a,raw_b,a,b,low,high,result,cfg=favorite
    sources,filtered,vmax=_fourier_figures(raw_a,raw_b,a,b,low,high,result,cfg)
    common='Both Fourier figures use the same logarithmic scale and display maximum.'
    primary.extend([
        _figure(sources,'Original and aligned astronaut and portrait-cat inputs. Cyan circles show the alignment landmarks; spectra are calculated from the unmarked images. '+common,
                'Original sources, alignment and Fourier spectra'),
        _figure(filtered,'The low-pass spectrum is concentrated near the center. The high-pass component suppresses central energy and retains fine detail. Adding the two components produces the hybrid; the signed high-pass component is displayed as 0.5 + gain H. '+common,
                'Filtered components and reconstruction')])
    primary.extend(pair_cards)
    favorite_record=next(d for d in data if d['id']==FAVORITE)
    favorite_record['fourier_common_display_max']=vmax
    required_records=[d for d in data if not d.get('supplement',False)]
    settings={d['id']:d for d in required_records}
    geometry_rows=[]
    for d in required_records:
        common=np.asarray(d['target_points'],dtype=float)
        human=np.asarray(d.get('low_target_points',d['target_points']),dtype=float)
        scale=np.linalg.norm(human[1]-human[0])/np.linalg.norm(common[1]-common[0])
        dy=float(human.mean(axis=0)[1]-common.mean(axis=0)[1])
        eyes='; '.join(f'({x:g}, {y:g})' for x,y in human)
        geometry_rows.append([d['title'],f'{scale:.2f}',f'{dy:g}',eyes])
    selected_text='; '.join(f'{d["title"]}: ({d["sigma_low"]:g}, {d["sigma_high"]:g}, {d["gain"]:g})'
                            for d in required_records)
    refinement=favorite_record['refinement_trials']
    clipping_text=(f'On refined geometry, changing from reference to selected filters changes clipping from '
                   f'{100*refinement[2]["clip_fraction"]:.2f}% to {100*refinement[3]["clip_fraction"]:.2f}%. '
                   f'With selected filters fixed, refining geometry changes clipping from '
                   f'{100*refinement[1]["clip_fraction"]:.2f}% to {100*refinement[3]["clip_fraction"]:.2f}%.')
    paragraphs=[
        'A hybrid image combines a blurred image with fine detail from a second, aligned image: hybrid = G_sigmaL * A + gain (B - G_sigmaH * B). G_sigma is a Gaussian kernel with standard deviation sigma, and * denotes convolution. A is the human portrait and B is the cat photograph. The three examples are Derek + Nutmeg and two custom portrait/cat pairs.',
        'The initial alignment maps both pairs of eye centers to (170,210) and (330,210). Each two-point similarity transform combines rotation, uniform scale and translation. Exact eye alignment leaves a separate human mouth or chin below the cat muzzle. The broad human smile remains in the low-frequency component, so increasing fur contrast alone does not remove it.',
        'Each human portrait is scaled about the common eye midpoint (250,210), then shifted vertically, while the cat remains fixed. Derek uses scale 0.70 and shift -12 pixels; the astronaut uses scale 0.70 with no vertical shift; Obama uses scale 0.80 and shift -20 pixels. Their exact output eye coordinates are recorded in the geometry table. This places the lower human face within the cat muzzle, at the cost of coincident eye landmarks.',
        'Each original is resampled once with the composed similarity transform, using bilinear interpolation and replicated borders. The face proportions are unchanged. The original landmarks and exact 2 x 3 transformation matrices are saved with the experiment records.',
        'A high-pass sigma of 1.5 or 2 pixels removes more broad cat shading than sigma 5, so less cat structure remains in the reduced views. The selected (low-pass sigma, high-pass sigma, gain) settings are '+selected_text+'. Larger low-pass widths soften the human teeth and chin while retaining broad facial structure.',
        'The six filter-width and gain trials keep the selected alignment fixed. Increasing the astronaut low-pass sigma to 18 blurs the eyes and smile in the reduced view. Increasing its high-pass sigma from 1.5 to 3 retains broader cat structure, which competes with the human face. The controlled comparisons vary alignment and filtering separately. These settings are selected visually for these particular inputs.',
        favorite_record['selection_note'],
        clipping_text+' The smaller human image reduces the separate lower mouth and chin, but displaces the eye landmarks. This is a visual tradeoff, not evidence of more accurate landmark registration. Intermediate views remain mixed.',
        'To inspect the effect, view the largest image at normal size and then move farther away, keeping its display size fixed. The reduced versions provide a second comparison. The apparent change depends on screen size, zoom and eyesight, so the pixel-size sequence does not establish a calibrated viewing distance.',
        f'A Gaussian has no sharp frequency cutoff. Its approximate half-amplitude frequency is sqrt(2 ln 2) / (2 pi sigma) cycles per output pixel. For the selected astronaut pair, this is {favorite_record["low_half_amplitude_cycles_per_pixel"]:.4f} for the low pass and {favorite_record["high_half_amplitude_cycles_per_pixel"]:.4f} for the complementary high pass. Filtering uses spatial convolution; the Fourier plots show the resulting frequency content.',
        'Each Fourier spectrum displays log(1 + 1000000 |fftshift(fft2(luminance))| / N), where N is the number of image pixels. Division by N permits comparison of differently sized inputs, and both figures use one shared display maximum. No window or mean subtraction is applied before the Fourier transform.',
        'Filtering uses reflected boundaries, and filtering and addition retain signed float64 values. Intermediate bands are neither clipped nor contrast-normalized. Display exports clamp values to [0,1] and quantize them to 8 bits; the table reports the fraction of scalar channel values clipped. Supplementary figures include the remaining alignment, component and parameter comparisons, together with the unsuccessful Earth + Moon hybrid.']
    sec=section('part22','2.2 · Hybrid images',paragraphs,primary+extras,
        [{'title':'Selected settings at 512 x 512 pixels','columns':['Pair','Low-pass sigma (px)','High-pass sigma (px)','Gain','Values clipped'],'rows':rows},
         {'title':'Human transform relative to the common eye alignment.','columns':['Pair','Scale','Vertical shift (px)','Human eye centers (px)'],'rows':geometry_rows}],
        [{'title':'Hybrid synthesis','text':'low = gaussian(A, sigma_low)\nhigh = B - gaussian(B, sigma_high)\nhybrid = low + gain * high'}],
        paragraph_headings={0:'Hybrid construction',1:'Image registration',4:'Filter settings',6:'Appearance at different scales',9:'Frequency analysis',11:'Numerical representation'})
    metadata_keys=('sigma_low','sigma_high','gain','target_points','low_target_points',
                   'high_target_points','low_half_amplitude_cycles_per_pixel',
                   'high_half_amplitude_cycles_per_pixel','selection_note')
    sec['hybrid_settings']={ident:{k:d[k] for k in metadata_keys if k in d}
                            for ident,d in settings.items()}
    color=section('hybrid-color','Color in hybrid images',[
        'Four variants retain color in neither source, only the low-frequency source, only the high-frequency source, or both. Color in the low-frequency source preserves the astronaut’s broad skin and hair regions. Color in the high-frequency source appears around fine cat edges, but the filtering removes the broad coat color.',
        'For this pair, color in the low-frequency source agrees with the face visible at smaller sizes, while grayscale fur remains visible at larger sizes. Retaining color in both sources adds competing hues around some cat edges. The main examples use grayscale so that the change in visible subject can be assessed without this broad color difference.'],color_figs)
    return [sec,color],data
