"""Hybrid-image experiments and report figures, with explicit scale comparisons."""
import numpy as np
from PIL import Image, ImageDraw, ImageOps
from .frequencies import gaussian, grayscale, rgb, align, hybrid, clip_fraction
from .report_figures import font, read, pil, save, grid, mark, near_far, describe, section, BG


FAVORITE = 'obama_biden'
GEOMETRY_EXAMPLE = 'derek_nutmeg'
BASELINE = (10, 5, 1)


def _figure(path, caption, heading, supplement=False, group='hybrids'):
    return dict(describe(path, caption), heading=heading,
                supplement=supplement, group=group)


def _band_ratio(low, high, size):
    """Diagnostic band-contrast ratio, not a perceptual identity score.

    Lanczos operates on signed float luminance; no clipping/8-bit conversion is
    used here. This matches the display reduction filter but analyzes the bands.
    """
    bands=[]
    for a in (low, high):
        a=grayscale(a)
        if a.shape != (size,size):
            a=np.asarray(Image.fromarray(a.astype(np.float32)).resize(
                (size,size),Image.Resampling.LANCZOS),dtype=float)
        bands.append(a)
    return float(np.std(bands[1])/max(np.std(bands[0]),1e-12))


def _comparison_card(raw_a, raw_b, result, ident):
    """Two complete originals plus the hybrid at large and reduced sizes."""
    canvas=Image.new('RGB',(1056,574),BG); draw=ImageDraw.Draw(canvas)
    for image,x,label in [(raw_a,16,'Original low source'),(raw_b,256,'Original high source')]:
        thumb=ImageOps.contain(pil(image),(224,280),Image.Resampling.LANCZOS)
        canvas.paste(thumb,(x+(224-thumb.width)//2,16+(280-thumb.height)//2))
        draw.text((x,307),label,font=font(17),fill=(31,40,49))
    im=pil(result)
    canvas.paste(im,(528,16))
    draw.text((528,540),'Hybrid / 512 px',font=font(17),fill=(31,40,49))
    reduced_views=[(128,56,365),(64,306,397)]
    if ident in (GEOMETRY_EXAMPLE, 'monroe_einstein'):
        reduced_views.append((32,420,413))
    for size,x,y in reduced_views:
        canvas.paste(im.resize((size,size),Image.Resampling.LANCZOS),(x,y))
        draw.text((x,y+size+10),f'{size} px',font=font(17),fill=(31,40,49))
    return save(canvas,'hybrid_'+ident+'_summary')


def refinement_comparison(raw_a, a, b, cfg):
    """Separate the effects of geometry and filtering using four saved controls."""
    reference=cfg['refinement_baseline']
    original=[reference[k] for k in ('sigma_low','sigma_high','gain')]
    selected=[cfg[k] for k in ('sigma_low','sigma_high','gain')]
    if cfg.get('geometry_reference'):
        reduced_targets=cfg['geometry_reference']['low_target_points']
        reduced,_=align(raw_a,cfg['low_points'],reduced_targets,cfg['shape'])
        trials=[('Reduced human / reference filters',reduced,original,reduced_targets,'reduced','reference'),
                ('Reduced human / selected filters',reduced,selected,reduced_targets,'reduced','selected'),
                ('Common eyes (selected) / reference filters',a,original,cfg['target_points'],'common','reference'),
                ('Common eyes (selected) / selected filters',a,selected,cfg['target_points'],'common','selected')]
    else:
        eye_aligned,_=align(raw_a,cfg['low_points'],cfg['target_points'],cfg['shape'])
        trials=[('Common eye targets / reference filters',eye_aligned,original,cfg['target_points'],'common','reference'),
                ('Common eye targets / selected filters',eye_aligned,selected,cfg['target_points'],'common','selected'),
                ('Refined geometry / reference filters',a,original,cfg['low_target_points'],'refined','reference'),
                ('Refined geometry / selected filters',a,selected,cfg['low_target_points'],'refined','selected')]
    width,height=744,596
    canvas=Image.new('RGB',(2*width,2*height),BG); draw=ImageDraw.Draw(canvas)
    records=[]
    for i,(label,low_source,settings,targets,geometry,filter_set) in enumerate(trials):
        result,_,_=hybrid(low_source,b,*settings,cfg['low_color'],cfg['high_color'])
        im=pil(result); x=(i%2)*width; y=(i//2)*height
        draw.text((x+16,y+12),label,font=font(20),fill=(31,40,49))
        canvas.paste(im,(x+16,y+46))
        for size,offset in [(128,96),(64,310)]:
            canvas.paste(im.resize((size,size),Image.Resampling.LANCZOS),(x+552,y+offset))
            draw.text((x+552,y+offset+size+8),f'{size} px',font=font(17),fill=(31,40,49))
        sl,sh,gain=settings
        draw.text((x+16,y+566),f'512 px | low {sl:g}, high {sh:g}, gain {gain:g} | clipped {100*clip_fraction(result):.2f}%',font=font(17),fill=(31,40,49))
        records.append(dict(label=label,sigma_low=sl,sigma_high=sh,gain=gain,
                            geometry=geometry,filter_set=filter_set,
                            low_target_points=targets,clip_fraction=clip_fraction(result)))
    return save(canvas,'hybrid_'+cfg['id']+'_refinement'),records


def framing_comparison(raw_a, raw_b, selected_result, cfg):
    """Compare saved and selected framing with the same output-pixel filters.

    Both original sources are sampled directly with their composed transforms;
    this comparison never crops or resamples an already synthesized hybrid.
    """
    baseline=cfg['framing_baseline']
    common=baseline['target_points']
    a,_=align(raw_a,cfg['low_points'],baseline.get('low_target_points',common),cfg['shape'],
              horizontal_flip=cfg.get('low_horizontal_flip',False))
    b,_=align(raw_b,cfg['high_points'],baseline.get('high_target_points',common),cfg['shape'],
              horizontal_flip=cfg.get('high_horizontal_flip',False))
    old_result,_,_=hybrid(a,b,cfg['sigma_low'],cfg['sigma_high'],cfg['gain'],
                          cfg['low_color'],cfg['high_color'])
    width,height=744,596
    canvas=Image.new('RGB',(2*width,height),BG); draw=ImageDraw.Draw(canvas)
    for i,(label,result) in enumerate([('Previous framing',old_result),
                                       ('Selected shared framing',selected_result)]):
        x=i*width; im=pil(result)
        draw.text((x+16,12),label,font=font(20),fill=(31,40,49))
        canvas.paste(im,(x+16,46))
        for size,y in [(128,96),(64,310)]:
            canvas.paste(im.resize((size,size),Image.Resampling.LANCZOS),(x+552,y))
            draw.text((x+552,y+size+8),f'{size} px',font=font(17),fill=(31,40,49))
        draw.text((x+16,566),
                  f'512 px | low {cfg["sigma_low"]:g}, high {cfg["sigma_high"]:g}, gain {cfg["gain"]:g}',
                  font=font(17),fill=(31,40,49))
    return save(canvas,'hybrid_'+cfg['id']+'_framing')


def reflection_comparison(a, raw_b, selected_result, cfg):
    """Isolate horizontal reflection at fixed eye targets and filter settings."""
    unflipped_b,_=align(raw_b,cfg['high_points'],
                       cfg.get('high_target_points',cfg['target_points']),cfg['shape'])
    unflipped,_,_=hybrid(a,unflipped_b,cfg['sigma_low'],cfg['sigma_high'],
                         cfg['gain'],cfg['low_color'],cfg['high_color'])
    width,height=744,596
    canvas=Image.new('RGB',(2*width,height),BG); draw=ImageDraw.Draw(canvas)
    for i,(label,result) in enumerate([('Original Einstein orientation',unflipped),
                                       ('Mirrored Einstein (selected)',selected_result)]):
        x=i*width; im=pil(result)
        draw.text((x+16,12),label,font=font(20),fill=(31,40,49))
        canvas.paste(im,(x+16,46))
        for size,y in [(128,96),(64,310),(32,440)]:
            canvas.paste(im.resize((size,size),Image.Resampling.LANCZOS),(x+552,y))
            draw.text((x+552,y+size+8),f'{size} px',font=font(17),fill=(31,40,49))
        draw.text((x+16,566),
                  f'512 px | low {cfg["sigma_low"]:g}, high {cfg["sigma_high"]:g}, gain {cfg["gain"]:g}',
                  font=font(17),fill=(31,40,49))
    return save(canvas,'hybrid_'+cfg['id']+'_reflection')


def hybrid_experiments(a,b,cfg):
    """Render the actual cutoff/gain trials, at identical two display sizes."""
    chosen=(cfg['sigma_low'],cfg['sigma_high'],cfg['gain'])
    trials=[tuple(p) for p in cfg.get('trial_settings',[
        BASELINE,(6,1.5,1),(14,1.5,chosen[2]),
        (6,5,chosen[2]),(6,1,4),chosen])]
    if chosen not in trials:
        trials.append(chosen)
    lows={s:gaussian(rgb(grayscale(a)),s) for s in {x[0] for x in trials}}
    highs={s:rgb(grayscale(b))-gaussian(rgb(grayscale(b)),s) for s in {x[1] for x in trials}}
    cols=3; cellw=344; cellh=332
    canvas=Image.new('RGB',(cols*cellw+16,((len(trials)+cols-1)//cols)*cellh+16),BG)
    draw=ImageDraw.Draw(canvas); records=[]
    for i,(sl,sh,gain) in enumerate(trials):
        low=lows[sl]; high=gain*highs[sh]; result=low+high
        x=16+(i%cols)*cellw; y=16+(i//cols)*cellh
        im=pil(result)
        canvas.paste(im.resize((256,256),Image.Resampling.LANCZOS),(x,y))
        canvas.paste(im.resize((64,64),Image.Resampling.LANCZOS),(x+264,y+96))
        selected=(sl,sh,gain)==chosen
        draw.text((x,y+267),f'low {sl:g} / high {sh:g} / gain {gain:g}',font=font(17),fill=(31,40,49))
        suffix='SELECTED' if selected else ('wide-band baseline' if (sl,sh,gain)==BASELINE else 'comparison')
        draw.text((x,y+290),suffix,font=font(16),fill=(31,40,49))
        draw.text((x,y+311),f'clipped {100*clip_fraction(result):.1f}%',font=font(15),fill=(60,68,74))
        records.append({'sigma_low':sl,'sigma_high':sh,'gain':gain,'selected':selected,
                        'clip_fraction':clip_fraction(result),
                        'high_to_low_contrast_ratio_512':_band_ratio(low,high,512),
                        'high_to_low_contrast_ratio_128':_band_ratio(low,high,128)})
    return save(canvas,'hybrid_'+cfg['id']+'_sweep'),records


def _fourier_figures(raw_a,raw_b,a,b,low,high,result,cfg):
    arrays=[raw_a,raw_b,a,b,low,high,result]
    spectra=[]
    for array in arrays:
        gray=grayscale(array)
        spectra.append(np.log1p(1e6*np.abs(np.fft.fftshift(np.fft.fft2(gray)))/gray.size))
    vmax=max(float(s.max()) for s in spectra)
    low_label=cfg.get('low_label','low source'); high_label=cfg.get('high_label','high source')
    source_labels=[f'Original {low_label}',f'Original {high_label}',
                   f'Aligned {low_label}',f'Aligned {high_label}']
    source_points=[cfg['low_points'],cfg['high_points'],
                   cfg.get('low_target_points',cfg['target_points']),
                   cfg.get('high_target_points',cfg['target_points'])]
    items=[(mark(array,pts),label) for array,pts,label in zip(arrays[:4],source_points,source_labels)]
    items += [(s/vmax,'Log Fourier: '+label) for s,label in zip(spectra[:4],source_labels)]
    sources=grid(items,'hybrid_fourier_sources',4,(280,280))
    process_labels=['Gaussian low pass','Gain-scaled signed high pass','Final hybrid']
    process=[(low,process_labels[0]),(.5+high,process_labels[1]),(result,process_labels[2])]
    process += [(s/vmax,'Log Fourier: '+label) for s,label in zip(spectra[4:],process_labels)]
    filtered=grid(process,'hybrid_fourier_process',3,(320,320))
    return sources,filtered,float(vmax)


def make_hybrids(config):
    primary=[]; extras=[]; data=[]; rows=[]; color_figs=[]
    favorite=None; pair_cards=[]
    for cfg in config['hybrids']:
        ident=cfg['id']; is_favorite=ident==FAVORITE
        optional=cfg.get('supplement',ident=='earth_moon')
        print('Hybrid:',ident,flush=True)
        raw_a=read(cfg['low_path']); raw_b=read(cfg['high_path'])
        low_targets=cfg.get('low_target_points',cfg['target_points'])
        high_targets=cfg.get('high_target_points',cfg['target_points'])
        a,ma=align(raw_a,cfg['low_points'],low_targets,cfg['shape'],
                  horizontal_flip=cfg.get('low_horizontal_flip',False))
        b,mb=align(raw_b,cfg['high_points'],high_targets,cfg['shape'],
                  horizontal_flip=cfg.get('high_horizontal_flip',False))
        result,low,high=hybrid(a,b,cfg['sigma_low'],cfg['sigma_high'],cfg['gain'],cfg['low_color'],cfg['high_color'])
        final=save(result,'hybrid_'+ident+'_final')
        distance=near_far(result,'hybrid_'+ident+'_distance')
        alignment=grid([(mark(raw_a,cfg['low_points']),'Original low source: landmarks'),
                        (mark(raw_b,cfg['high_points']),'Original high source: landmarks'),
                        (mark(a,low_targets),'Aligned low source: 512 x 512'),
                        (mark(b,high_targets),'Aligned high source'+(' (flipped)' if cfg.get('high_horizontal_flip') else '')+': 512 x 512')],
                        'hybrid_'+ident+'_alignment',4,(260,280))
        comps=grid([(a,'Aligned low-frequency source'),(b,'Aligned high-frequency source'),
                    (low,'Gaussian low pass'),(.5+high,'Signed high pass: 0.5 + gain H'),
                    (result,'Hybrid = low + gain H')],
                   'hybrid_'+ident+'_components',5,(230,250))
        extras.extend([
            _figure(alignment,cfg['title']+': original and aligned images. Cyan circles mark the eye centers (or disk-limb landmarks) and their output positions.'+(' The high source is reflected horizontally, with left-to-right eye correspondence reversed before alignment.' if cfg.get('high_horizontal_flip') else ''),cfg['title']+' · Image registration',True),
            _figure(comps,cfg['title']+f': sigma low = {cfg["sigma_low"]:g} px, sigma high = {cfg["sigma_high"]:g} px and gain = {cfg["gain"]:g}. The signed high-pass display is shifted by 0.5 but receives no additional display amplification.',cfg['title']+' — component detail',True)])
        refinement_records=[]
        if ident == GEOMETRY_EXAMPLE:
            refinement_path,refinement_records=refinement_comparison(raw_a,a,b,cfg)
            geometry_caption=('a reduced-human alternative and selected common-eye alignment, each with reference and selected filter settings. The reduced alternative uses the same selected cat framing; it is not a reproduction of an earlier crop. '
                              if cfg.get('geometry_reference') else
                              'the initial and refined human alignment, each with the reference and selected filter settings. ')
            extras.append(_figure(refinement_path,
                cfg['title']+': a two-by-two comparison of '+geometry_caption+'Every result appears at 512, 128 and 64 pixels with the same clipping and Lanczos reduction. The photographs and cat alignment remain fixed.',
                cfg['title']+' · Alignment and filter comparison',True))
        if cfg.get('framing_baseline'):
            framing_path=framing_comparison(raw_a,raw_b,result,cfg)
            extras.append(_figure(framing_path,
                cfg['title']+': previous and selected shared framing at native 512 pixels, with 128- and 64-pixel Lanczos reductions. Each original is sampled once using its composed similarity transform. Output-pixel filter sigmas and gain remain fixed; the shared crop therefore changes the effective bandwidth relative to the original photographs. Framing reduces neck and shoulder context but does not match the subjects\' anatomy.',
                cfg['title']+' · Shared framing comparison',True))
        if cfg.get('high_horizontal_flip'):
            flip_path=reflection_comparison(a,raw_b,result,cfg)
            extras.append(_figure(flip_path,
                cfg['title']+': original and mirrored Einstein orientation at identical eye targets, filter widths and gain. Each uses a single warp of the original photograph; the mirror is composed with the similarity transform. Reflection improves the facing direction and cheek-shadow agreement but does not equalize mouth-to-eye distances.',
                cfg['title']+' · Horizontal reflection comparison',True))
        trial_records=[]
        if not optional:
            trialpath,trial_records=hybrid_experiments(a,b,cfg)
            trialfig=_figure(trialpath,
                cfg['title']+': filter-width and gain trials, synthesized at 512 x 512 and displayed at 256 and 64 pixels. The selected panel uses the final settings. Alignment remains fixed across the trials.',
                'Filter widths and detail gain' if is_favorite else cfg['title']+' · Filter and gain comparison',not is_favorite)
            (primary if is_favorite else extras).append(trialfig)
        if is_favorite:
            primary.insert(0,_figure(distance,
                cfg['title']+': the same hybrid at 512, 256, 128 and 64 pixels, reduced with Lanczos. '+cfg['selection_note'],
                'Hybrid appearance at different display sizes'))
            favorite=(raw_a,raw_b,a,b,low,high,result,cfg)
            colors=[]
            for lc,hc,label in [(False,False,'Neither in color'),(True,False,'Low source in color'),(False,True,'High source in color'),(True,True,'Both in color')]:
                image,_,_=hybrid(a,b,cfg['sigma_low'],cfg['sigma_high'],cfg['gain'],lc,hc)
                colors.append((image,label))
            color_figs.append(_figure(grid(colors,'hybrid_color_comparison',4,(280,280)),
                f'Four color variants of {cfg["title"]} with identical alignment, filter widths and gain. Luminance conversion uses weights 0.2126, 0.7152 and 0.0722. Low-frequency color preserves {cfg.get("low_label","the low source")}’s broad skin, hair and clothing regions; high-frequency color remains mainly around {cfg.get("high_label","the high source")}’s fine facial and hair edges.',
                'Color by frequency band'))
        else:
            summary=_comparison_card(raw_a,raw_b,result,ident)
            shown_sizes='512, 128, 64 and 32' if ident in (GEOMETRY_EXAMPLE, 'monroe_einstein') else '512, 128 and 64'
            fig=_figure(summary,
                cfg['title']+': original sources and the final hybrid at '+shown_sizes+' pixels. '+cfg.get('selection_note','The shared circular outline and overlapping surface detail remain visible at each size. The subject does not change clearly with viewing scale.'),
                cfg['title'],optional)
            (extras if optional else pair_cards).append(fig)
            extras.append(_figure(distance,cfg['title']+': the same hybrid at four display sizes. Intermediate sizes retain features from both sources.',cfg['title']+' · Display-size comparison',True))
        f_low=np.sqrt(2*np.log(2))/(2*np.pi*cfg['sigma_low'])
        f_high=np.sqrt(2*np.log(2))/(2*np.pi*cfg['sigma_high'])
        baseline,baseline_low,baseline_high=hybrid(a,b,*BASELINE,False,False)
        record=dict(cfg,low_matrix=ma.tolist(),high_matrix=mb.tolist(),
                    clip_fraction=clip_fraction(result),range=[float(result.min()),float(result.max())],
                    low_half_amplitude_cycles_per_pixel=float(f_low),
                    high_half_amplitude_cycles_per_pixel=float(f_high),
                    final=final,alignment=alignment,components=comps,near_far=distance,
                    trials=trial_records,refinement_trials=refinement_records,
                    band_contrast_diagnostic={'definition':'std(high luminance) / std(low luminance); signed float Lanczos reduction, no clipping. Not a perceptual score.',
                        'selected_512':_band_ratio(low,high,512),'selected_128':_band_ratio(low,high,128),
                        'baseline_512':_band_ratio(baseline_low,baseline_high,512),
                        'baseline_128':_band_ratio(baseline_low,baseline_high,128)})
        data.append(record)
        if not optional:
            rows.append([cfg['title'],f'{cfg["sigma_low"]:g}',f'{cfg["sigma_high"]:g}',
                         f'{cfg["gain"]:g}',f'{100*clip_fraction(result):.2f}%'])
    raw_a,raw_b,a,b,low,high,result,cfg=favorite
    sources,filtered,vmax=_fourier_figures(raw_a,raw_b,a,b,low,high,result,cfg)
    common='Both Fourier figures use the same logarithmic scale and display maximum.'
    primary.extend([
        _figure(sources,f'Original and aligned {cfg.get("low_label","low-source")} and {cfg.get("high_label","high-source")} inputs. Cyan circles show the alignment landmarks; spectra are calculated from the unmarked images. '+common,
                'Original sources, alignment and Fourier spectra'),
        _figure(filtered,'The low-pass spectrum is concentrated near the center. The high-pass component suppresses central energy and retains fine detail. Adding the two components produces the hybrid; the signed high-pass component is displayed as 0.5 + gain H. '+common,
                'Filtered components and reconstruction')])
    primary.extend(pair_cards)
    favorite_record=next(d for d in data if d['id']==FAVORITE)
    favorite_record['fourier_common_display_max']=vmax
    required_records=[d for d in data if not d.get('supplement',False)]
    settings={d['id']:d for d in required_records}
    geometry_rows=[]
    for d in required_records:
        common=np.asarray(d['target_points'],dtype=float)
        human=np.asarray(d.get('low_target_points',d['target_points']),dtype=float)
        scale=np.linalg.norm(human[1]-human[0])/np.linalg.norm(common[1]-common[0])
        dy=float(human.mean(axis=0)[1]-common.mean(axis=0)[1])
        eyes='; '.join(f'({x:g}, {y:g})' for x,y in human)
        geometry_rows.append([d['title'],f'{scale:.2f}',f'{dy:g}',eyes])
    selected_text='; '.join(f'{d["title"]}: ({d["sigma_low"]:g}, {d["sigma_high"]:g}, {d["gain"]:g})'
                            for d in required_records)
    geometry_record=next(d for d in data if d['id']==GEOMETRY_EXAMPLE)
    refinement=geometry_record['refinement_trials']
    geometry_term='common-eye alignment' if geometry_record.get('geometry_reference') else 'refined geometry'
    geometry_change='replacing the reduced-human alternative with common-eye alignment' if geometry_record.get('geometry_reference') else 'refining geometry'
    clipping_text=(f'For {geometry_record["title"]}, changing from reference to selected filters on {geometry_term} changes clipping from '
                   f'{100*refinement[2]["clip_fraction"]:.2f}% to {100*refinement[3]["clip_fraction"]:.2f}%. '
                   f'With selected filters fixed, {geometry_change} changes clipping from '
                   f'{100*refinement[1]["clip_fraction"]:.2f}% to {100*refinement[3]["clip_fraction"]:.2f}%.')
    paragraphs=[
        'A hybrid image combines a blurred image with fine detail from a second, aligned image: hybrid = G_sigmaL * A + gain (B - G_sigmaH * B). G_sigma is a Gaussian kernel with standard deviation sigma, and * denotes convolution. A supplies broad structure and B supplies fine detail. The three examples are '+', '.join(d['title'] for d in required_records)+'.',
        'Obama and Biden have similar near-frontal poses and open smiles. Monroe and Einstein implement a classic hybrid pairing using separately sourced portraits; the softly lit Monroe source reduces strong lower-face shadows. Einstein is horizontally mirrored to improve the facing direction and cheek-shadow match. Eye centers map to common output landmarks using rotation, uniform scale and translation; his left-to-right landmark order is reversed after reflection. There is no separate face scaling. Different facial proportions and illumination remain visible, particularly at intermediate sizes.',
        'The required Derek + Nutmeg pair uses common eye targets (186,235) and (326,235). A controlled alternative reduces Derek by 0.70 about the common eye midpoint and shifts him upward by 12 pixels, giving human targets (207,223) and (305,223). The cat framing stays fixed. This alternative places the human mouth nearer the muzzle but introduces displaced eyes and a narrow cheek region. The common-eye result is selected for a more coherent cat face.',
        'Each original is resampled once; Einstein’s horizontal reflection is composed with his similarity transform, using bilinear interpolation and replicated borders. Uniform scaling preserves face proportions; there is no local warp or independent neck adjustment. Original landmarks and exact 2 x 3 matrices are saved. The four-cell Derek study crosses the two geometries with reference and selected filters on the same cat framing, so the reduced alternative does not reproduce an earlier crop.',
        'Increasing the high-pass sigma retains a wider range of detail. Increasing gain strengthens that detail but can emphasize bright and dark edge outlines. Selected (low-pass sigma, high-pass sigma, gain) settings are '+selected_text+'. Broad low-source facial shading remains; changing the high-band gain cannot remove it.',
        'The filter-width and gain trials keep alignment fixed. A wider low-pass kernel suppresses more fine structure from the low source. A wider high-pass kernel retains more of the second face at intermediate sizes. Gain controls the contrast of that retained detail. Settings are selected visually from the displayed trials, using the near view and the reduced views together.',
        favorite_record['selection_note'],
        clipping_text+' These measurements describe clipping, not perceptual quality. Common eye alignment improves the coherence of the cat eye and cheek region, but broad human hair and neck shading remains. The 64-pixel view is still mixed; the additional 32-pixel view makes Derek clearer. The custom portrait pairs also use common eye targets.',
        'To inspect the effect, view the largest image at normal size and then move farther away, keeping its display size fixed. The reduced versions provide a second comparison. The apparent change depends on screen size, zoom and eyesight, so the pixel-size sequence does not establish a calibrated viewing distance.',
        f'A Gaussian has no sharp frequency cutoff. Its approximate half-amplitude frequency is sqrt(2 ln 2) / (2 pi sigma) cycles per output pixel. For {favorite_record["title"]}, this is {favorite_record["low_half_amplitude_cycles_per_pixel"]:.4f} for the low pass and {favorite_record["high_half_amplitude_cycles_per_pixel"]:.4f} for the complementary high pass. Filtering uses spatial convolution; the Fourier plots show the resulting frequency content.',
        'Each Fourier spectrum displays log(1 + 1000000 |fftshift(fft2(luminance))| / N), where N is the number of image pixels. Division by N permits comparison of differently sized inputs, and both figures use one shared display maximum. No window or mean subtraction is applied before the Fourier transform.',
        'Filtering uses reflected boundaries, and filtering and addition retain signed float64 values. Intermediate bands are neither clipped nor contrast-normalized. Display exports clamp values to [0,1] and quantize them to 8 bits; the table reports the fraction of scalar channel values clipped. Supplementary figures include the remaining alignment, component and parameter comparisons, together with the unsuccessful Earth + Moon hybrid.']
    sec=section('part22','2.2 · Hybrid images',paragraphs,primary+extras,
        [{'title':'Selected settings at 512 x 512 pixels','columns':['Pair','Low-pass sigma (px)','High-pass sigma (px)','Gain','Values clipped'],'rows':rows},
         {'title':'Low-source transform relative to each pair’s common eye alignment.','columns':['Pair','Scale','Vertical shift (px)','Low-source eye centers (px)'],'rows':geometry_rows}],
        [{'title':'Hybrid synthesis','text':'low = gaussian(A, sigma_low)\nhigh = B - gaussian(B, sigma_high)\nhybrid = low + gain * high'}],
        paragraph_headings={0:'Hybrid construction',1:'Image registration',4:'Filter settings',6:'Appearance at different scales',9:'Frequency analysis',11:'Numerical representation'})
    metadata_keys=('title','low_label','high_label','alignment_note','sigma_low','sigma_high','gain','target_points','low_target_points',
                   'low_horizontal_flip','high_horizontal_flip',
                   'high_target_points','low_half_amplitude_cycles_per_pixel',
                   'high_half_amplitude_cycles_per_pixel','selection_note')
    sec['hybrid_settings']={ident:{k:d[k] for k in metadata_keys if k in d}
                            for ident,d in settings.items()}
    low_label=favorite_record.get('low_label','the low source')
    high_label=favorite_record.get('high_label','the high source')
    color=section('hybrid-color','Color in hybrid images',[
        f'Four variants retain color in neither source, only the low-frequency source, only the high-frequency source, or both. Low-frequency color preserves {low_label}’s broad skin, hair and clothing regions. High-frequency color appears mainly around {high_label}’s fine facial and hair edges because filtering suppresses broad color variation.',
        f'Color in the low-frequency source agrees with the face visible at smaller sizes, while grayscale detail from {high_label} remains visible at larger sizes. Keeping both sources in color combines their chromatic structure at different scales. The main examples use grayscale so that the change in visible subject can be assessed without the broad color difference.'],color_figs)
    return [sec,color],data
