"""Hybrid-image experiments and report figures, with explicit scale comparisons."""
import numpy as np
from PIL import Image, ImageDraw, ImageOps
from .frequencies import gaussian, grayscale, rgb, align, hybrid, clip_fraction
from .report_figures import font, read, pil, save, grid, mark, near_far, describe, section, BG


FAVORITE = 'astronaut_chelsea'  # Stable artifact identifier; source is portrait_cat.jpg.
BASELINE = (10, 5, 1)


def _figure(path, caption, heading, supplement=False, group='hybrids'):
    return dict(describe(path, caption), heading=heading,
                supplement=supplement, group=group)


def _band_ratio(low, high, size):
    """Diagnostic band-contrast ratio, not a perceptual identity score.

    Lanczos operates on signed float luminance; no clipping/8-bit conversion is
    used here. This matches the display reduction filter but analyzes the bands.
    """
    bands=[]
    for a in (low, high):
        a=grayscale(a)
        if a.shape != (size,size):
            a=np.asarray(Image.fromarray(a.astype(np.float32)).resize(
                (size,size),Image.Resampling.LANCZOS),dtype=float)
        bands.append(a)
    return float(np.std(bands[1])/max(np.std(bands[0]),1e-12))


def _comparison_card(raw_a, raw_b, result, ident):
    """Two complete originals plus the hybrid at large and reduced sizes."""
    canvas=Image.new('RGB',(1056,574),BG); draw=ImageDraw.Draw(canvas)
    for image,x,label in [(raw_a,16,'Original low source'),(raw_b,256,'Original high source')]:
        thumb=ImageOps.contain(pil(image),(224,280),Image.Resampling.LANCZOS)
        canvas.paste(thumb,(x+(224-thumb.width)//2,16+(280-thumb.height)//2))
        draw.text((x,307),label,font=font(17),fill=(31,40,49))
    im=pil(result)
    canvas.paste(im,(528,16))
    draw.text((528,540),'Hybrid / 512 px',font=font(17),fill=(31,40,49))
    for size,x,y in [(128,56,365),(64,306,397)]:
        canvas.paste(im.resize((size,size),Image.Resampling.LANCZOS),(x,y))
        draw.text((x,y+size+10),f'{size} px',font=font(17),fill=(31,40,49))
    return save(canvas,'hybrid_'+ident+'_summary')


def hybrid_experiments(a,b,cfg):
    """Render the actual cutoff/gain trials, at identical two display sizes."""
    chosen=(cfg['sigma_low'],cfg['sigma_high'],cfg['gain'])
    trials=[tuple(p) for p in cfg.get('trial_settings',[
        BASELINE,(6,1.5,1),(14,1.5,chosen[2]),
        (6,5,chosen[2]),(6,1,4),chosen])]
    if chosen not in trials:
        trials.append(chosen)
    lows={s:gaussian(rgb(grayscale(a)),s) for s in {x[0] for x in trials}}
    highs={s:rgb(grayscale(b))-gaussian(rgb(grayscale(b)),s) for s in {x[1] for x in trials}}
    cols=3; cellw=344; cellh=332
    canvas=Image.new('RGB',(cols*cellw+16,((len(trials)+cols-1)//cols)*cellh+16),BG)
    draw=ImageDraw.Draw(canvas); records=[]
    for i,(sl,sh,gain) in enumerate(trials):
        low=lows[sl]; high=gain*highs[sh]; result=low+high
        x=16+(i%cols)*cellw; y=16+(i//cols)*cellh
        im=pil(result)
        canvas.paste(im.resize((256,256),Image.Resampling.LANCZOS),(x,y))
        canvas.paste(im.resize((64,64),Image.Resampling.LANCZOS),(x+264,y+96))
        selected=(sl,sh,gain)==chosen
        draw.text((x,y+267),f'low {sl:g} / high {sh:g} / gain {gain:g}',font=font(17),fill=(31,40,49))
        suffix='SELECTED' if selected else ('wide-band baseline' if (sl,sh,gain)==BASELINE else 'comparison')
        draw.text((x,y+290),suffix,font=font(16),fill=(31,40,49))
        draw.text((x,y+311),f'clipped {100*clip_fraction(result):.1f}%',font=font(15),fill=(60,68,74))
        records.append({'sigma_low':sl,'sigma_high':sh,'gain':gain,'selected':selected,
                        'clip_fraction':clip_fraction(result),
                        'high_to_low_contrast_ratio_512':_band_ratio(low,high,512),
                        'high_to_low_contrast_ratio_128':_band_ratio(low,high,128)})
    return save(canvas,'hybrid_'+cfg['id']+'_sweep'),records


def _fourier_figures(raw_a,raw_b,a,b,low,high,result,cfg):
    arrays=[raw_a,raw_b,a,b,low,high,result]
    spectra=[]
    for array in arrays:
        gray=grayscale(array)
        spectra.append(np.log1p(1e6*np.abs(np.fft.fftshift(np.fft.fft2(gray)))/gray.size))
    vmax=max(float(s.max()) for s in spectra)
    source_labels=['Original astronaut','Original portrait cat','Aligned astronaut','Aligned portrait cat']
    source_points=[cfg['low_points'],cfg['high_points'],cfg['target_points'],cfg['target_points']]
    items=[(mark(array,pts),label) for array,pts,label in zip(arrays[:4],source_points,source_labels)]
    items += [(s/vmax,'Log Fourier: '+label) for s,label in zip(spectra[:4],source_labels)]
    sources=grid(items,'hybrid_fourier_sources',4,(280,280))
    process_labels=['Gaussian low pass','Gain-scaled signed high pass','Final hybrid']
    process=[(low,process_labels[0]),(.5+high,process_labels[1]),(result,process_labels[2])]
    process += [(s/vmax,'Log Fourier: '+label) for s,label in zip(spectra[4:],process_labels)]
    filtered=grid(process,'hybrid_fourier_process',3,(320,320))
    return sources,filtered,float(vmax)


def make_hybrids(config):
    primary=[]; extras=[]; data=[]; rows=[]; color_figs=[]
    favorite=None; pair_cards=[]
    for cfg in config['hybrids']:
        ident=cfg['id']; is_favorite=ident==FAVORITE
        optional=cfg.get('supplement',ident=='earth_moon')
        print('Hybrid:',ident,flush=True)
        raw_a=read(cfg['low_path']); raw_b=read(cfg['high_path'])
        a,ma=align(raw_a,cfg['low_points'],cfg['target_points'],cfg['shape'])
        b,mb=align(raw_b,cfg['high_points'],cfg['target_points'],cfg['shape'])
        result,low,high=hybrid(a,b,cfg['sigma_low'],cfg['sigma_high'],cfg['gain'],cfg['low_color'],cfg['high_color'])
        final=save(result,'hybrid_'+ident+'_final')
        distance=near_far(result,'hybrid_'+ident+'_distance')
        alignment=grid([(mark(raw_a,cfg['low_points']),'Original low source: landmarks'),
                        (mark(raw_b,cfg['high_points']),'Original high source: landmarks'),
                        (mark(a,cfg['target_points']),'Aligned low source: 512 x 512'),
                        (mark(b,cfg['target_points']),'Aligned high source: 512 x 512')],
                        'hybrid_'+ident+'_alignment',4,(260,280))
        comps=grid([(a,'Aligned low-frequency source'),(b,'Aligned high-frequency source'),
                    (low,'Gaussian low pass'),(.5+high,'Signed high pass: 0.5 + gain H'),
                    (result,'Hybrid = low + gain H')],
                   'hybrid_'+ident+'_components',5,(230,250))
        extras.extend([
            _figure(alignment,cfg['title']+': complete originals and two-point similarity alignment. Cyan circles mark the original eye centers (or disk-limb landmarks) and the common destinations. The transform uses rotation, uniform scale and translation; image warping uses bilinear interpolation and edge replication, while filtering uses reflection.',cfg['title']+' — alignment detail',True),
            _figure(comps,cfg['title']+f': sigma low = {cfg["sigma_low"]:g} px, sigma high = {cfg["sigma_high"]:g} px and gain = {cfg["gain"]:g}. The signed high-pass display is shifted by 0.5 but receives no additional display amplification.',cfg['title']+' — component detail',True)])
        trial_records=[]
        if not optional:
            trialpath,trial_records=hybrid_experiments(a,b,cfg)
            trialfig=_figure(trialpath,
                cfg['title']+': every trial is synthesized at 512 x 512, then shown at the same 256-pixel and 64-pixel display sizes. The comparisons vary low-pass width, high-pass width and detail gain; the selected panel uses the exact settings of the final result.',
                'Choosing cutoffs and detail gain' if is_favorite else cfg['title']+' — cutoff and gain trials',not is_favorite)
            (primary if is_favorite else extras).append(trialfig)
        if is_favorite:
            primary.insert(0,_figure(distance,
                cfg['title']+': one fixed result at 512, 256, 128 and 64 pixels, reduced with Lanczos. Fine fur and eye rims are visible at the largest size. The astronaut eyes and smile emerge in the smaller views; the intermediate view deliberately exposes the remaining mixture.',
                'A custom hybrid across viewing scales'))
            favorite=(raw_a,raw_b,a,b,low,high,result,cfg)
            colors=[]
            for lc,hc,label in [(False,False,'Neither in color'),(True,False,'Low source in color'),(False,True,'High source in color'),(True,True,'Both in color')]:
                image,_,_=hybrid(a,b,cfg['sigma_low'],cfg['sigma_high'],cfg['gain'],lc,hc)
                colors.append((image,label))
            color_figs.append(_figure(grid(colors,'hybrid_color_comparison',4,(280,280)),
                'The four variants use identical geometry, sigma values and detail gain. Only conversion to luminance changes (weights 0.2126, 0.7152, 0.0722). Broad human skin and hair colors survive the low pass; high-only color is confined to edges and fine cat detail.',
                'Color in the low band, high band, or both'))
        else:
            summary=_comparison_card(raw_a,raw_b,result,ident)
            fig=_figure(summary,
                cfg['title']+': complete original sources beside the final hybrid at 512, 128 and 64 pixels. '+cfg.get('selection_note','Both circular subjects share a silhouette and overlapping structure, so this remains a textured-planet result rather than a convincing identity switch.'),
                cfg['title'],optional)
            (extras if optional else pair_cards).append(fig)
            extras.append(_figure(distance,cfg['title']+': the same fixed hybrid at four display sizes, including the mixed intermediate scale.',cfg['title']+' — full scale sequence',True))
        f_low=np.sqrt(2*np.log(2))/(2*np.pi*cfg['sigma_low'])
        f_high=np.sqrt(2*np.log(2))/(2*np.pi*cfg['sigma_high'])
        baseline,baseline_low,baseline_high=hybrid(a,b,*BASELINE,False,False)
        record=dict(cfg,low_matrix=ma.tolist(),high_matrix=mb.tolist(),
                    clip_fraction=clip_fraction(result),range=[float(result.min()),float(result.max())],
                    low_half_amplitude_cycles_per_pixel=float(f_low),
                    high_half_amplitude_cycles_per_pixel=float(f_high),
                    final=final,alignment=alignment,components=comps,near_far=distance,
                    trials=trial_records,
                    band_contrast_diagnostic={'definition':'std(high luminance) / std(low luminance); signed float Lanczos reduction, no clipping. Not a perceptual score.',
                        'selected_512':_band_ratio(low,high,512),'selected_128':_band_ratio(low,high,128),
                        'baseline_512':_band_ratio(baseline_low,baseline_high,512),
                        'baseline_128':_band_ratio(baseline_low,baseline_high,128)})
        data.append(record)
        if not optional:
            rows.append([cfg['title'],f'{cfg["sigma_low"]:g}',f'{cfg["sigma_high"]:g}',
                         f'{cfg["gain"]:g}',f'{100*clip_fraction(result):.2f}%'])
    raw_a,raw_b,a,b,low,high,result,cfg=favorite
    sources,filtered,vmax=_fourier_figures(raw_a,raw_b,a,b,low,high,result,cfg)
    common='Each spectrum is log(1 + 1000000 |fftshift(fft2(luminance))| / N), using one shared display maximum across both Fourier figures. Division by N normalizes differently sized inputs. No FFT window or mean subtraction is used.'
    primary.extend([
        _figure(sources,'Original and aligned inputs for the favorite custom pair. Cyan landmarks are display annotations only; spectra are calculated from the unmarked images. '+common,
                'Original sources, alignment and Fourier spectra'),
        _figure(filtered,'The low-pass spectrum is concentrated centrally; the high pass suppresses central energy and preserves fine structure. Their spatial sum produces the final hybrid. The signed high component is displayed as 0.5 + gain H, with clipping only for display. '+common,
                'Filtered components and reconstruction')])
    primary.extend(pair_cards)
    favorite_record=next(d for d in data if d['id']==FAVORITE)
    favorite_record['fourier_common_display_max']=vmax
    paragraphs=[
        'A hybrid adds a blurred source to detail from a second aligned source: H = G_sigmaL * A + gain (B - G_sigmaH * B). Here the people provide the low-frequency image and the cats provide the high-frequency image. The three required examples are Derek + Nutmeg and two custom portrait/cat pairs.',
        'I aligned the eye centers with a two-point similarity transform before filtering. The transform permits rotation, uniform scale and translation, but no face warping. The existing landmarks line up the pupils well, so the refinement changes the frequency separation and gain. Full original coordinates and 2 x 3 transforms are saved with the results.',
        'The initial sigma-low 10, sigma-high 5, gain 1 settings left substantial cat shading at reduced sizes. Moving the high-pass sigma to 1.5 removes more of that broad structure. A gain of 2.2–3 restores fine fur contrast, while sigma-low 6 retains enough human eye and mouth structure to read at smaller sizes. The selected gain is lower for the dense tabby texture than for the lighter portrait cat. These are judgments from the displayed comparisons, not a universally optimal setting.',
        'In the selected astronaut example, the 512-pixel view emphasizes cat fur and eye rims; the astronaut eyes and smile are readable at 128 pixels and clearer at 64. The 256-pixel view still contains both identities. Increasing gain further strengthens fine edges but also clips more highlights; increasing sigma-high leaks broader cat structure back into the reduced view. The six actual trials expose these tradeoffs.',
        'To view the effect, open the largest result at normal size, then increase your viewing distance or compare the smaller versions. Keep the displayed image fixed while moving back. Exact distances depend on screen size, zoom and eyesight, so the pixel-size sequence is a repeatable demonstration rather than a calibrated distance test.',
        f'The Gaussian has no sharp cutoff. Its approximate half-amplitude frequency is sqrt(2 ln 2) / (2 pi sigma) cycles per output pixel. For the selected astronaut pair this is {favorite_record["low_half_amplitude_cycles_per_pixel"]:.4f} for the low pass and {favorite_record["high_half_amplitude_cycles_per_pixel"]:.4f} for the complementary high pass. The filtering itself is spatial convolution; the Fourier plots diagnose the resulting bands.',
        'All filtering and addition use signed float64 values. Display exports clamp to [0,1] and quantize to 8 bits; the table reports the fraction of scalar channel values clipped. No intermediate band is clipped or contrast-normalized during synthesis. Additional alignment/component views, all other trial grids and the unsuccessful Earth + Moon study are included as supplemental figures.']
    sec=section('part22','2.2 · Hybrid images',paragraphs,primary+extras,
        [{'title':'Selected settings on a 512 x 512 canvas','columns':['Pair','sigma low (px)','sigma high (px)','gain','values clipped'],'rows':rows}],
        [{'title':'Hybrid synthesis','text':'low = gaussian(A, sigma_low)\nhigh = B - gaussian(B, sigma_high)\nhybrid = low + gain * high'}])
    color=section('hybrid-color','Color · Which frequency band benefits?',[
        'The four controlled variants put color in neither source, only the low-frequency source, only the high-frequency source, or both. Low-only color preserves broad skin and hair hues associated with the distant astronaut. High-only color contributes colored fine edges but cannot recover the cat’s broad coat color after that information has been removed.',
        'For this pair, low-only color is the most coherent color version: its large color regions agree with the distant face, while grayscale fur remains visible nearby. Both-color adds localized competing hues around some cat edges. The grayscale main examples make the frequency-dependent identity easier to judge without a broad color cue.'],color_figs)
    return [sec,color],data
