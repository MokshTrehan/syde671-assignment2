"""Recompute report diagnostics without changing any synthesis choices.

All synthesis, registration, masks, input loading, and band-ratio calculations
reuse the report implementation. Measurements use the signed reconstruction,
never a JPEG or a clipped display. The one new figure uses the existing fixed
[0,1] display export and does not feed back into any measurement.
"""
from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np

from .blend_report import (boundary_jump, fit_disk_registration, selection_mask,
                           photometric_diagnostics)
from .frequencies import (align, clip_fraction, gaussian, hybrid,
                          multiresolution_blend, reconstruct, apply_rgb_gain)
from .hybrid_report import BASELINE, GEOMETRY_EXAMPLE, _band_ratio
from .report_figures import ROOT, grid, read


DEFINITIONS = {
    'numerical_domain': 'Signed float64 image arrays before clipping, quantization, or JPEG export. Original input RGB is scaled to [0,1]; optional configured global RGB gains are then applied after framing without clipping. JSON values are not rounded.',
    'photometric_preprocessing': 'When configured, B prime = B * b_gain_rgb applies the same three positive channel gains to every framed B pixel in stored RGB space. This is an empirical color adjustment, not a scene-linear exposure or relighting model. Hard-cut, feathered and multiscale methods all receive the same corrected B, including values outside [0,1].',
    'clip_fraction': 'Count of scalar RGB channel values strictly below 0 or above 1 divided by the total number of scalar RGB values.',
    'clip_fraction_tolerance_1e6': 'Only the audit blending comparison additionally uses C_epsilon = mean(image < -1e-6 or image > 1+1e-6) over scalar RGB values, with epsilon = 1e-6. This tolerance discounts numerical roundoff and negligible excursions near display limits. The original strict clip_fraction and signed ranges are retained for every method; image computation and display export are unchanged. This is not a visual-quality score.',
    'band_contrast_ratio': 'Population std(high luminance) / max(population std(low luminance), 1e-12), where high includes synthesis gain and luminance = 0.2126 R + 0.7152 G + 0.0722 B. Reuses hybrid_report._band_ratio: native 512-pixel bands are measured directly; 128-pixel bands use PIL signed float32 Lanczos reduction then float64 standard deviation. No clipping or uint8 conversion. This is a band-contrast diagnostic, not a perceptual or identity score.',
    'boundary_jump': 'J = mean absolute RGB difference across all horizontal and vertical adjacent pixel pairs straddling the ORIGINAL binary selection contour, pooled equally over all pairs and channels. Reuses blend_report.boundary_jump. Natural image texture contributes; this is not an overall perceptual quality score.',
    'feather': 'The exact coarsest Gaussian mask returned by multiresolution_blend weights the full registered sources: M_last A + (1-M_last) B. This is the same mask used for the multiscale coarse residual, including any configured initial mask smoothing.',
    'rms': 'sqrt(mean(X**2)) over all pixels and RGB channels, with no centering, clipping, or contrast normalization.',
    'mixed_contribution': 'S_i = M_i L_Ai + (1-M_i) L_Bi; L_i = G_i-G_(i+1) for detail levels, and L_5 = G_5 for the oraple coarse residual.',
    'coarse_to_fine_trace': 'T_5 = S_5; T_k = T_(k+1) + S_k for k = 4,...,0. Remaining RMS is RMS(final-T_k), using the unmodified multiresolution_blend final. It need not decrease monotonically because signed bands can cancel. The endpoint can differ at floating-point roundoff because the accumulation order differs.',
    'fine_to_coarse_trace': 'U_i = sum(S_0,...,S_i); remaining RMS = RMS(final-U_i). Retained as a numerical cross-check, not the primary report trace.',
    'saved_checks': 'Numeric matches use numpy.allclose with rtol=1e-12 and atol=1e-12 against results/frequencies.json; configuration labels and landmarks must match exactly. A mismatch raises AssertionError.',
    'interpretation': 'No reference composite or ground truth is available. These diagnostics do not establish MSE, SSIM, perceptual quality, or a calibrated viewing distance.',
}


def _rms(array):
    return float(np.sqrt(np.mean(np.asarray(array, dtype=np.float64) ** 2)))


def _range(array):
    return [float(np.min(array)), float(np.max(array))]


def _match(actual, expected, name):
    matched = bool(np.allclose(actual, expected, rtol=1e-12, atol=1e-12))
    assert matched, f'{name}: recomputed {actual!r} != saved {expected!r}'
    return matched


def _equal(actual, expected, name):
    assert actual == expected, f'{name}: recomputed {actual!r} != saved {expected!r}'
    return True


def _hybrid_measurements(result, low, high):
    return {
        'clip_fraction': clip_fraction(result),
        'range': _range(result),
        'high_to_low_contrast_ratio_512': _band_ratio(low, high, 512),
        'high_to_low_contrast_ratio_128': _band_ratio(low, high, 128),
    }


def _hybrid_sources(cfg):
    raw_a, raw_b = read(cfg['low_path']), read(cfg['high_path'])
    low_targets = cfg.get('low_target_points', cfg['target_points'])
    high_targets = cfg.get('high_target_points', cfg['target_points'])
    a, ma = align(raw_a, cfg['low_points'], low_targets, cfg['shape'])
    b, mb = align(raw_b, cfg['high_points'], high_targets, cfg['shape'])
    return raw_a, a, b, ma, mb


def _geometry_refinement(cfg, saved, sources):
    raw_a, final_a, b, final_matrix, high_matrix = sources
    # As in refinement_comparison, each alternative samples the original once;
    # the common alignment is never warped again to obtain the refined one.
    common, common_matrix = align(raw_a, cfg['low_points'], cfg['target_points'], cfg['shape'])
    reference = cfg['refinement_baseline']
    original = [reference[k] for k in ('sigma_low', 'sigma_high', 'gain')]
    selected = [cfg[k] for k in ('sigma_low', 'sigma_high', 'gain')]
    if cfg.get('geometry_reference'):
        reduced_targets = cfg['geometry_reference']['low_target_points']
        reduced, reduced_matrix = align(raw_a, cfg['low_points'], reduced_targets, cfg['shape'])
        controls = [
            ('Reduced human / reference filters', 'reduced', 'reference', reduced, reduced_matrix, original, reduced_targets),
            ('Reduced human / selected filters', 'reduced', 'selected', reduced, reduced_matrix, selected, reduced_targets),
            ('Common eyes (selected) / reference filters', 'common', 'reference', final_a, final_matrix, original, cfg['target_points']),
            ('Common eyes (selected) / selected filters', 'common', 'selected', final_a, final_matrix, selected, cfg['target_points']),
        ]
    else:
        controls = [
            ('Common eye targets / reference filters', 'common', 'reference', common, common_matrix, original, cfg['target_points']),
            ('Common eye targets / selected filters', 'common', 'selected', common, common_matrix, selected, cfg['target_points']),
            ('Refined geometry / reference filters', 'refined', 'reference', final_a, final_matrix, original, cfg['low_target_points']),
            ('Refined geometry / selected filters', 'refined', 'selected', final_a, final_matrix, selected, cfg['low_target_points']),
        ]
    assert len(saved['refinement_trials']) == len(controls) == 4
    records = []
    for control, prior in zip(controls, saved['refinement_trials']):
        label, geometry, filter_set, a, matrix, settings, targets = control
        result, low, high = hybrid(a, b, *settings, cfg['low_color'], cfg['high_color'])
        record = dict(label=label, geometry=geometry, filter_set=filter_set,
                      sigma_low=settings[0], sigma_high=settings[1], gain=settings[2],
                      low_target_points=targets, low_matrix=matrix.tolist(),
                      **_hybrid_measurements(result, low, high))
        checks = {key: _equal(record[key], prior[key], f'{label}.{key}')
                  for key in ('label', 'geometry', 'filter_set', 'sigma_low', 'sigma_high', 'gain', 'low_target_points')}
        checks['clip_fraction'] = _match(record['clip_fraction'], prior['clip_fraction'], f'{label}.clip_fraction')
        record['saved_checks'] = checks
        record['matches_saved_refinement_trial'] = all(checks.values())
        records.append(record)
    return {
        'id': cfg['id'], 'title': cfg['title'],
        'figure': 'images/hybrid_' + cfg['id'] + '_refinement.jpg',
        'design': '2 geometries x 2 filter sets; same original photographs, cat alignment, color flags, canvas, and interpolation. Every original is geometrically resampled once per alignment.',
        'selected_geometry': 'common' if cfg.get('geometry_reference') else 'refined',
        'alternative_geometry': 'reduced' if cfg.get('geometry_reference') else 'common',
        'geometry_comparison_note': ('The reduced-human alternative is constructed on the selected cat framing; it does not reproduce a historical crop.'
                                     if cfg.get('geometry_reference') else 'Compare common-eye and refined geometry on one cat framing.'),
        'width': cfg['shape'][1], 'height': cfg['shape'][0],
        'high_matrix': high_matrix.tolist(),
        'low_color': cfg['low_color'], 'high_color': cfg['high_color'],
        'trials': records,
        'all_clip_fractions_match_saved': all(r['saved_checks']['clip_fraction'] for r in records),
    }


def _selected_hybrids(config, saved):
    records, refinement = [], None
    priors = {r['id']: r for r in saved['hybrids']}
    for cfg in config['hybrids']:
        if cfg.get('supplement', cfg['id'] == 'earth_moon'):
            continue
        sources = _hybrid_sources(cfg)
        _, a, b, ma, mb = sources
        result, low, high = hybrid(a, b, cfg['sigma_low'], cfg['sigma_high'], cfg['gain'], cfg['low_color'], cfg['high_color'])
        prior = priors[cfg['id']]
        record = dict(id=cfg['id'], title=cfg['title'], width=cfg['shape'][1], height=cfg['shape'][0],
                      sigma_low=cfg['sigma_low'], sigma_high=cfg['sigma_high'], gain=cfg['gain'],
                      low_color=cfg['low_color'], high_color=cfg['high_color'],
                      **_hybrid_measurements(result, low, high))
        record['saved_checks'] = {
            'clip_fraction': _match(record['clip_fraction'], prior['clip_fraction'], cfg['id'] + '.clip_fraction'),
            'range': _match(record['range'], prior['range'], cfg['id'] + '.range'),
            'ratio_512': _match(record['high_to_low_contrast_ratio_512'], prior['band_contrast_diagnostic']['selected_512'], cfg['id'] + '.ratio_512'),
            'ratio_128': _match(record['high_to_low_contrast_ratio_128'], prior['band_contrast_diagnostic']['selected_128'], cfg['id'] + '.ratio_128'),
            'low_matrix': _match(ma, prior['low_matrix'], cfg['id'] + '.low_matrix'),
            'high_matrix': _match(mb, prior['high_matrix'], cfg['id'] + '.high_matrix'),
        }
        baseline_result, baseline_low, baseline_high = hybrid(a, b, *BASELINE, False, False)
        record['baseline'] = {
            'label': 'Wide-band baseline on selected geometry',
            'sigma_low': BASELINE[0], 'sigma_high': BASELINE[1], 'gain': BASELINE[2],
            'geometry': 'Same selected geometry as this pair; only filter widths and gain vary.',
            'low_color': False, 'high_color': False,
            **_hybrid_measurements(baseline_result, baseline_low, baseline_high),
        }
        record['baseline']['saved_checks'] = {
            'ratio_512': _match(record['baseline']['high_to_low_contrast_ratio_512'], prior['band_contrast_diagnostic']['baseline_512'], cfg['id'] + '.baseline_ratio_512'),
            'ratio_128': _match(record['baseline']['high_to_low_contrast_ratio_128'], prior['band_contrast_diagnostic']['baseline_128'], cfg['id'] + '.baseline_ratio_128'),
        }
        records.append(record)
        if cfg['id'] == GEOMETRY_EXAMPLE:
            refinement = _geometry_refinement(cfg, prior, sources)
    assert len(records) == 3, 'The report requires three primary hybrids'
    assert refinement is not None, 'The configured geometry example must have a four-cell refinement audit'
    return records, refinement


def _method_record(image, binary_mask):
    return {'boundary_jump': boundary_jump(image, binary_mask),
            'clip_fraction': clip_fraction(image),
            'clip_fraction_tolerance_1e6': float(np.mean((image < -1e-6) | (image > 1+1e-6))),
            'range': _range(image)}


def _three_methods(a, b, binary_mask, finest_mask, bands, base_sigma):
    final, details = multiresolution_blend(a, b, finest_mask, bands, base_sigma)
    hard = binary_mask[..., None] * a + (1-binary_mask[..., None]) * b
    coarse = details['gm'][-1][..., None]
    feather = coarse * a + (1-coarse) * b
    methods = {name: _method_record(im, binary_mask)
               for name, im in [('hard_cut', hard), ('feather', feather), ('multiscale', final)]}
    return methods, final, details


def _oraple(config, saved):
    cfg = config['oraple']
    a, b = read(cfg['apple_path']), read(cfg['orange_path'])
    assert a.shape == b.shape, 'Course apple/orange input dimensions must match'
    source_shape = list(a.shape)
    width = int(cfg['width'])
    assert width >= 2
    height = max(1, round(a.shape[0] * width / a.shape[1]))
    # Same single area-resize, aspect rounding, and binary seam as the report.
    a = cv2.resize(a, (width, height), interpolation=cv2.INTER_AREA)
    b = cv2.resize(b, (width, height), interpolation=cv2.INTER_AREA)
    bands, base_sigma = config['stack']['bands'], config['stack']['base_sigma']
    mask = np.zeros(a.shape[:2]); mask[:, :width//2] = 1
    methods, final, details = _three_methods(a, b, mask, mask, bands, base_sigma)
    assert bands == 5, 'The existing oraple demonstration has five details and a residual'
    sigmas = [0] + [base_sigma * 2**i for i in range(bands)]
    cumulative = np.zeros_like(final)
    steps, figure_items = [], []
    for step, level in enumerate(range(bands, -1, -1), start=1):
        contribution = details['sum'][level]
        cumulative += contribution
        remaining = final - cumulative
        steps.append({
            'step': step, 'level': level, 'added_band': f'S{level}',
            'width': width, 'height': height,
            'gaussian_input_sigma': sigmas[level],
            'next_gaussian_input_sigma': None if level == bands else sigmas[level+1],
            'laplacian_definition': f'L{level} = G{level}' if level == bands else f'L{level} = G{level} - G{level+1}',
            'mask_sigma': sigmas[level],
            'contribution_rms': _rms(contribution),
            'remaining_rms': _rms(remaining),
            'remaining_max_abs': float(np.max(np.abs(remaining))),
            'cumulative_range': _range(cumulative),
        })
        label = (f'Residual S{level} / sigma {sigmas[level]:g}' if level == bands
                 else f'+ S{level} / sigma {sigmas[level]:g}')
        figure_items.append((cumulative.copy(), label))
    figure_path = grid(figure_items, 'stacks_oraple_reconstruction_trace', 3, (360, 258))
    fine_steps, fine_cumulative = [], np.zeros_like(final)
    for level, contribution in enumerate(details['sum']):
        fine_cumulative += contribution
        fine_steps.append({'level': level, 'width': width, 'height': height,
                           'gaussian_input_sigma': sigmas[level], 'mask_sigma': sigmas[level],
                           'laplacian_definition': steps[bands-level]['laplacian_definition'],
                           'contribution_rms': _rms(contribution),
                           'remaining_rms': _rms(final-fine_cumulative)})
    without_residual = reconstruct(details['sum'][:-1])
    reconstruction_errors = {
        'apple_max_abs': float(np.max(np.abs(reconstruct(details['la'])-a))),
        'orange_max_abs': float(np.max(np.abs(reconstruct(details['lb'])-b))),
        'mixed_sum_max_abs': float(np.max(np.abs(reconstruct(details['sum'])-final))),
        'coarse_to_fine_endpoint_max_abs': steps[-1]['remaining_max_abs'],
        'coarse_to_fine_endpoint_rms': steps[-1]['remaining_rms'],
    }
    assert max(reconstruction_errors.values()) < 1e-12
    assert fine_steps[-1]['remaining_rms'] < 1e-12
    checks = {
        'source_shape': _equal(source_shape, saved['source_shape'], 'oraple.source_shape'),
        'stack_shape': _equal(list(a.shape), saved['stack_shape'], 'oraple.stack_shape'),
        'hard_boundary_jump': _match(methods['hard_cut']['boundary_jump'], saved['mean_boundary_jump_hard'], 'oraple.hard_boundary_jump'),
        'multiscale_boundary_jump': _match(methods['multiscale']['boundary_jump'], saved['mean_boundary_jump_blend'], 'oraple.multiscale_boundary_jump'),
        'multiscale_clip_fraction': _match(methods['multiscale']['clip_fraction'], saved['clip_fraction'], 'oraple.clip_fraction'),
        'multiscale_range': _match(methods['multiscale']['range'], saved['range'], 'oraple.range'),
        'apple_reconstruction': _match(reconstruction_errors['apple_max_abs'], saved['apple_reconstruction_max_abs_error'], 'oraple.apple_reconstruction'),
        'orange_reconstruction': _match(reconstruction_errors['orange_max_abs'], saved['orange_reconstruction_max_abs_error'], 'oraple.orange_reconstruction'),
        'mixed_reconstruction': _match(reconstruction_errors['mixed_sum_max_abs'], saved['final_decomposition_max_abs_error'], 'oraple.mixed_reconstruction'),
    }
    trace = {
        'id': 'oraple', 'width': width, 'height': height, 'channels': 3,
        'source_shape': source_shape, 'bands': bands, 'base_sigma': base_sigma,
        'gaussian_input_sigmas': sigmas, 'mask_sigmas': sigmas,
        'seam_column': width//2, 'hard_boundary_jump': methods['hard_cut']['boundary_jump'],
        'steps': steps, 'fine_to_coarse_steps': fine_steps,
        'figure': {'path': figure_path,
                   'caption': 'Coarse-to-fine reconstruction of the same oraple, read left to right and top to bottom. Start with the mixed coarse residual S5, then add S4 through S0. Every panel uses the same fixed [0,1] display clipping with no contrast normalization; all measurements use signed float64 values before clipping.',
                   'columns': 3, 'rows': 2, 'display_range': [0, 1],
                   'normalization': 'none', 'level_order': list(range(bands, -1, -1))},
        'reconstruction_errors': reconstruction_errors,
        'without_residual': {'definition': 'Sum of detail contributions S0 through S4; omit S5.',
                             'range': _range(without_residual),
                             'rms_error_to_final': _rms(final-without_residual),
                             'mean_rgb': np.mean(without_residual, axis=(0, 1)).tolist()},
        'coarse_contribution': {'definition': 'S5 = M5 G_A5 + (1-M5) G_B5. Omitting it loses the broad intensity/color contribution; detail bands alone do not reconstruct the final image.',
                                'rms': _rms(details['sum'][-1]),
                                'range': _range(details['sum'][-1]),
                                'mean_rgb': np.mean(details['sum'][-1], axis=(0, 1)).tolist(),
                                'omission_error_matches_contribution_rms': _match(_rms(final-without_residual), _rms(details['sum'][-1]), 'oraple.coarse_omission')},
        'saved_checks': checks,
    }
    comparison = {'id': 'oraple', 'title': 'Apple + orange', 'width': width, 'height': height,
                  'bands': bands, 'base_sigma': base_sigma, 'initial_mask_sigma': 0,
                  'coarse_image_sigma': sigmas[-1], 'binary_mask_area_pixels': int(mask.sum()),
                  'mask_kind': 'vertical binary seam', 'methods': methods, 'saved_checks': checks}
    return trace, comparison


def _custom_blend(cfg, saved):
    original_a, original_b = read(cfg['a_path']), read(cfg['b_path'])
    registration = cfg.get('registration', {'kind': 'two_point_similarity'})
    if registration['kind'] == 'ellipse_to_circle':
        a, ma, _ = fit_disk_registration(original_a, registration, cfg['shape'])
        b, mb, _ = fit_disk_registration(original_b, registration, cfg['shape'])
    elif registration['kind'] == 'two_point_similarity':
        a, ma = align(original_a, cfg['a_points'], cfg['target_points'], cfg['shape'])
        b, mb = align(original_b, cfg['b_points'], cfg['target_points'], cfg['shape'])
    else:
        raise ValueError('Unknown custom-blend registration kind')
    framed_b = b
    gains = cfg.get('photometric', {}).get('b_gain_rgb')
    b = apply_rgb_gain(framed_b, gains)
    photometric = None if gains is None else photometric_diagnostics(framed_b, b, gains)
    mask = selection_mask(cfg['shape'], cfg['mask'])
    initial_sigma = float(cfg.get('mask_sigma', 0))
    finest = np.clip(gaussian(mask, initial_sigma), 0, 1)
    methods, final, details = _three_methods(a, b, mask, finest, cfg['bands'], cfg['base_sigma'])
    decomposition_error = float(np.max(np.abs(reconstruct(details['sum'])-final)))
    checks = {
        f'{method}_boundary_jump': _match(methods[method]['boundary_jump'], saved[key], cfg['id'] + '.' + key)
        for method, key in [('hard_cut', 'boundary_jump_hard'), ('feather', 'boundary_jump_feather'), ('multiscale', 'boundary_jump_multiscale')]
    }
    checks.update({
        'multiscale_clip_fraction': _match(methods['multiscale']['clip_fraction'], saved['clip_fraction'], cfg['id'] + '.clip_fraction'),
        'multiscale_range': _match(methods['multiscale']['range'], saved['range'], cfg['id'] + '.range'),
        'decomposition_error': _match(decomposition_error, saved['reconstruction_error'], cfg['id'] + '.reconstruction_error'),
        'a_matrix': _match(ma, saved['a_matrix'], cfg['id'] + '.a_matrix'),
        'b_matrix': _match(mb, saved['b_matrix'], cfg['id'] + '.b_matrix'),
    })
    if photometric is not None:
        for key, value in photometric.items():
            name = cfg['id'] + '.photometric_diagnostics.' + key
            checks['photometric_' + key] = (
                _equal(value, saved['photometric_diagnostics'][key], name)
                if isinstance(value, (str, bool)) else
                _match(value, saved['photometric_diagnostics'][key], name))
    refinement_trials = []
    if cfg.get('lighting_refinement_baseline'):
        prior_points = cfg['lighting_refinement_baseline']['b_points']
        prior_b, _ = align(original_b, prior_points, cfg['target_points'], cfg['shape'])
        controls = [(prior_b, prior_points, [1, 1, 1]),
                    (framed_b, cfg['b_points'], [1, 1, 1]),
                    (b, cfg['b_points'], gains)]
        assert len(saved['lighting_refinement_trials']) == len(controls)
        for index, (control, prior) in enumerate(zip(controls, saved['lighting_refinement_trials'])):
            source, points, gain = control
            result, _ = multiresolution_blend(a, source, finest, cfg['bands'], cfg['base_sigma'])
            record = {'b_points': points, 'b_gain_rgb': gain,
                      'boundary_jump': boundary_jump(result, mask),
                      'clip_fraction': clip_fraction(result), 'range': _range(result)}
            for key, value in record.items():
                name = f'{cfg["id"]}.lighting_refinement_trials.{index}.{key}'
                checks[f'lighting_refinement_{index}_{key}'] = _match(value, prior[key], name)
            refinement_trials.append(record)
    assert decomposition_error < 1e-12
    coarse_sigma = cfg['base_sigma'] * 2**(cfg['bands']-1)
    record = {'id': cfg['id'], 'title': cfg['title'], 'width': cfg['shape'][1], 'height': cfg['shape'][0],
            'registration': registration, 'a_matrix': ma.tolist(), 'b_matrix': mb.tolist(),
            'bands': cfg['bands'], 'base_sigma': cfg['base_sigma'], 'initial_mask_sigma': initial_sigma,
            'coarse_image_sigma': coarse_sigma,
            'coarse_mask_nominal_equivalent_sigma': float(np.hypot(initial_sigma, coarse_sigma)),
            'mask_kind': cfg['mask']['kind'], 'binary_mask_area_pixels': int(mask.sum()),
            'methods': methods, 'decomposition_max_abs_error': decomposition_error, 'saved_checks': checks}
    if photometric is not None:
        record['photometric_diagnostics'] = photometric
    if refinement_trials:
        record['lighting_refinement_trials'] = refinement_trials
    return record


def _validate_domains(value, path='audit'):
    """Fail rather than serialize a nonfinite or invalid diagnostic."""
    if isinstance(value, dict):
        for key, child in value.items():
            _validate_domains(child, f'{path}.{key}')
            if key in ('clip_fraction', 'clip_fraction_tolerance_1e6') and isinstance(child, (float, int)):
                assert 0 <= child <= 1, path
            if isinstance(child, (float, int)) and (key.endswith('_rms') or key in ('rms', 'boundary_jump') or key.startswith('high_to_low_contrast_ratio_')):
                assert child >= 0, path
    elif isinstance(value, list):
        for i, child in enumerate(value):
            _validate_domains(child, f'{path}[{i}]')
    elif isinstance(value, (float, int)) and not isinstance(value, bool):
        assert np.isfinite(value), f'{path} is not finite'


def compute_audit(config, saved_result):
    """Recompute diagnostics from the config, checking the saved result records."""
    saved = saved_result['measurements']
    hybrids, refinement = _selected_hybrids(config, saved)
    trace, oraple_blend = _oraple(config, saved['stacks'])
    prior_blends = {r['id']: r for r in saved['blends']}
    blends = [oraple_blend] + [_custom_blend(cfg, prior_blends[cfg['id']]) for cfg in config['blends']]
    result = {'schema_version': 1, 'config': 'frequencies_config.json',
              'reference_measurements': 'results/frequencies.json',
              'reproduce': '.venv/bin/python run_audit.py',
              'definitions': DEFINITIONS, 'hybrids': hybrids,
              # Retain this legacy key for packaged audit readers; its id and
              # title identify the geometry example independently of FAVORITE.
              'favorite_refinement': refinement, 'oraple_trace': trace, 'blends': blends,
              'validation': {'all_saved_checks_passed': True,
                             'three_primary_hybrids': len(hybrids) == 3,
                             'four_controlled_refinement_trials': len(refinement['trials']) == 4,
                             'six_oraple_trace_levels': len(trace['steps']) == 6,
                             'three_methods_on_three_blends': len(blends) == 3 and all(len(r['methods']) == 3 for r in blends),
                             'trace_endpoint_below_1e_12': trace['steps'][-1]['remaining_max_abs'] < 1e-12,
                             'all_numeric_domains_valid': True}}
    _validate_domains(result)
    assert all(result['validation'].values())
    return result


def write_audit(config=None, saved_result=None, output_path=None):
    """Write audit.json; callers may pass freshly generated report data directly."""
    if config is None:
        config = json.loads((ROOT / 'frequencies_config.json').read_text())
    if saved_result is None:
        saved_result = json.loads((ROOT / 'results/frequencies.json').read_text())
    result = compute_audit(config, saved_result)
    output_path = Path(output_path) if output_path is not None else ROOT / 'results/audit.json'
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    return result
