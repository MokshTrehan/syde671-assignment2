"""Reproducible filtering primitives for SYDE 671 Assignment 2.

The two convolution implementations below use only NumPy array operations.
Both implement true convolution (kernel flip), same-sized output, and zero
extension. For even kernels the asymmetric padding matches scipy.signal's
``convolve2d(..., mode='same', boundary='fill', fillvalue=0)`` convention.
"""
from __future__ import annotations

import numpy as np

DX = np.array([[1.0, 0.0, -1.0]])
DY = DX.T.copy()


def _convolution_inputs(image, kernel):
    image = np.asarray(image, dtype=np.float64)
    kernel = np.asarray(kernel, dtype=np.float64)
    if image.ndim != 2 or kernel.ndim != 2:
        raise ValueError("image and kernel must both be two dimensional")
    if not image.size or not kernel.size:
        raise ValueError("image and kernel must be nonempty")
    kh, kw = kernel.shape
    # Before = ceil((K-1)/2); after = floor((K-1)/2).
    padded = np.pad(image, ((kh // 2, (kh - 1) // 2),
                            (kw // 2, (kw - 1) // 2)), mode='constant')
    return image, kernel[::-1, ::-1], padded


def convolve_four_loops(image, kernel):
    """True 2-D convolution: two spatial loops and two kernel loops."""
    image, flipped, padded = _convolution_inputs(image, kernel)
    height, width = image.shape
    kh, kw = flipped.shape
    out = np.zeros_like(image)
    for y in range(height):
        for x in range(width):
            for ky in range(kh):
                for kx in range(kw):
                    out[y, x] += flipped[ky, kx] * padded[y + ky, x + kx]
    return out


def convolve_two_loops(image, kernel):
    """True 2-D convolution: kernel loops; spatial products are vectorized."""
    image, flipped, padded = _convolution_inputs(image, kernel)
    height, width = image.shape
    kh, kw = flipped.shape
    out = np.zeros_like(image)
    for ky in range(kh):
        for kx in range(kw):
            out += flipped[ky, kx] * padded[ky:ky + height, kx:kx + width]
    return out


def gradient_magnitude(gx, gy):
    return np.sqrt(np.asarray(gx) ** 2 + np.asarray(gy) ** 2)


def orientation_without_angles(gx, gy, terms=18):
    """Quadrant-correct atan2 equivalent using arithmetic and a Taylor series.

    No arctan/arctan2/angle function is used. Range reduction first replaces
    the ratio by min(|y|,|x|)/max(|y|,|x|), then uses
      atan(r) = pi/4 + atan((r-1)/(r+1)) for r > tan(pi/8).
    This bounds the series argument by sqrt(2)-1, giving fast convergence.
    At a zero gradient the angle is assigned zero (orientation is undefined).
    Signed-zero distinctions on the negative x-axis are immaterial for hue.
    """
    gx, gy = np.broadcast_arrays(np.asarray(gx, float), np.asarray(gy, float))
    if not np.all(np.isfinite(gx)) or not np.all(np.isfinite(gy)):
        raise ValueError('gradient components must be finite')
    if terms < 1:
        raise ValueError('terms must be positive')
    ax, ay = np.abs(gx), np.abs(gy)
    high, low = np.maximum(ax, ay), np.minimum(ax, ay)
    ratio = np.divide(low, high, out=np.zeros_like(high), where=high != 0)
    reduce = ratio > np.sqrt(2.0) - 1.0
    z = np.where(reduce, (ratio - 1.0) / (ratio + 1.0), ratio)
    # Horner evaluation of z - z^3/3 + z^5/5 - ... .
    z2 = z * z
    poly = np.zeros_like(z)
    for n in range(terms - 1, -1, -1):
        poly = ((-1.0) ** n) / (2 * n + 1) + z2 * poly
    small_angle = z * poly + np.where(reduce, np.pi / 4, 0.0)
    angle = np.where(ay > ax, np.pi / 2 - small_angle, small_angle)
    angle = np.where(gx < 0, np.pi - angle, angle)
    angle = np.where(gy < 0, -angle, angle)
    return np.where(high == 0, 0.0, angle)


def unsharp_kernel(gaussian, alpha):
    """(1+alpha)*delta - alpha*G, for an odd, normalized Gaussian G."""
    gaussian = np.asarray(gaussian, float)
    if gaussian.ndim != 2 or any(n % 2 == 0 for n in gaussian.shape):
        raise ValueError('Gaussian must have odd dimensions')
    if not np.isclose(gaussian.sum(), 1.0):
        raise ValueError('Gaussian must sum to one')
    kernel = -float(alpha) * gaussian.copy()
    kernel[gaussian.shape[0] // 2, gaussian.shape[1] // 2] += 1 + float(alpha)
    return kernel
