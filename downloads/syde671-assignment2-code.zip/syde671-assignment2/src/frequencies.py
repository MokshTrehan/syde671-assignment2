"""Reproducible hybrid images and full-resolution multiresolution blending.

Only convolution and geometric interpolation use SciPy/OpenCV primitives.
The Gaussian kernels, frequency decomposition, stacks, masks, weighted bands,
and reconstruction are explicit; no pyramid/stack convenience routine is used.
Float64 arrays represent intensity in [0,1] until filtering creates signed bands.
"""
from __future__ import annotations

import numpy as np
from scipy.ndimage import convolve1d
import cv2


def gaussian_kernel(sigma: float, truncate: float = 4.0) -> np.ndarray:
    """Unit-sum discrete Gaussian, sampled to +/-ceil(truncate*sigma)."""
    if sigma <= 0 or truncate <= 0:
        raise ValueError("sigma and truncate must be positive")
    radius = int(np.ceil(truncate * sigma))
    x = np.arange(-radius, radius + 1, dtype=np.float64)
    kernel = np.exp(-0.5 * (x / sigma) ** 2)
    return kernel / kernel.sum()


def gaussian(image: np.ndarray, sigma: float) -> np.ndarray:
    """Separable spatial Gaussian; spatial axes only, reflect boundary."""
    image = np.asarray(image, dtype=np.float64)
    if sigma == 0:
        return image.copy()
    kernel = gaussian_kernel(sigma)
    return convolve1d(convolve1d(image, kernel, axis=0, mode="reflect"),
                      kernel, axis=1, mode="reflect")


def grayscale(image: np.ndarray) -> np.ndarray:
    image = np.asarray(image, dtype=np.float64)
    return image if image.ndim == 2 else image[..., :3] @ np.array([0.2126, 0.7152, 0.0722])


def rgb(image: np.ndarray) -> np.ndarray:
    return np.repeat(image[..., None], 3, axis=2) if image.ndim == 2 else image


def similarity_matrix(source_points, destination_points) -> np.ndarray:
    """Unique orientation-preserving two-point similarity, no shear/reflection."""
    source = np.asarray(source_points, dtype=np.float64)
    destination = np.asarray(destination_points, dtype=np.float64)
    if source.shape != (2, 2) or destination.shape != (2, 2):
        raise ValueError("Two (x,y) points per image are required")
    s = complex(*(source[1] - source[0]))
    d = complex(*(destination[1] - destination[0]))
    if abs(s) < 1e-12 or abs(d) < 1e-12:
        raise ValueError("Landmarks must be distinct")
    z = d / s
    linear = np.array([[z.real, -z.imag], [z.imag, z.real]])
    translation = destination[0] - linear @ source[0]
    return np.column_stack((linear, translation))


def align(image, source_points, destination_points, shape=(512, 512)):
    """Return aligned image and source-to-destination 2x3 matrix.

    Edge replication avoids reflected duplicate facial features outside a crop."""
    matrix = similarity_matrix(source_points, destination_points)
    out = cv2.warpAffine(np.asarray(image, dtype=np.float64), matrix,
                         (shape[1], shape[0]), flags=cv2.INTER_LINEAR,
                         borderMode=cv2.BORDER_REPLICATE)
    return out, matrix


def hybrid(low_source, high_source, sigma_low, sigma_high, gain=1.0,
           low_color=True, high_color=True):
    if low_source.shape[:2] != high_source.shape[:2]:
        raise ValueError("Aligned sources must have equal spatial dimensions")
    a = rgb(low_source if low_color else grayscale(low_source))
    b = rgb(high_source if high_color else grayscale(high_source))
    low = gaussian(a, sigma_low)
    high = b - gaussian(b, sigma_high)
    return low + gain * high, low, gain * high


def gaussian_stack(image, bands=5, base_sigma=2.0):
    """G0=image; Gi=Gaussian(image, base_sigma*2**(i-1)), i=1..bands.

    All levels preserve resolution. Independent blurring at the stated sigma
    makes the effective cutoff unambiguous. Returns bands+1 arrays.
    """
    if bands < 1 or base_sigma <= 0:
        raise ValueError("Need at least one band and positive base sigma")
    image = np.asarray(image, dtype=np.float64)
    return [image.copy()] + [gaussian(image, base_sigma * 2 ** i) for i in range(bands)]


def laplacian_stack(image, bands=5, base_sigma=2.0):
    """L_i=G_i-G_(i+1); the last entry is the essential coarse residual."""
    gs = gaussian_stack(image, bands, base_sigma)
    return [gs[i] - gs[i+1] for i in range(bands)] + [gs[-1]], gs


def reconstruct(laplacians):
    return np.sum(np.stack(laplacians), axis=0)


def multiresolution_blend(a, b, mask, bands=5, base_sigma=2.0):
    """Blend full-resolution Laplacian bands with a matching Gaussian mask.

    mask=1 selects A and mask=0 selects B. Float, signed contributions are
    reconstructed without clipping; callers clip only when exporting a display.
    """
    a, b = np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64)
    mask = np.asarray(mask, dtype=np.float64)
    if a.shape != b.shape or mask.shape != a.shape[:2]:
        raise ValueError("Images must match; mask must match spatial dimensions")
    if not np.all(np.isfinite(mask)) or mask.min() < 0 or mask.max() > 1:
        raise ValueError("Mask must be finite and in [0,1]")
    la, ga = laplacian_stack(a, bands, base_sigma)
    lb, gb = laplacian_stack(b, bands, base_sigma)
    gm = gaussian_stack(mask, bands, base_sigma)
    weights = [g[..., None] if a.ndim == 3 else g for g in gm]
    ca = [m * l for m, l in zip(weights, la)]
    cb = [(1-m) * l for m, l in zip(weights, lb)]
    result = reconstruct(ca) + reconstruct(cb)
    return result, {"ga": ga, "gb": gb, "la": la, "lb": lb,
                    "gm": gm, "ca": ca, "cb": cb,
                    "sum": [x + y for x, y in zip(ca, cb)]}


def disk_mask(shape, center, radii):
    """Binary ellipse: curved, nonrectangular selection, not a vertical seam."""
    y, x = np.mgrid[:shape[0], :shape[1]]
    cx, cy = center
    rx, ry = radii
    return ((((x-cx)/rx)**2 + ((y-cy)/ry)**2) <= 1).astype(np.float64)


def log_spectrum(image):
    """Unwindowed log(1+|shifted 2-D Fourier transform|) of luminance."""
    return np.log1p(np.abs(np.fft.fftshift(np.fft.fft2(grayscale(image)))))


def clip_fraction(image):
    """Fraction of scalar channel values clipped by an [0,1] export."""
    return float(np.mean((image < 0) | (image > 1)))
