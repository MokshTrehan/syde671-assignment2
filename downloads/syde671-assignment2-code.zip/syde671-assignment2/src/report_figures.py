"""Consistent, documented figure exports for the assignment report."""
from pathlib import Path
import textwrap
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps
from .frequencies import rgb, log_spectrum, reconstruct
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'site/images'
OUT.mkdir(parents=True, exist_ok=True)
BG = (247, 247, 244)
FONT_PATHS = ['/System/Library/Fonts/Supplemental/Arial.ttf',
              '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']

def font(size=17):
    for path in FONT_PATHS:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default(size=size)



def read(path):
    return np.asarray(ImageOps.exif_transpose(Image.open(ROOT/path)).convert('RGB'), dtype=np.float64)/255



def pil(a):
    if isinstance(a, Image.Image):
        return a.convert('RGB')
    return Image.fromarray(np.uint8(np.rint(np.clip(rgb(a), 0, 1)*255)))



def save(a, name):
    path = OUT / (name + '.jpg')
    pil(a).save(path, quality=88, optimize=True)
    # Keep report panels comfortable to load without hiding data processing.
    if path.stat().st_size > 790000:
        pil(a).save(path, quality=76, optimize=True)
    return 'images/' + path.name



def grid(items, name, cols=3, size=(320,320)):
    w,h = size
    rowh = h+66
    canvas = Image.new('RGB', (cols*(w+16)+16, ((len(items)+cols-1)//cols)*rowh+16), BG)
    draw = ImageDraw.Draw(canvas)
    for i,(a,label) in enumerate(items):
        thumb = ImageOps.contain(pil(a), (w,h), Image.Resampling.LANCZOS)
        x=16+(i%cols)*(w+16); y=16+(i//cols)*rowh
        canvas.paste(thumb,(x+(w-thumb.width)//2,y+(h-thumb.height)//2))
        for j,line in enumerate(textwrap.wrap(label, max(18,int(w/8.8)))[:3]):
            draw.text((x,y+h+8+j*18),line,font=font(16),fill=(31,40,49))
    return save(canvas,name)



def mark(a, points):
    im = pil(a)
    d=ImageDraw.Draw(im)
    radius=max(4,int(min(im.size)*.010))
    for i,(x,y) in enumerate(points):
        d.ellipse((x-radius,y-radius,x+radius,y+radius), outline=(0,255,255),width=max(2,radius//3))
        d.text((x+radius+3,y-radius),str(i+1),fill=(0,255,255),font=font(max(16,radius*2)))
    return im



def near_far(a, name):
    canvas=Image.new('RGB',(1056,572),BG)
    d=ImageDraw.Draw(canvas)
    x=16
    for width in [512,256,128,64]:
        im=pil(a).resize((width,width),Image.Resampling.LANCZOS)
        canvas.paste(im,(x,24+(512-width)//2))
        d.text((x,544),str(width)+' px',font=font(16),fill=(31,40,49))
        x+=width+20
    return save(canvas,name)



def spectrum_panel(a, vmax):
    return log_spectrum(a)/max(vmax,1e-12)



def signed_row(arrays):
    # Same scaling across A, B and sum within a band; no independent contrast.
    scale=max(float(np.quantile(np.abs(a),.995)) for a in arrays)
    scale=max(scale,1e-8)
    return [0.5 + .45*a/scale for a in arrays], scale



def contribution_figure(details,name,levels=(0,2,4)):
    items=[]; scales=[]
    for level in levels:
        arrays=[details['ca'][level],details['cb'][level],details['sum'][level]]
        shown,scale=signed_row(arrays); scales.append(scale)
        for a,col in zip(shown,['masked A','masked B','sum']):
            items.append((a,f'({chr(97+len(items))}) L{level}: {col}'))
    for arr,label in [(reconstruct(details['ca']),'Reconstructed A contribution'),
                      (reconstruct(details['cb']),'Reconstructed B contribution'),
                      (reconstruct(details['sum']),'Final reconstruction')]:
        items.append((arr,f'({chr(97+len(items))}) {label}'))
    return grid(items,name,3,(300,240)),scales



def describe(fig,caption):
    return {'path':fig,'caption':caption}



def section(id,title,paragraphs=None,figures=None,tables=None,code=None):
    return {'id':id,'title':title,'paragraphs':paragraphs or [],'figures':figures or [],'tables':tables or [],'code':code or []}

