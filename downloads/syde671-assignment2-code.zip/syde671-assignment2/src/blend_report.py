"""Custom blends with complete registered inputs and controlled baselines."""
import numpy as np
import cv2
from PIL import Image, ImageDraw
from .frequencies import (align, grayscale, gaussian, multiresolution_blend,
                          reconstruct, clip_fraction)
from .report_figures import read, pil, save, grid, mark, contribution_figure, describe, section


def fit_disk_registration(image, specification, shape):
    """Fit the largest bright disk contour and map its ellipse to a circle.

    Thresholding is used ONLY to measure geometry. The warp samples the original
    RGB image; the thresholded image never replaces or masks any output pixels.
    R diag(target_radius/source_radii) R.T removes ellipse anisotropy without
    introducing a global rotation of the photographed surface.
    """
    threshold = float(specification['luminance_threshold'])
    if not 0 < threshold < 1:
        raise ValueError('Disk luminance threshold must be between zero and one')
    binary = (grayscale(image) > threshold).astype(np.uint8)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        raise ValueError('No disk found at the configured luminance threshold')
    contour = max(contours, key=cv2.contourArea)
    if len(contour) < 5:
        raise ValueError('At least five contour points are needed for an ellipse')
    center, diameters, angle_degrees = cv2.fitEllipse(contour)
    source_center = np.asarray(center, dtype=np.float64)
    radii = np.asarray(diameters, dtype=np.float64) / 2
    target_center = np.asarray(specification['target_center'], dtype=np.float64)
    target_radius = float(specification['target_radius'])
    if min(radii) <= 0 or target_radius <= 0:
        raise ValueError('Source and target ellipse radii must be positive')
    angle = np.deg2rad(angle_degrees)
    rotation = np.array([[np.cos(angle), -np.sin(angle)],
                         [np.sin(angle), np.cos(angle)]])
    axis_scales = target_radius / radii
    linear = rotation @ np.diag(axis_scales) @ rotation.T
    matrix = np.column_stack((linear, target_center - linear @ source_center))
    registered = cv2.warpAffine(image, matrix, (shape[1], shape[0]),
                               flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    contour_points = contour[:, 0].astype(np.float64)
    transformed = contour_points @ linear.T + matrix[:, 2]
    radial_error = np.linalg.norm(transformed - target_center, axis=1) - target_radius
    fit = {
        'method': 'largest external contour of luminance > threshold; cv2.fitEllipse',
        'contour_sampling': 'cv2.CHAIN_APPROX_NONE',
        'luminance_threshold': threshold,
        'source_center': source_center.tolist(),
        'source_diameters': list(diameters),
        'source_angle_degrees': float(angle_degrees),
        'contour_point_count': int(len(contour)),
        'target_center': target_center.tolist(), 'target_radius': target_radius,
        'axis_scale_factors': axis_scales.tolist(),
        'axis_scale_ratio': float(max(axis_scales) / min(axis_scales)),
        'registered_contour_radial_rmse': float(np.sqrt(np.mean(radial_error**2)))
    }
    return registered, matrix, fit


def ellipse_annotation(image, center, diameters, angle_degrees=0):
    """Cyan geometry annotation for report panels, never for synthesis."""
    im = pil(image)
    theta = np.linspace(0, 2 * np.pi, 361)
    angle = np.deg2rad(angle_degrees)
    rotation = np.array([[np.cos(angle), -np.sin(angle)],
                         [np.sin(angle), np.cos(angle)]])
    points = (np.column_stack((np.cos(theta), np.sin(theta))) *
              (np.asarray(diameters) / 2)) @ rotation.T + np.asarray(center)
    ImageDraw.Draw(im).line([tuple(p) for p in points], fill=(0, 255, 255),
                            width=max(2, round(min(im.size) * .004)))
    return im


def selection_mask(shape, specification):
    """Rasterize saved output-pixel coordinates; white always selects A."""
    h, w = shape
    if specification['kind'] == 'polygon':
        canvas = Image.new('L', (w, h), 0)
        ImageDraw.Draw(canvas).polygon([tuple(p) for p in specification['vertices']], fill=255)
        return np.asarray(canvas, dtype=np.float64) / 255
    if specification['kind'] == 'sinusoidal':
        y, x = np.indices((h, w))
        boundary = (specification['center_x'] + specification['amplitude'] *
                    np.sin(2 * np.pi * (y - specification['origin_y']) / specification['period']))
        return (x < boundary).astype(np.float64)
    raise ValueError('Unknown custom-blend mask kind')


def boundary_jump(image, mask):
    """Mean channel difference across adjacent pixels straddling the binary contour.

    Includes natural texture; a local diagnostic, not a perceptual quality score.
    """
    horizontal = mask[:, 1:] != mask[:, :-1]
    vertical = mask[1:] != mask[:-1]
    jumps = np.concatenate((np.abs(image[:, 1:] - image[:, :-1])[horizontal].ravel(),
                            np.abs(image[1:] - image[:-1])[vertical].ravel()))
    return float(jumps.mean())


def figure(path, caption, heading, supplement=False):
    result = describe(path, caption)
    result['heading'] = heading
    if supplement:
        result['supplement'] = True
    return result


def make_custom_blends(config):
    figs, metrics, rows, color_items = [], [], [], []
    for cfg in config['blends']:
        ident = cfg['id']
        print('Blend:', ident, flush=True)
        original_a, original_b = read(cfg['a_path']), read(cfg['b_path'])
        registration = cfg.get('registration', {'kind': 'two_point_similarity'})
        fits = None
        if registration['kind'] == 'ellipse_to_circle':
            a, matrix_a, fit_a = fit_disk_registration(original_a, registration, cfg['shape'])
            b, matrix_b, fit_b = fit_disk_registration(original_b, registration, cfg['shape'])
            fits = {'a': fit_a, 'b': fit_b}
            marked = [ellipse_annotation(im, fit['source_center'], fit['source_diameters'],
                                         fit['source_angle_degrees'])
                      for im, fit in [(original_a, fit_a), (original_b, fit_b)]]
            marked += [ellipse_annotation(im, registration['target_center'],
                                          [2 * registration['target_radius']] * 2)
                       for im in [a, b]]
            registration_caption = (
                'Cyan outlines show fitted source ellipses and the common target circle. '
                f'The largest external contour above luminance {registration["luminance_threshold"]:g} '
                'is fitted with cv2.fitEllipse, then mapped affinely to a circle. '
                f'The differential axis scaling is {100 * (fit_a["axis_scale_ratio"]-1):.2f}% '
                f'for Earth and {100 * (fit_b["axis_scale_ratio"]-1):.2f}% for the Moon. '
                'Thresholding measures geometry only; the warp samples the original RGB pixels. ')
        elif registration['kind'] == 'two_point_similarity':
            a, matrix_a = align(original_a, cfg['a_points'], cfg['target_points'], cfg['shape'])
            b, matrix_b = align(original_b, cfg['b_points'], cfg['target_points'], cfg['shape'])
            marked = [mark(original_a, cfg['a_points']), mark(original_b, cfg['b_points']),
                      mark(a, cfg['target_points']), mark(b, cfg['target_points'])]
            registration_caption = ('Cyan marks show eye centers and their shared destination. '
                'The cat inputs use similarity transforms (uniform scale, rotation and translation). ')
        else:
            raise ValueError('Unknown custom-blend registration kind')
        mask = selection_mask(cfg['shape'], cfg['mask'])
        hard = mask[..., None] * a + (1 - mask[..., None]) * b
        final, details = multiresolution_blend(a, b, mask, cfg['bands'], cfg['base_sigma'])
        coarse_sigma = cfg['base_sigma'] * 2 ** (cfg['bands'] - 1)
        # Same broad mask as the residual; feathering applies it to ALL image
        # frequencies, while the stack uses a different mask for each band.
        soft_mask = gaussian(mask, coarse_sigma)
        feather = soft_mask[..., None] * a + (1 - soft_mask[..., None]) * b
        final_path = save(final, 'blend_' + ident + '_final')
        credit = ' ' + cfg['derivative_notice']
        inputs = grid([
            (marked[0], 'Original A: ' + cfg['a_label']),
            (marked[1], 'Original B: ' + cfg['b_label']),
            (marked[2], 'Registered A: 512 x 512'),
            (marked[3], 'Registered B: 512 x 512')],
            'blend_' + ident + '_inputs', 4, (260, 310))
        figs.append(figure(inputs, cfg['title'] + ': original photographs and complete '
            'registered inputs. ' + cfg['alignment_note'] + ' ' + registration_caption +
            'Both methods use bilinear interpolation and replicated borders. There is no exposure matching, color '
            'correction, background replacement or retouching. Every baseline receives '
            'exactly these registered arrays.' + credit, cfg['title'] + ' · Inputs and registration'))
        comparison = grid([(mask, 'Binary mask: white selects A'),
            (hard, 'Direct hard cut'),
            (feather, f'Single-scale feather: sigma={coarse_sigma:g} px'),
            (final, f'Multiscale: {cfg["bands"]} detail bands + residual')],
            'blend_' + ident + '_comparison', 2, (390, 390))
        figs.append(figure(comparison, cfg['title'] + ': controlled baselines using the '
            'same alignment and binary selection. Feathering applies the stack’s coarsest '
            'Gaussian mask to every image frequency; the multiscale result uses the '
            'corresponding mask at each Laplacian band. ' + cfg['visual_observation']
            + credit, cfg['title'] + ' · Mask and fair baselines'))

        x0, y0, x1, y1 = cfg['detail_crop']
        crops = grid([(im[y0:y1, x0:x1], label) for im, label in [
            (hard, 'Hard cut / same crop'), (feather, 'Single-scale feather / same crop'),
            (final, 'Multiscale / same crop')]], 'blend_' + ident + '_detail', 3, (345, 240))
        figs.append(figure(crops,
            f'Identical boundary crops, x={x0}:{x1}, y={y0}:{y1}, with identical display '
            'scaling. ' + cfg['crop_observation'] + credit,
            cfg['title'] + ' · Boundary detail', supplement=True))
        mask_stack = grid([(m, f'M{i}: ' + ('binary mask' if i == 0 else
            f'sigma={cfg["base_sigma"] * 2 ** (i-1):g} px')) for i, m in enumerate(details['gm'])],
            'blend_' + ident + '_maskstack', len(details['gm']), (190, 190))
        figs.append(figure(mask_stack, cfg['title'] + ': all Gaussian mask levels, including '
            'the coarse residual weight. All arrays remain 512 x 512.',
            cfg['title'] + ' · Complete mask stack', supplement=True))
        sweep_items, sweep_records = [], []
        for bands in cfg['trial_bands']:
            trial, _ = multiresolution_blend(a, b, mask, bands, cfg['base_sigma'])
            sigma = cfg['base_sigma'] * 2 ** (bands - 1)
            chosen = ' [selected]' if bands == cfg['bands'] else ''
            sweep_items.append((trial, f'{bands} bands; coarse sigma={sigma:g}{chosen}'))
            sweep_records.append({'bands': bands, 'coarse_sigma': sigma,
                'boundary_jump': boundary_jump(trial, mask), 'clip_fraction': clip_fraction(trial)})
        sweep = grid(sweep_items, 'blend_' + ident + '_sweep', len(sweep_items), (320, 320))
        figs.append(figure(sweep, 'Controlled scale sweep: sources, transform, mask and '
            'base sigma remain fixed; only the number of detail bands changes. '
            + cfg['selection_note'] + credit, cfg['title'] + ' · Scale selection', supplement=True))
        record = dict(cfg, a_matrix=matrix_a.tolist(), b_matrix=matrix_b.tolist(),
            coarse_sigma=coarse_sigma, feather_sigma=coarse_sigma, source_precomposition=False,
            clip_fraction=clip_fraction(final), range=[float(final.min()), float(final.max())],
            reconstruction_error=float(np.max(np.abs(reconstruct(details['sum']) - final))),
            boundary_jump_hard=boundary_jump(hard, mask),
            boundary_jump_feather=boundary_jump(feather, mask),
            boundary_jump_multiscale=boundary_jump(final, mask),
            final=final_path, mask_area_pixels=int(mask.sum()), trial_results=sweep_records)
        if fits is not None:
            record['registration_fits'] = fits
        if cfg.get('favorite'):
            process, scales = contribution_figure(details, 'blend_' + ident + '_process', (0, 2, 4))
            figs.append(figure(process, 'Favorite blend, ' + cfg['title'] + ': rows 1–3 show '
                'masked A, masked B and their sum at Laplacian levels 0, 2 and 4. The final '
                'row reconstructs each contribution and the result using ALL detail bands '
                'plus the coarse residual, following Burt–Adelson Figure 10. Each detail '
                'row uses one shared symmetric contrast scale; reconstructed rows retain '
                'actual intensity.' + credit, 'Favorite blend · Twelve-panel multiscale process'))
            record['process_shared_row_scales'] = scales
        gray, _ = multiresolution_blend(grayscale(a), grayscale(b), mask, cfg['bands'], cfg['base_sigma'])
        color_items.extend([(gray, cfg['title'] + ' / luminance'), (final, cfg['title'] + ' / RGB')])
        metrics.append(record)
        rows.append([cfg['title'], cfg['mask']['kind'], str(cfg['bands']), f'{coarse_sigma:g}',
            f'{record["boundary_jump_hard"]:.4f}', f'{record["boundary_jump_feather"]:.4f}',
            f'{record["boundary_jump_multiscale"]:.4f}',
            f'{100 * clip_fraction(final):.2f}%'])
    color_path = grid(color_items, 'blend_custom_color_comparison', 2, (390, 390))
    figs.append(figure(color_path, 'Controlled luminance-versus-RGB comparison. Registration, '
        'masks and all stack settings remain fixed. Luminance is 0.2126R + 0.7152G + 0.0722B; '
        'RGB channels are blended independently. Tabby and Moon derivatives in this figure '
        'are distributed under CC BY-SA 3.0; source credits are listed below.',
        'Color experiment · Luminance and RGB'))
    paragraphs = [
        'Tabby disguise transfers the tabby’s central face onto the orange-and-white cat '
        'while retaining the destination’s ears, whiskers and chest. An irregular 18-vertex '
        'polygon follows the forehead and cheeks. Eye-center alignment puts the face '
        'texture in a plausible position. The hard cut exposes the polygon immediately; '
        'multiscale blending softens the coat-color transition while keeping the transferred '
        'eyes and fur crisp.',
        'One world, two surfaces is an imaginary globe: Earth’s oceans and clouds transition '
        'into lunar craters along an S-shaped boundary. Ellipses fitted to the largest '
        'source contours above luminance 0.04 are mapped to a shared circle. This affine '
        'registration corrects approximately 1% anisotropy in the photographed Earth '
        'outline; the Moon needs almost uniform scaling. Thresholding only measures '
        'geometry and does not mask or recolor either photograph. Their shared round outline supports this composite '
        'even though their textures did not produce a convincing frequency-switching '
        'hybrid. This is an artistic surface fusion, not an astronomical depiction.',
        'Both examples use the entire registered source photographs. The background is '
        'never copied into the other source before filtering. Hard cut, single-scale '
        'feathering and multiscale blending receive identical arrays and the same binary '
        'mask. The feather baseline uses the coarsest Gaussian mask on the full images: '
        'its wide transition mixes competing fine details as well as broad colors.',
        'The cat uses five detail bands (sigma = 2, 4, 8, 16, 32 pixels); the globe uses '
        'six (2, 4, 8, 16, 32, 64 pixels). Both retain their coarse residual. Supplementary '
        'sweeps test four, five and six bands without changing other inputs. For the cat, '
        '16 pixels leaves a more conspicuous facial patch; 32 softens the coat boundary '
        'without the broader tonal spill of 64. The globe benefits from 64 pixels because '
        'its brightness mismatch spans a large fraction of the disk.',
        'Compared with broad feathering, the cat’s cheek and muzzle retain more definite '
        'tabby detail; feathering mixes both faces over a broad transition. At the globe’s '
        'boundary, clouds and crater detail remain more localized in the multiscale result. '
        'The boundary-jump values below measure adjacent RGB differences across the original '
        'binary contour. Feathering gives still smaller jumps because it mixes more '
        'image detail; minimizing this number would not select the most convincing '
        'photograph. It is a local seam diagnostic, not a perceptual score or proof '
        'of physical realism.',
        'Color helps both concepts. The warm tabby patch remains distinct from white fur '
        'and orange ears; grayscale makes these coat regions less distinct. The globe’s '
        'blue oceans contrast with the nearly neutral Moon and make the two surfaces '
        'easier to identify. I prefer RGB for the final composites; grayscale controls '
        'show that seam smoothing also works without this color cue.',
        'Multiresolution blending cannot fix anatomical or surface mismatches. The cats '
        'still differ slightly in muzzle shape and fur direction, and lunar features '
        'cannot continue Earth’s clouds naturally. A small transition remains where the '
        'globe seam meets the outer limb. These limitations remain visible in the '
        'unretouched results and matched close-ups. Processing stays signed float64; '
        'only final image display is clipped to [0,1].'
    ]
    sec = section('blend-custom', 'Two custom color blends · Irregular selections', paragraphs,
        figs, [{'title': 'Custom-blend settings and local boundary diagnostic',
        'columns': ['Blend', 'Mask', 'Bands', 'Max sigma', 'Hard jump',
                    'Feather jump', 'Stack jump', 'Clipped'], 'rows': rows}])
    return sec, metrics
