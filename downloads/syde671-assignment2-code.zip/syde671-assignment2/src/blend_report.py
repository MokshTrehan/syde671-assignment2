"""Custom blends with complete registered inputs and controlled baselines."""
import numpy as np
import cv2
from PIL import Image, ImageDraw
from .frequencies import (align, grayscale, gaussian, multiresolution_blend,
                          reconstruct, clip_fraction, apply_rgb_gain)
from .report_figures import read, pil, save, grid, mark, contribution_figure, describe, section


def fit_disk_registration(image, specification, shape):
    """Fit the largest bright disk contour and map its ellipse to a circle.

    Thresholding is used ONLY to measure geometry. The warp samples the original
    RGB image; the thresholded image never replaces or masks any output pixels.
    R diag(target_radius/source_radii) R.T removes ellipse anisotropy without
    introducing a global rotation of the photographed surface.
    """
    threshold = float(specification['luminance_threshold'])
    if not 0 < threshold < 1:
        raise ValueError('Disk luminance threshold must be between zero and one')
    binary = (grayscale(image) > threshold).astype(np.uint8)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        raise ValueError('No disk found at the configured luminance threshold')
    contour = max(contours, key=cv2.contourArea)
    if len(contour) < 5:
        raise ValueError('At least five contour points are needed for an ellipse')
    center, diameters, angle_degrees = cv2.fitEllipse(contour)
    source_center = np.asarray(center, dtype=np.float64)
    radii = np.asarray(diameters, dtype=np.float64) / 2
    target_center = np.asarray(specification['target_center'], dtype=np.float64)
    target_radius = float(specification['target_radius'])
    if min(radii) <= 0 or target_radius <= 0:
        raise ValueError('Source and target ellipse radii must be positive')
    angle = np.deg2rad(angle_degrees)
    rotation = np.array([[np.cos(angle), -np.sin(angle)],
                         [np.sin(angle), np.cos(angle)]])
    axis_scales = target_radius / radii
    linear = rotation @ np.diag(axis_scales) @ rotation.T
    matrix = np.column_stack((linear, target_center - linear @ source_center))
    registered = cv2.warpAffine(image, matrix, (shape[1], shape[0]),
                               flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    contour_points = contour[:, 0].astype(np.float64)
    transformed = contour_points @ linear.T + matrix[:, 2]
    radial_error = np.linalg.norm(transformed - target_center, axis=1) - target_radius
    fit = {
        'method': 'largest external contour of luminance > threshold; cv2.fitEllipse',
        'contour_sampling': 'cv2.CHAIN_APPROX_NONE',
        'luminance_threshold': threshold,
        'source_center': source_center.tolist(),
        'source_diameters': list(diameters),
        'source_angle_degrees': float(angle_degrees),
        'contour_point_count': int(len(contour)),
        'target_center': target_center.tolist(), 'target_radius': target_radius,
        'axis_scale_factors': axis_scales.tolist(),
        'axis_scale_ratio': float(max(axis_scales) / min(axis_scales)),
        'registered_contour_radial_rmse': float(np.sqrt(np.mean(radial_error**2)))
    }
    return registered, matrix, fit


def ellipse_annotation(image, center, diameters, angle_degrees=0):
    """Cyan geometry annotation for report panels, never for synthesis."""
    im = pil(image)
    theta = np.linspace(0, 2 * np.pi, 361)
    angle = np.deg2rad(angle_degrees)
    rotation = np.array([[np.cos(angle), -np.sin(angle)],
                         [np.sin(angle), np.cos(angle)]])
    points = (np.column_stack((np.cos(theta), np.sin(theta))) *
              (np.asarray(diameters) / 2)) @ rotation.T + np.asarray(center)
    ImageDraw.Draw(im).line([tuple(p) for p in points], fill=(0, 255, 255),
                            width=max(2, round(min(im.size) * .004)))
    return im


def selection_mask(shape, specification):
    """Rasterize saved output-pixel coordinates; white always selects A."""
    h, w = shape
    if specification['kind'] == 'polygon':
        canvas = Image.new('L', (w, h), 0)
        ImageDraw.Draw(canvas).polygon([tuple(p) for p in specification['vertices']], fill=255)
        return np.asarray(canvas, dtype=np.float64) / 255
    if specification['kind'] == 'sinusoidal':
        y, x = np.indices((h, w))
        boundary = (specification['center_x'] + specification['amplitude'] *
                    np.sin(2 * np.pi * (y - specification['origin_y']) / specification['period']))
        return (x < boundary).astype(np.float64)
    raise ValueError('Unknown custom-blend mask kind')


def boundary_jump(image, mask):
    """Mean channel difference across adjacent pixels straddling the binary contour.

    Includes natural texture; a local diagnostic, not a perceptual quality score.
    """
    horizontal = mask[:, 1:] != mask[:, :-1]
    vertical = mask[1:] != mask[:-1]
    jumps = np.concatenate((np.abs(image[:, 1:] - image[:, :-1])[horizontal].ravel(),
                            np.abs(image[1:] - image[:-1])[vertical].ravel()))
    return float(jumps.mean())


def figure(path, caption, heading, supplement=False):
    result = describe(path, caption)
    result['heading'] = heading
    if supplement:
        result['supplement'] = True
    return result


def photometric_diagnostics(before, after, gains):
    """Record display-range excursions without changing the synthesis arrays."""
    return {
        'b_gain_rgb': np.asarray(gains, dtype=np.float64).tolist(),
        'domain': 'stored RGB; spatially uniform multiplication after framing',
        'intermediate_clipping': False,
        'b_range_before_gain': [float(before.min()), float(before.max())],
        'b_range_after_gain': [float(after.min()), float(after.max())],
        'b_out_of_display_count': int(np.count_nonzero((after < 0) | (after > 1))),
        'b_out_of_display_fraction': clip_fraction(after),
    }


def lighting_refinement(cfg, original_b, a, framed_b, corrected_b, mask, finest_mask):
    """Hold all blending settings fixed while separating framing and RGB gain."""
    baseline = cfg['lighting_refinement_baseline']
    old_b, _ = align(original_b, baseline['b_points'], cfg['target_points'], cfg['shape'])
    gains = cfg['photometric']['b_gain_rgb']
    controls = [
        ('Original crop / no color adjustment', old_b, baseline['b_points'], [1, 1, 1]),
        ('Selected crop / no color adjustment', framed_b, cfg['b_points'], [1, 1, 1]),
        ('Selected crop / uniform RGB gains', corrected_b, cfg['b_points'], gains),
    ]
    items, records = [], []
    for label, b, points, gain in controls:
        result, _ = multiresolution_blend(a, b, finest_mask, cfg['bands'], cfg['base_sigma'])
        items.append((result, label))
        records.append({'label': label, 'b_points': points, 'b_gain_rgb': gain,
                        'boundary_jump': boundary_jump(result, mask),
                        'clip_fraction': clip_fraction(result),
                        'range': [float(result.min()), float(result.max())]})
    path = grid(items, 'blend_' + cfg['id'] + '_lighting_refinement', 3, (390, 390))
    caption = (
        'Controlled lighting refinement: original Denali crop without color adjustment; '
        'selected crop without adjustment; selected crop with uniform RGB gains '
        f'({gains[0]:g}, {gains[1]:g}, {gains[2]:g}). Rainier, the polygon, initial-mask '
        f'sigma {cfg.get("mask_sigma", 0):g}, all {cfg["bands"]} detail bands and the '
        'coarse residual remain fixed. The correction reduces the mauve-blue cast '
        'without local retouching. It is an empirical adjustment of stored RGB, '
        'not a physical relighting model. All panels retain signed values until display export.')
    return figure(path, caption, cfg['title'] + ' · Lighting refinement', supplement=True), records


def make_custom_blends(config):
    figs, metrics, rows, color_items = [], [], [], []
    refinement_figures = []
    for cfg in config['blends']:
        ident = cfg['id']
        print('Blend:', ident, flush=True)
        original_a, original_b = read(cfg['a_path']), read(cfg['b_path'])
        registration = cfg.get('registration', {'kind': 'two_point_similarity'})
        fits = None
        framing_only = registration.get('purpose', '').startswith('independent framing')
        input_term = 'Framed' if framing_only else 'Registered'
        transform_term = 'framing' if framing_only else 'registration'
        if registration['kind'] == 'ellipse_to_circle':
            a, matrix_a, fit_a = fit_disk_registration(original_a, registration, cfg['shape'])
            b, matrix_b, fit_b = fit_disk_registration(original_b, registration, cfg['shape'])
            fits = {'a': fit_a, 'b': fit_b}
            marked = [ellipse_annotation(im, fit['source_center'], fit['source_diameters'],
                                         fit['source_angle_degrees'])
                      for im, fit in [(original_a, fit_a), (original_b, fit_b)]]
            marked += [ellipse_annotation(im, registration['target_center'],
                                          [2 * registration['target_radius']] * 2)
                       for im in [a, b]]
            registration_caption = (
                'Cyan outlines mark the fitted source ellipses and target circle. '
                f'The larger axis scale factor exceeds the smaller by {100 * (fit_a["axis_scale_ratio"]-1):.2f}% '
                f'for Earth and {100 * (fit_b["axis_scale_ratio"]-1):.2f}% for the Moon. ')
        elif registration['kind'] == 'two_point_similarity':
            a, matrix_a = align(original_a, cfg['a_points'], cfg['target_points'], cfg['shape'])
            b, matrix_b = align(original_b, cfg['b_points'], cfg['target_points'], cfg['shape'])
            marked = [mark(original_a, cfg['a_points']), mark(original_b, cfg['b_points']),
                      mark(a, cfg['target_points']), mark(b, cfg['target_points'])]
            registration_caption = cfg.get('registration_caption',
                'Cyan circles mark the eye centers and their common output positions. ')
        else:
            raise ValueError('Unknown custom-blend registration kind')
        framed_b = b
        gains = cfg.get('photometric', {}).get('b_gain_rgb')
        b = apply_rgb_gain(framed_b, gains)
        photometric = None
        b_label = input_term + ' B: 512 x 512'
        if gains is not None:
            photometric = photometric_diagnostics(framed_b, b, gains)
            if registration['kind'] == 'two_point_similarity':
                marked[3] = mark(b, cfg['target_points'])
            else:
                marked[3] = ellipse_annotation(b, registration['target_center'],
                                               [2 * registration['target_radius']] * 2)
            b_label = input_term + ' B: corrected RGB'
            registration_caption += (
                f'After framing, B uses uniform RGB gains ({gains[0]:g}, {gains[1]:g}, '
                f'{gains[2]:g}) in stored RGB space, with no intermediate clipping. '
                'The original photographs above remain unmodified. ')
        mask = selection_mask(cfg['shape'], cfg['mask'])
        mask_sigma = float(cfg.get('mask_sigma', 0))
        # Smoothing the selection weights avoids a hard source switch in the
        # finest band. Clip only roundoff in mask weights, never image bands.
        finest_mask = np.clip(gaussian(mask, mask_sigma), 0, 1)
        hard = mask[..., None] * a + (1 - mask[..., None]) * b
        final, details = multiresolution_blend(a, b, finest_mask, cfg['bands'], cfg['base_sigma'])
        coarse_sigma = cfg['base_sigma'] * 2 ** (cfg['bands'] - 1)
        feather_sigma = float(np.hypot(mask_sigma, coarse_sigma))
        # Same broad mask as the residual; feathering applies it to ALL image
        # frequencies, while the stack uses a different mask for each band.
        soft_mask = details['gm'][-1]
        feather = soft_mask[..., None] * a + (1 - soft_mask[..., None]) * b
        final_path = save(final, 'blend_' + ident + '_final')
        credit = ' ' + cfg['derivative_notice']
        inputs = grid([
            (marked[0], 'Original A: ' + cfg['a_label']),
            (marked[1], 'Original B: ' + cfg['b_label']),
            (marked[2], input_term + ' A: 512 x 512'),
            (marked[3], b_label)],
            'blend_' + ident + '_inputs', 4, (260, 310))
        figs.append(figure(inputs, cfg['title'] + ': original and ' + input_term.lower() + ' photographs. '
            + registration_caption + credit,
            cfg['title'] + ' · Inputs and ' + transform_term))
        comparison = grid([(mask, 'Binary mask: white selects A'),
            (hard, 'Direct hard cut'),
            (feather, f'Single-scale feather: sigma~{feather_sigma:.1f} px'),
            (final, f'Multiscale: {cfg["bands"]} detail bands + residual')],
            'blend_' + ident + '_comparison', 2, (390, 390))
        figs.append(figure(comparison, cfg['title'] + ': three methods using the '
            'same ' + input_term.lower() + ' inputs and underlying binary selection. '
            + (f'The initial mask is smoothed at sigma={mask_sigma:g} pixels before '
               'the mask stack is constructed. '
               if mask_sigma else '') + cfg['visual_observation'],
            cfg['title'] + ' · Blending methods'))

        x0, y0, x1, y1 = cfg['detail_crop']
        crops = grid([(im[y0:y1, x0:x1], label) for im, label in [
            (hard, 'Hard cut / same crop'), (feather, 'Single-scale feather / same crop'),
            (final, 'Multiscale / same crop')]], 'blend_' + ident + '_detail', 3, (345, 240))
        figs.append(figure(crops,
            f'The same boundary crop, x={x0}:{x1}, y={y0}:{y1}, shown at one display '
            'scale for all three methods. ' + cfg['crop_observation'],
            cfg['title'] + ' · Boundary detail', supplement=True))
        mask_scales = [mask_sigma] + [float(np.hypot(mask_sigma,
            cfg['base_sigma'] * 2 ** i)) for i in range(cfg['bands'])]
        mask_stack = grid([(m, f'M{i}: ' + ('binary mask' if scale == 0 else
            f'sigma~{scale:.1f} px')) for i, (m, scale) in enumerate(zip(details['gm'], mask_scales))],
            'blend_' + ident + '_maskstack', len(details['gm']), (190, 190))
        figs.append(figure(mask_stack, cfg['title'] + ': Gaussian mask levels, including '
            'the coarse residual weight, all at 512 x 512 pixels. '
            + ('Each stack Gaussian acts on the initially smoothed mask. Labels show '
               'the nominal equivalent widths sqrt(initial_sigma^2 + stack_sigma^2); '
               'the weights use the discrete convolutions.' if mask_sigma else ''),
            cfg['title'] + ' · Complete mask stack', supplement=True))
        sweep_items, sweep_records = [], []
        for bands in cfg['trial_bands']:
            trial, _ = multiresolution_blend(a, b, finest_mask, bands, cfg['base_sigma'])
            sigma = cfg['base_sigma'] * 2 ** (bands - 1)
            chosen = ' [selected]' if bands == cfg['bands'] else ''
            sweep_items.append((trial, f'{bands} bands; coarse sigma={sigma:g}{chosen}'))
            sweep_records.append({'bands': bands, 'coarse_sigma': sigma,
                'boundary_jump': boundary_jump(trial, mask), 'clip_fraction': clip_fraction(trial)})
        sweep = grid(sweep_items, 'blend_' + ident + '_sweep', len(sweep_items), (320, 320))
        figs.append(figure(sweep, 'The number of detail bands varies while the sources, '
            + transform_term + ', mask and base sigma remain fixed. '
            + cfg['selection_note'], cfg['title'] + ' · Number of detail bands', supplement=True))
        mask_trials = []
        if cfg.get('trial_mask_sigmas'):
            trial_items = []
            cx0, cy0, cx1, cy1 = cfg['mask_trial_crop']
            for sigma in cfg['trial_mask_sigmas']:
                trial_mask = np.clip(gaussian(mask, sigma), 0, 1)
                trial, _ = multiresolution_blend(a, b, trial_mask, cfg['bands'], cfg['base_sigma'])
                chosen = ' [selected]' if sigma == mask_sigma else ''
                trial_items.append((trial[cy0:cy1, cx0:cx1],
                    f'Initial mask sigma={sigma:g}{chosen}'))
                mask_trials.append({'mask_sigma': sigma,
                    'boundary_jump': boundary_jump(trial, mask),
                    'clip_fraction': clip_fraction(trial)})
            trial_path = grid(trial_items, 'blend_' + ident + '_mask_sweep', 3, (340, 170))
            figs.append(figure(trial_path, 'Initial-mask comparison, '
                f'x={cx0}:{cx1}, y={cy0}:{cy1}. Sources, alignment and all {cfg["bands"]} image detail '
                'bands stay fixed. ' + cfg.get('mask_selection_note',
                'A binary finest mask leaves an abrupt change in limb contrast. '
                'Sigma 8 smooths that join; larger widths mix cloud and crater detail '
                'over a wider region.') + ' Only the selection weights vary.',
                cfg['title'] + ' · Initial mask width', supplement=True))
        record = dict(cfg, a_matrix=matrix_a.tolist(), b_matrix=matrix_b.tolist(),
            coarse_sigma=coarse_sigma, feather_sigma=feather_sigma,
            mask_equivalent_sigmas=mask_scales, source_precomposition=False,
            clip_fraction=clip_fraction(final), range=[float(final.min()), float(final.max())],
            reconstruction_error=float(np.max(np.abs(reconstruct(details['sum']) - final))),
            boundary_jump_hard=boundary_jump(hard, mask),
            boundary_jump_feather=boundary_jump(feather, mask),
            boundary_jump_multiscale=boundary_jump(final, mask),
            final=final_path, mask_area_pixels=int(mask.sum()), trial_results=sweep_records)
        if mask_trials:
            record['mask_trials'] = mask_trials
        if fits is not None:
            record['registration_fits'] = fits
        if photometric is not None:
            record['photometric_diagnostics'] = photometric
        if cfg.get('lighting_refinement_baseline'):
            refinement, controls = lighting_refinement(
                cfg, original_b, a, framed_b, b, mask, finest_mask)
            refinement_figures.append(refinement)
            record['lighting_refinement_figure'] = refinement['path']
            record['lighting_refinement_trials'] = controls
        if cfg.get('favorite'):
            process, scales = contribution_figure(details, 'blend_' + ident + '_process', (0, 2, 4))
            figs.append(figure(process, cfg['title'] + ': rows 1–3 show '
                'masked A, masked B and their sum at Laplacian levels 0, 2 and 4. The final '
                'row reconstructs each contribution and the result using all detail bands '
                'plus the coarse residual, following Burt–Adelson Figure 10. Each detail '
                'row uses one shared symmetric contrast scale; reconstructed rows retain '
                'actual intensity.', cfg['title'] + ' · Multiresolution contributions'))
            record['process_shared_row_scales'] = scales
        gray, _ = multiresolution_blend(grayscale(a), grayscale(b), finest_mask, cfg['bands'], cfg['base_sigma'])
        color_items.extend([(gray, cfg['title'] + ' / luminance'), (final, cfg['title'] + ' / RGB')])
        metrics.append(record)
        rows.append([cfg['title'], cfg['mask']['kind'], str(cfg['bands']), f'{coarse_sigma:g}',
            f'{record["boundary_jump_hard"]:.4f}', f'{record["boundary_jump_feather"]:.4f}',
            f'{record["boundary_jump_multiscale"]:.4f}',
            f'{100 * clip_fraction(final):.2f}%'])
    color_path = grid(color_items, 'blend_custom_color_comparison', 2, (390, 390))
    figs.append(figure(color_path, 'Luminance and RGB results with the same registration, '
        'masks and stack settings. Luminance is 0.2126R + 0.7152G + 0.0722B; '
        'RGB channels are blended independently.',
        'Color experiment · Luminance and RGB'))
    # Append optional controls after the established figures to preserve the
    # report's existing figure indices and the unchanged Earth-Moon layout.
    figs.extend(refinement_figures)
    paragraphs = [
        'The mountain-sky composite places Mount Rainier below a warm cloud field '
        'photographed above Denali. A 38-vertex polygon follows the visible cloud and '
        'mountain silhouette. It retains Rainier’s summit, glacier, foreground trees '
        'and the bright cloud on the left.',
        'The Earth-Moon composite joins oceans and clouds to lunar craters along an '
        'S-shaped boundary. Their similar outlines support this composite, although the '
        'same photographs do not produce a clear change of subject in the hybrid experiment.',
        'The largest source contours above luminance 0.04 are fitted with cv2.fitEllipse '
        'and mapped affinely to a circle of radius 220 pixels centered at (256,256). '
        'The Earth mapping uses axis scale factors differing by approximately 1%; '
        'the Moon mapping is nearly uniform.',
        'The landscape photographs are independently cropped and uniformly scaled using '
        'saved framing points. These points set the output field of view; they are not '
        'corresponding features of the same scene. Both examples sample the original '
        'photographs with bilinear interpolation and replicated borders. Thresholding '
        'measures the planetary outlines only. The selected Denali crop uses uniform '
        'stored-RGB gains (1.12, 1.10, 0.96) to reduce its mauve-blue cast; no '
        'intermediate clipping, local retouching or prior background transfer precedes '
        'blending. Rainier, Earth and Moon have no photometric adjustment.',
        'The hard cut, single-scale feathering and multiresolution blend use identical '
        'input arrays and the same underlying binary selection. Feathering applies '
        'the exact coarsest Gaussian mask to the full images, so fine details and broad '
        'colors mix over the same wide transition. Multiresolution blending applies '
        'the corresponding Gaussian mask to each Laplacian band.',
        'A binary finest mask leaves visible polygon corners at the landscape boundary '
        'and a contrast change where the planetary boundary meets the outer edge. '
        'Initial-mask Gaussian widths of 0, 2, 4, 8, 12 and 16 pixels are compared '
        'for each example. Landscape widths of 0, 2 and 4 give similar results; sigma 2 '
        'softens corners while preserving the summit outline. Earth-Moon uses sigma 8 to soften the outer-edge join.',
        'Only the selection weights change; the source photographs and image detail '
        'bands remain fixed. Further smoothing at stack width sigma gives a nominal '
        'combined width of sqrt(initial_sigma² + sigma²). The landscape mask widths '
        'are 2, 2.8, 4.5, 8.2, 16.1 and 32.1 pixels. Earth-Moon uses 8, 8.2, 8.9, '
        '11.3, 17.9, 33.0 and 64.5 pixels. The oraple retains a binary finest mask.',
        'The landscape uses five detail bands with sigma = 2, 4, 8, 16 and 32 pixels. '
        'The Earth-Moon blend uses six, adding sigma = 64 pixels, and both include the '
        'coarse residual. Supplementary comparisons test four, five and six bands '
        'while keeping all other inputs fixed.',
        'For the landscape, the band-count differences are modest. A maximum sigma of '
        '16 pixels leaves a narrower color transition. Sigma 32 spreads this transition locally; sigma 64 transfers '
        'more sky color over the snow. The Earth-Moon blend uses sigma 64 because '
        'the brightness mismatch extends across a large part of the disk.',
        'The landscape hard cut exposes the polygon above the summit and left cloud. '
        'Broad feathering mixes cloud texture through the ridge and makes the summit '
        'partly transparent. Multiresolution blending retains more local rock and snow '
        'contrast while spreading the broad sky-color transition. Some original cloud '
        'cover remains around the summit. Clouds and craters also remain more localized '
        'at the Earth-Moon boundary. These observations concern the visible transitions '
        'in these two examples.',
        'The boundary-jump measurement is the mean absolute RGB difference between '
        'adjacent pixels on opposite sides of the original binary contour. It includes '
        'natural image texture as well as the seam. Feathering mixes detail across one '
        'broad transition; a smaller jump alone does not establish a better-looking '
        'or physically realistic composite.',
        'RGB is used for the final composites. Warm clouds and orange-green foreground '
        'trees give the mountain-sky example stronger regional color differences. Blue '
        'oceans distinguish Earth from the nearly neutral Moon. These differences are '
        'less distinct in grayscale, although the boundaries remain smoothed.',
        'Multiresolution blending does not correct scene geometry or illumination. '
        'The landscape combines different places. Its selected crop and uniform RGB '
        'gains improve visual consistency but do not estimate physically matched '
        'illumination. It is not a photograph of a real scene. Lunar '
        'features likewise do not continue Earth’s clouds. Smoothing the finest mask '
        'reduces the abrupt outer-edge join, but the Earth-Moon composite remains '
        'an imaginary surface.',
        'Processing retains signed float64 values. Only the final display images '
        'are clipped to [0,1].'
    ]
    sec = section('blend-custom', 'Custom blends with irregular masks', paragraphs,
        figs, [{'title': 'Blend settings and mean boundary differences',
        'columns': ['Parameter or measurement'] + [row[0] for row in rows],
        'rows': [[label, *values] for label, values in zip(
            ['Selection mask', 'Detail bands', 'Maximum image sigma (px)',
             'Boundary jump: hard cut', 'Boundary jump: feathering',
             'Boundary jump: multiresolution', 'Scalar values clipped'],
            zip(*(row[1:] for row in rows)))]}],
        paragraph_headings={0:'Image pairs and registration',4:'Comparison methods',
            5:'Initial mask smoothing',7:'Number of detail bands',9:'Boundary appearance',
            11:'Color comparison',12:'Limitations'})
    return sec, metrics
