"""Page compositions for the filtering and sharpening report.

The numerical experiment records remain the source for figures and tables.
These compositions control reading order without rerunning the experiments.
"""


def filter_pages(sections):
    def p(text): return {'type': 'p', 'text': text}
    def note(text): return {'type': 'note', 'text': text}
    def heading(text): return {'type': 'heading', 'text': text}
    def eq(label, html): return {'type': 'equation', 'label': label, 'html': html}
    def fig(section, index, **kwargs):
        return dict(type='figure', section=section, index=index, **kwargs)
    def table(section, index, **kwargs):
        return dict(type='table', section=section, index=index, **kwargs)
    def page(ident, number, title, blocks):
        return dict(id=ident, number=number, title=title,
                    kicker='Part One · Filters' if number.startswith('1') else 'Part Two · Frequencies',
                    blocks=blocks)

    return [
        page('part11', '1.1', 'Convolutions from scratch', [
            p('Convolution flips a kernel in both dimensions, then sums the products of overlapping samples. I implemented this operation using four loops and two loops, and applied a box filter and two derivative filters to the self portrait.'),
            eq('Filters', 'B = (1/81) · <b>1</b><sub>9×9</sub> &nbsp;&nbsp; D<sub>x</sub> = [1, 0, −1] &nbsp;&nbsp; D<sub>y</sub> = D<sub>x</sub><sup>T</sup>'),
            fig('part11', 0),
            heading('Filtering the portrait'),
            p('The box filter removes fine texture. The horizontal and vertical derivatives emphasize intensity changes across columns and rows. Their signed responses share a symmetric color scale. Zero padding darkens the outer rim of the smoothed image and can introduce derivative responses at the frame.'),
            note('The working image is 384 × 512 pixels. Grayscale intensity is 0.299R + 0.587G + 0.114B, with RGB values in [0, 1].'),
            heading('Implementation'),
            p('The four-loop version iterates over image rows, image columns, kernel rows, and kernel columns. The two-loop version retains the kernel loops and multiplies complete shifted image slices. Both use NumPy operations only; neither calls a convolution, FFT, window-view, or image-processing routine.'),
            note('Appendices A and B contain the input checks, padding, and both complete implementations.'),
        ]),
        page('convolution-validation', '1.1', 'Runtime and boundary effects', [
            p('Both implementations agree with SciPy to floating-point precision. Non-symmetric odd and even kernels test kernel reversal and output alignment; a symmetric Gaussian alone would not reveal either error.'),
            table('part11', 0),
            p('Both manual methods require O(HWKhKw) arithmetic. The two-loop version removes Python’s per-pixel loop overhead by operating on image slices. These timings are local measurements, using a 96 × 96 float64 image and the median of three calls after one warm-up.'),
            heading('What happens at the image boundary?'),
            table('part11', 1),
            p('For a constant 25 × 25 image and a normalized 9 × 9 box filter, zero padding gives 25/81 at a corner and 5/9 at an edge midpoint. Symmetric and periodic extension preserve one. The “same” option sets output size; the boundary option supplies samples outside the image.'),
            note('Along each axis, the manual implementations pad by floor(K/2) before the image and floor((K−1)/2) after it. This matches SciPy’s “same” convention for even kernels. The largest comparison error is 8.88 × 10⁻¹⁶.'),
        ]),
        page('part12', '1.2', 'Finite difference operator', [
            p('The cameraman image is differentiated horizontally and vertically. Gradient magnitude combines these signed responses into an unsigned measure of edge strength.'),
            eq('Gradient', 'g<sub>x</sub> = I ∗ D<sub>x</sub> &nbsp;&nbsp; g<sub>y</sub> = I ∗ D<sub>y</sub> &nbsp;&nbsp; |∇I| = √(g<sub>x</sub><sup>2</sup> + g<sub>y</sub><sup>2</sup>)'),
            fig('part12', 0),
            heading('Interpreting the derivatives'),
            p('The horizontal response emphasizes intensity changes across columns; the vertical response emphasizes changes across rows. Convolution reverses the derivative kernel, so an increase from left to right produces a positive horizontal response.'),
            note('The white border is cropped from the supplied cameraman image before resizing it to 256 × 256 pixels. Computation uses floating-point intensities in [0, 1]. The complete crop coordinates and preprocessing steps are recorded in Appendix B.'),
        ]),
        page('finite-thresholds', '1.2', 'Choosing an edge threshold', [
            p('A pixel is classified as an edge when its gradient magnitude exceeds T. Three thresholds show the balance between retaining weak contours and rejecting background texture.'),
            fig('part12', 1),
            table('part12', 0),
            p('A threshold of 0.16 preserves the person, camera, and tripod while rejecting much of the ground texture visible at 0.08. Raising it to 0.24 removes more weak contours. This selection is based on the images; no annotated edge map is used to measure detection accuracy.'),
            note('A seven-pixel frame is excluded from all Part 1 binary maps and edge-fraction measurements. This removes responses caused by zero padding and covers the largest Gaussian-derivative support. The signed derivative and magnitude images show the complete responses.'),
        ]),
        page('part13', '1.3', 'Derivative of Gaussian', [
            p('Smoothing before differentiation reduces the response to fine texture. A 13 × 13 Gaussian with σ = 2 pixels is formed from the outer product of cv2.getGaussianKernel(13, 2) with itself.'),
            fig('part13', 0),
            p('Convolving this Gaussian with the finite-difference kernels gives a single filter for each derivative. Full kernel convolution produces supports of 13 × 15 and 15 × 13 pixels.'),
            eq('Combined filters', 'K<sub>x</sub> = G ∗ D<sub>x</sub> &nbsp;&nbsp; K<sub>y</sub> = G ∗ D<sub>y</sub>'),
            fig('part13', 1),
            p('Compared with the unsmoothed derivatives, the contours are wider and the grass texture is weaker. Nearby edges can merge, and weak detail can disappear.'),
        ]),
        page('dog-equivalence', '1.3', 'Sequential and combined filtering', [
            p('Sequential and combined filtering should agree when both use the same boundary treatment.'),
            eq('Associativity', 'I ∗ (G ∗ D) = (I ∗ G) ∗ D'),
            fig('part13', 2, caption='Gaussian derivative results, thresholded edges, and boundary differences. Keeping the full intermediate blur restores agreement.'),
            table('part13', 0, rows=[0, 1, 2], title='Agreement between the two formulations'),
            p('Two successive “same” convolutions crop the intermediate blur before differentiation. This removes samples outside the original frame and creates the boundary differences above. Keeping the full intermediate image and cropping once restores agreement across the complete output.'),
            note('The edge maps use T = 0.08 for the Gaussian derivative and T = 0.16 for the original finite differences. Smoothing reduces response amplitudes, so these are separately selected visual settings, not a comparison of measured detection accuracy.'),
        ]),
        page('dog-noise', '1.3', 'Sensitivity to added noise', [
            p('Gaussian noise with σ = 0.08 is added using a fixed random seed, and the resulting intensities are clipped to [0, 1]. Each noisy gradient is compared with the same method applied to the clean image.'),
            fig('part13', 3),
            table('part13', 0, rows=[3, 4], title='Interior vector-gradient residual'),
            heading('Effect of smoothing'),
            p('The residual RMS decreases from 0.15226 for finite differences to 0.01030 for the derivative of Gaussian, a factor of 14.8. Smoothing suppresses many isolated noise responses, leaving a more continuous outline of the person and camera.'),
            p('This test measures sensitivity to the added noise in this image. It does not measure recovery of detail lost through smoothing.'),
        ]),
        page('orientation', '1.4', 'Gradient orientations', [
            p('The Gaussian-derivative responses also define the direction of increasing intensity. Hue shows this direction, while brightness shows gradient strength.'),
            fig('orientation', 0),
            heading('Reading the orientation map'),
            p('The gradient is perpendicular to an edge tangent. Image rows increase downward, so 90° points down. Weak responses are dark, and the excluded seven-pixel boundary is black.'),
            eq('HSV mapping', 'h = (θ mod 2π)/(2π) &nbsp;&nbsp; s = 1<br>v = min(|∇I| / 0.2386, 1)<sup>0.7</sup>'),
            note('The brightness reference, 0.2386, is the 99.5th percentile of interior gradient magnitude.'),
            heading('Computing the angle'),
            p('The implementation uses an 18-term arithmetic series with range reduction and quadrant correction. It does not call arctangent, atan2, or an angle routine. Comparison with NumPy atan2, used only for validation, gives a maximum error of 4.44 × 10⁻¹⁶ radians. Appendix C gives the derivation and complete implementation.'),
        ]),
        page('part21', '2.1', 'Image sharpening', [
            p('Unsharp masking adds a scaled high-frequency residual to the original image. The Gaussian blur supplies the low-frequency component; subtracting it from the input isolates detail.'),
            eq('Unsharp mask', 'B = G ∗ I &nbsp;&nbsp; H = I − B &nbsp;&nbsp; S = I + αH'),
            fig('part21', 0),
            heading('Effect of the sharpening amount'),
            p('Increasing α strengthens the Taj Mahal’s edges and texture. At the largest setting, halos and clipped highlights also become more apparent. Sharpening increases local contrast but can amplify noise and existing artifacts.'),
            note('Both sharpening examples use a 13 × 13 Gaussian with σ = 2 pixels and symmetric boundaries. RGB channels are processed independently in float64. Residuals use the fixed display mapping 0.5 + 2H, so middle gray means zero.'),
        ]),
        page('sharpen-street', '2.1', 'Sharpening the street photograph', [
            p('The same filter and sharpening amounts are applied to the original street photograph. Fine building edges and road texture become more distinct as α increases.'),
            fig('part21', 1),
            table('part21', 0),
            p('The table counts scalar RGB values outside [0, 1] before export. The Taj Mahal image clips more heavily than the street image at every tested setting. Signed residuals and out-of-range values are retained during computation; only display exports are clipped.'),
        ]),
        page('sharpen-kernel', '2.1', 'One convolution and its limits', [
            p('Expanding the unsharp-mask equation gives an equivalent single convolution. The unit impulse δ retains the original image, while the Gaussian term subtracts the blurred component.'),
            eq('Sharpening kernel', 'S = [(1 + α)δ − αG] ∗ I<br>K = (1 + α)δ − αG'),
            p('The kernel sums to one and preserves a constant image when the boundary extension also preserves constants. Symmetric extension avoids the dark borders introduced by zero padding. At α = 1, this formulation agrees with residual addition to a maximum error of 1.78 × 10⁻¹⁵ across both examples.'),
            heading('Why sharpening does not undo blur'),
            fig('part21', 3),
            eq('Blur then sharpen', 'R(f) = G(f)[1 + α − αG(f)]'),
            p('The combined frequency response generally differs from one. Frequencies strongly attenuated by the blur remain attenuated after finite amplification, and clipping can remove additional information. The nonzero error map shows that stronger edges do not imply complete recovery of the original detail.'),
            note('The next comparison measures this loss against the original street photograph. Appendix D gives the single-convolution kernel code.'),
        ]),
        page('sharpen-recovery', '2.1', 'Blur and resharpen', [
            p('The street photograph is first blurred, then sharpened with the same Gaussian. The original photograph provides a reference for the comparison.'),
            fig('part21', 2),
            table('part21', 1),
            p('Of the three tested amounts, α = 2 gives the lowest clipped RGB MSE: 0.001099, compared with 0.001660 after blurring. PSNR rises from 27.80 to 29.59 dB. This setting is selected against the original reference and applies to this experiment.'),
            note('MSE is averaged over all RGB values. With a reference range of [0, 1], PSNR = 10 log₁₀(1/MSE), in decibels. Both unclipped and display-clipped results are reported.'),
        ]),
    ]
