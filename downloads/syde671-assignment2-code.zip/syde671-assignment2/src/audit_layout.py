"""Place reproducible diagnostics beside the experiments they qualify."""


def add_audit_pages(pages, sections, audit):
    section_id = 'report-audits'

    def p(text): return dict(type='p', text=text)
    def note(text): return dict(type='note', text=text)
    def eq(label, html): return dict(type='equation', label=label, html=html)
    def table(index): return dict(type='table', section=section_id, index=index)
    def figure(section, index, height, caption):
        return dict(type='figure', section=section, index=index, height=height, caption=caption)
    def page(ident, number, title, *blocks):
        return dict(id=ident, number=number, title=title, kicker='Part Two · Frequencies', blocks=list(blocks))
    def ratio(record, width):
        return f"{record[f'high_to_low_contrast_ratio_{width}']:.3f}"

    hybrid_rows = []
    for h in audit['hybrids']:
        for label, record in [('Baseline', h['baseline']), ('Selected', h)]:
            hybrid_rows.append([h['title'], label, ratio(record, 512), ratio(record, 128),
                                f"{100 * record['clip_fraction']:.2f}"])
    control_rows = []
    for r in audit['favorite_refinement']['trials']:
        control_rows.append([
            'Common eyes' if r['geometry'] == 'common' else 'Refined',
            f"({r['sigma_low']:g}, {r['sigma_high']:g}, {r['gain']:g})",
            ratio(r, 128), f"{100 * r['clip_fraction']:.2f}"])
    trace_rows = [[r['step'], r['added_band'], r['mask_sigma'],
                   f"{r['remaining_rms']:.5f}" if r['level'] else f"{r['remaining_rms']:.2e}"]
                  for r in audit['oraple_trace']['steps']]
    blend_rows = []
    for b, title in zip(audit['blends'], ['Oraple', 'Cat', 'Earth–Moon']):
        methods = [b['methods'][m] for m in ('hard_cut', 'feather', 'multiscale')]
        blend_rows.append([title] + [f"{m['boundary_jump']:.4f}" for m in methods]
                          + [f"{100 * m['clip_fraction_tolerance_1e6']:.2f}" for m in methods])
    sections[section_id] = dict(id=section_id, figures=[audit['oraple_trace']['figure']], tables=[
        dict(title='The same diagnostics for all three portrait–cat pairs.',
             columns=['Pair', 'Setting', 'R₅₁₂', 'R₁₂₈', 'C (%)'], rows=hybrid_rows),
        dict(title='Geometry and filtering varied independently for the astronaut pair.',
             columns=['Geometry', '(σL, σH, g)', 'R₁₂₈', 'C (%)'], rows=control_rows),
        dict(title='All levels remain 512 × 367 RGB; σ is in output pixels.',
             columns=['Step', 'Added band', 'Mask σ', 'Remaining RMS'], rows=trace_rows),
        dict(title='Identical inputs and selections within each example.',
             columns=['Example', 'Hard J', 'Feather J', 'Multi J', 'Hard Cε (%)', 'Feather Cε (%)', 'Multi Cε (%)'], rows=blend_rows),
    ])

    control = page('hybrid-controlled-comparison', '2.2', 'Separating geometry and filtering',
        p('The four trials vary human position and filter settings independently. The cat transform, source photographs, color treatment and interpolation remain fixed.'),
        figure('part22', 13, 116, 'Rows compare common-eye and refined geometry; columns compare reference and selected filters. Each trial is shown at 512, 128 and 64 pixels.'),
        table(1),
        note('R₁₂₈ is the high-to-low luminance standard-deviation ratio after signed Lanczos reduction to 128 pixels; the high band includes gain g. C is the percentage of scalar channel values outside [0, 1] before display clipping.'),
        p('On refined geometry, the selected filters reduce clipping from 3.49% to 2.74%. With selected filters fixed, refining geometry increases clipping from 1.91% to 2.74%. It reduces the extra human mouth below the cat muzzle but displaces the eyes. This is a visual tradeoff, not evidence of more accurate landmark registration.'),
    )
    diagnostics = page('hybrid-diagnostics', '2.2', 'Comparing the frequency bands',
        p('Two diagnostics describe the selected hybrids and a common baseline. The band-contrast ratio measures the relative variation in the two components; the clipping fraction records how much of their sum exceeds the display range.'),
        eq('Relative band contrast at width s',
           'R<sub>s</sub> = std(D<sub>s</sub>(H)) / std(D<sub>s</sub>(L))'),
        p('L is low-pass luminance and H is gain-scaled high-pass luminance. Dₛ reduces each signed component to width s with Lanczos interpolation; the native 512-pixel arrays are unchanged. Standard deviations use all pixels. Neither component is clipped or contrast-normalized.'),
        eq('Strict clipping fraction', 'C = count(I<sub>hybrid</sub> &lt; 0 or I<sub>hybrid</sub> &gt; 1) / count(all channel values)'),
        table(0),
        note('The baseline uses (σL, σH, g) = (10, 5, 1) on each pair’s selected geometry. Selected settings are listed with the hybrid results. This baseline differs from the (6, 1.5, 3) reference used in the preceding geometry comparison.'),
        p('For every pair, selection increases the relative high-band contrast at 512 pixels and lowers it at 128 pixels compared with the baseline. The high-frequency contribution therefore changes more strongly with display scale. All three selected images also clip more values than the wide-band baseline.'),
        p('These measurements support the filtering explanation, but they do not measure recognition. Obama’s selected image has the largest R₅₁₂, yet the human mouth remains visible at that size. Successful frequency separation does not by itself guarantee a clean change in perceived subject.'),
    )
    trace = page('oraple-level-trace', '2.4', 'Adding the bands one level at a time',
        p('Starting with the mixed coarse residual S₅, add the five detail contributions from coarse to fine. Every addition uses arrays of the same size; no interpolation or resizing occurs.'),
        eq('Cumulative reconstruction', 'T<sub>5</sub> = S<sub>5</sub>; &nbsp; T<sub>k</sub> = T<sub>k+1</sub> + S<sub>k</sub>, &nbsp; k = 4, …, 0'),
        figure(section_id, 0, 82, 'Read left to right, then top to bottom. All panels use the same [0, 1] display limits, with no contrast normalization. Measurements use the signed arrays before clipping.'),
        table(2),
        note('Remaining RMS = √mean[(Iblend − Tₖ)²], over all pixels and RGB channels. The reference is the complete computed blend, not an ideal photograph. The final difference is floating-point roundoff; intermediate RMS need not decrease for arbitrary signed bands.'),
        p('Omitting S₅ leaves RMS error 0.39660: the detail bands cannot restore broad brightness and color. Including it reconstructs the full blend to numerical precision. This checks completeness of the summation, not visual quality.'),
    )

    additions = {'hybrid-registration': control, 'hybrid-other-pairs': diagnostics, 'part24': trace}
    updated = []
    for original in pages:
        if original['id'] == 'blend-planet-registration':
            blocks = original['blocks']
            table_index = next(i for i, b in enumerate(blocks) if b['type'] == 'table')
            blocks[table_index:] = [
                table(3),
                note('J is mean absolute RGB difference across adjacent pixels straddling the original binary contour, before clipping. Cε is the fraction of scalar values below −10⁻⁶ or above 1 + 10⁻⁶. This tolerance discounts roundoff and negligible excursions; strict counts and ranges remain in the measurements.'),
                p('Feathering gives the smallest J but mixes more texture. A smaller boundary jump alone does not establish a better composite. The disk fit checks outline coincidence, not surface-feature correspondence or physical realism.'),
            ]
        updated.append(original)
        if original['id'] in additions:
            updated.append(additions[original['id']])
    return updated
