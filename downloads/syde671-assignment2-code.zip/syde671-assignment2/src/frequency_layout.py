"""Authored reading order for the frequency and blending report pages.

The experiment records remain the source of figures, measurements and captions.
This module only places that evidence beside the explanation it supports.
"""


def frequency_pages(sections):
    """Return explicit report pages for Sections 2.2 onward.

    ``sections`` is the report's dictionary of saved experiment sections.  Figure
    and table blocks refer to those records rather than copying measured values.
    """
    required = ("part22", "hybrid-color", "part23", "part24", "blend-custom")
    for section_id in required:
        if section_id not in sections:
            raise KeyError(f"Missing frequency report section: {section_id}")
    settings = sections['part22']['hybrid_settings']
    favorite = settings['obama_biden']
    portrait = settings['monroe_einstein']
    filter_summary = '; '.join(
        f'{name}: ({settings[ident]["sigma_low"]:g}, '
        f'{settings[ident]["sigma_high"]:g}, {settings[ident]["gain"]:g})'
        for ident, name in [('derek_nutmeg', 'Derek'),
                            ('obama_biden', 'Obama + Biden'), ('monroe_einstein', 'Monroe + Einstein')])

    def p(text):
        return {"type": "p", "text": text}

    def note(text):
        return {"type": "note", "text": text}

    def heading(text):
        return {"type": "heading", "text": text}

    def equation(label, html):
        return {"type": "equation", "label": label, "html": html}

    def figure(section, index, *, caption=None, height=None):
        if isinstance(index, str):
            expected = 'images/' + index + '.jpg'
            index = next(i for i, item in enumerate(sections[section]['figures'])
                         if item['path'] == expected)
        block = {"type": "figure", "section": section, "index": index}
        if caption is not None:
            block["caption"] = caption
        if height is not None:
            block["height"] = height
        return block

    def table(section, index, *, title=None):
        block = {"type": "table", "section": section, "index": index}
        if title is not None:
            block["title"] = title
        return block

    def supplements(section):
        return {"type": "supplements", "section": section}

    def page(page_id, number, title, *blocks):
        return {
            "id": page_id,
            "number": number,
            "title": title,
            "kicker": "Part Two · Frequencies",
            "blocks": list(blocks),
        }

    return [
        page(
            "part22", "2.2", "Hybrid images at different scales",
            p("A hybrid image combines broad structure from one image with fine detail "
              "from another. The supplied Derek–Nutmeg example is followed by two custom "
              "portrait pairs: Obama–Biden and the classic Monroe–Einstein combination."),
            equation("Hybrid construction",
                     "I<sub>hybrid</sub> = G<sub>σL</sub> ∗ A + g(B − G<sub>σH</sub> ∗ B)"),
            note("A is the low-frequency source, B is the high-frequency source, g is the detail gain, and Gσ is a "
                 "Gaussian kernel with standard deviation σ. The symbol ∗ denotes convolution."),
            figure("part22", 0, height=100,
                   caption="Obama + Biden: the same hybrid at 512, 256, 128 and 64 pixels, reduced with Lanczos."),
            p("Biden’s eyes, wrinkles and fine facial detail are prominent in the large "
              "view. At 64 pixels, Obama’s broader facial structure becomes clearer. "
              "The intermediate views retain both identities; the transition is gradual."),
            table("part22", 0),
            note("For a distance comparison, keep the largest image at a fixed display size and move farther away. "
                 "Reduced versions provide another comparison; screen size, zoom and eyesight prevent assigning a calibrated viewing distance."),
            {"type": "viewer"},
        ),
        page(
            "hybrid-filter-selection", "2.2", "Choosing filter widths and gain",
            p("The low-pass width controls the broad portrait structure. Increasing the "
              "high-pass width retains more middle-scale detail, while gain changes its "
              "contrast. The selected settings balance a distinct near view against a clear reduced view."),
            figure("part22", 1, height=145),
            heading("What changes in the trials"),
            p("The six trials keep eye alignment fixed. Lower gain weakens Biden’s "
              "wrinkles and hair detail. Increasing the low-pass width to 20 blurs "
              "Obama’s eyes and smile. High-pass σ = 7 retains more of Biden’s face in "
              "the reduced view, making the identity change less distinct."),
            p("Selected (σL, σH, g) settings are " + filter_summary + ". "
              "The choices are visual judgments for these sources. The later controlled "
              "Derek–Nutmeg comparison separates the effects of geometry and filtering."),
        ),
        page(
            "hybrid-registration", "2.2", "Selecting and aligning the portraits",
            p("Obama and Biden have similar near-frontal poses, open smiles and collared "
              "clothing. Monroe’s softly lit portrait reduces mouth and neck shadows. "
              "Mirroring Einstein horizontally brings the facing directions and cheek "
              "shading into closer agreement."),
            figure("part22", 2, height=100),
            heading("Common eye alignment"),
            p("Two-point similarity transforms map each pair’s eyes to the common targets "
              "below. No separate face scaling or local deformation is applied."),
            table("part22", 1),
            p("Derek and Nutmeg have different proportions. The next page compares common "
              "eye alignment with a smaller Derek face, keeping Nutmeg’s framing fixed."),
            note("Einstein’s reflection reverses x as W−1−x and swaps the eye correspondence. "
                 "It is composed with the similarity transform; each original is sampled once, "
                 "using bilinear interpolation and replicated borders. Uniform scaling "
                 "preserves proportions. Original landmarks and exact matrices are saved with the results."),
        ),
        page(
            "hybrid-frequency-content", "2.2", "Frequency content of the hybrid",
            p("A Gaussian has no sharp cutoff. Its approximate half-amplitude frequency "
              "provides a reference for the selected filter widths."),
            equation("Half-amplitude frequency",
                     "f<sub>½</sub> = √(2 ln 2) / (2πσ)"),
            note("For Obama + Biden, the low-pass and complementary high-pass values "
                 f"are {favorite['low_half_amplitude_cycles_per_pixel']:.4f} and "
                 f"{favorite['high_half_amplitude_cycles_per_pixel']:.4f} cycles per output pixel, respectively. Filtering "
                 "uses spatial convolution; Fourier plots show the resulting frequency content."),
            figure("part22", 3, height=130, caption="Low-pass energy is concentrated near the center; the high-pass suppresses central energy and retains fine detail. Adding the two components produces the hybrid. Both Fourier figures use the same logarithmic scale and display maximum."),
            equation("Fourier display",
                     "log(1 + 1,000,000 |fftshift(fft2(Y))| / N)"),
            note("Y is luminance and N is the number of image pixels. Division by N permits "
                 "comparison of differently sized inputs. The source and process spectra "
                 "share one display maximum. No window or mean subtraction is applied."),
        ),
        page(
            "hybrid-other-pairs", "2.2", "Two further hybrid examples",
            figure("part22", "hybrid_derek_nutmeg_summary", height=80,
                   caption="Derek + Nutmeg: original sources and final hybrid at 512, 128, 64 and 32 pixels."),
            p("At fixed eye alignment, increasing the high-pass width from 3 to 5 and "
              "gain from 1.25 to 2 strengthens Nutmeg’s eyes, muzzle and fur. Low-pass "
              "width 10 softens Derek’s detail. Nutmeg dominates the large view; Derek "
              "emerges at 32 pixels. Intermediate views and broad shading remain mixed."),
            figure("part22", "hybrid_monroe_einstein_summary", height=80,
                   caption="Monroe + Einstein: original portraits and hybrid at 512, 128, 64 and 32 pixels; Einstein is mirrored before alignment."),
            p("With alignment fixed, increasing high-pass width from 3 to 5 and gain "
              "from 1.25 to 1.75 strengthens Einstein’s eyes, nose and moustache. "
              "The 64-pixel view remains mixed; Monroe is clearer at 32 pixels. "
              "Some cheek and jaw shading remains. This implements the classic pairing [5]."),
            note("The online supplement includes alignment, filter trials, geometry controls "
                 "and the reflection comparison. The Earth–Moon hybrid remains a limitation "
                 "study: its similar outlines do not yield a clear subject change."),
            supplements("part22"),
        ),
        page(
            "hybrid-color", "2.2", "Color in the frequency bands",
            p("Four variants retain color in neither source, only the low-frequency "
              "source, only the high-frequency source, or both. Alignment, filter widths "
              "and gain remain identical."),
            figure("hybrid-color", 0, height=105),
            heading("How color changes the result"),
            p("Low-frequency color preserves Obama’s broad skin, hair and background "
              "colors, agreeing with the portrait visible at smaller sizes. Biden’s fine "
              "detail remains visible in the larger view. High-frequency color contributes "
              "mainly near edges because the broad color regions have been removed."),
            p("Keeping both sources in color adds some competing edge colors. The main "
              "examples use grayscale so that the change in facial structure can be "
              "assessed without this broad color difference."),
            supplements("hybrid-color"),
        ),
        page(
            "part23", "2.3", "Gaussian and Laplacian stacks",
            p("The supplied burt_apple.png and burt_orange.png images are each 740 × 530 "
              "pixels. One resize with area interpolation gives 512 × 367 working images, "
              "reducing computation while preserving aspect ratio to the nearest output pixel."),
            p("Every Gaussian-stack level keeps the same dimensions. G₀ is the original; "
              "G₁ through G₅ independently blur it at σ = 2, 4, 8, 16 and 32 pixels. "
              "Each width therefore refers to the original image. Construction is explicit, "
              "with no downsampling or built-in pyramid routine."),
            figure("part23", 0, height=65),
            figure("part23", 1, height=65),
            equation("Laplacian detail and residual",
                     "L<sub>i</sub> = G<sub>i</sub> − G<sub>i+1</sub> "
                     "(i = 0, …, 4); &nbsp; L<sub>5</sub> = G<sub>5</sub>"),
            p("The five detail bands sum to the original minus G₅. Adding the coarse "
              "residual restores large-scale brightness and color, reconstructing the "
              "image up to floating-point rounding."),
        ),
        page(
            "stack-contributions", "2.3", "Reconstructing the oraple",
            p("The selected levels show how each source contributes at different scales. "
              "The final row sums all five detail bands and the coarse residual."),
            figure("part23", 3, height=185),
            supplements("part23"),
        ),
        page(
            "part24", "2.4", "A transition that changes with scale",
            p("A binary mask selects apple on the left and orange on the right. Its "
              "Gaussian stack uses the same smoothing scales as the image stacks."),
            figure("part23", 2, height=40),
            equation("Blend each band, then sum",
                     "S<sub>i</sub> = M<sub>i</sub>L<sub>A,i</sub> + "
                     "(1 − M<sub>i</sub>)L<sub>B,i</sub>; &nbsp; "
                     "I<sub>blend</sub> = Σ<sub>i=0</sub><sup>5</sup>S<sub>i</sub>"),
            p("The rule includes the coarse residual. The finest mask has a sharp "
              "transition; coarser masks spread brightness and color changes across wider "
              "regions while retaining local texture."),
            figure("part24", 0, height=45),
            p("Both methods use the same inputs and initial mask. The direct cut leaves "
              "a visible vertical change in brightness and color. The mean absolute RGB "
              "difference across adjoining seam columns falls from 0.1716 to 0.0279 with "
              "multiresolution blending. This measures the local discontinuity, not overall "
              "perceptual quality."),
            table("part23", 0),
            note("The seam lies between zero-based columns 255 and 256. Measurement uses "
                 "the floating-point reconstruction before clipping. Stack construction "
                 "and reconstruction remain unclipped; display export limits 2.35% of "
                 "scalar RGB values to [0, 1]."),
            supplements("part24"),
        ),
        page(
            "blend-custom", "2.4", "An alpine lake through a sandstone arch",
            p("North Window’s orange sandstone frames Lake McDonald and its snowy peaks. "
              "The source photographs contribute visibly different content. Their warm "
              "light provides a compatible starting point, while the composite deliberately "
              "joins two different places."),
            figure("blend-custom", "blend_custom_landscape_inputs", height=80),
            heading("Framing and selection"),
            p("Independent framing points crop and uniformly scale each photograph to "
              "512 × 512. They are not corresponding features of one scene. Bilinear "
              "sampling uses replicated borders. The inputs receive no color correction "
              "or prior background transfer."),
            equation("White selects lake A; black selects arch B",
                     "S<sub>i</sub> = M<sub>i</sub>L<sub>A,i</sub> + (1 − M<sub>i</sub>)L<sub>B,i</sub>"),
            p("A saved 122-vertex polygon follows the inner arch and the foreground "
              "ledge. Its upper boundary was traced from the framed sky edge and "
              "visually checked to remove remnants of the original sky. The lower "
              "boundary defines where the lake meets the foreground rock."),
            note("Four detail bands use image σ = 2, 4, 8 and 16 pixels, plus the coarse "
                 "residual. Initial mask σ = 1 softens pixel-level contour corners. Nominal "
                 "mask widths are 1, 2.2, 4.1, 8.1 and 16.0 pixels across the five levels."),
        ),
        page(
            "blend-landscape-comparison", "2.4", "Landscape blending: boundary and texture",
            p("The direct cut leaves a pasted edge along the foreground ledge. Broad "
              "feathering blends the full images over one wide transition, making rock "
              "partly transparent and introducing background detail through the foreground."),
            figure("blend-custom", "blend_custom_landscape_comparison", height=170,
                   caption="Hard cut, single-scale feathering and multiresolution blending use the same inputs and binary selection. Initial mask smoothing uses σ = 1 pixel."),
            p("Multiresolution blending retains more local rock and mountain texture "
              "while reducing the abrupt transition. Some lightening remains near the "
              "lower-left boundary. The warm peaks and arch are visually compatible, "
              "but this imagined view is not a photograph of one real location."),
        ),
        page(
            "blend-landscape-contributions", "2.4", "Landscape contributions at each scale",
            p("Three detail bands leave a tighter lower boundary. Five spread more broad "
              "color across the opening and foreground. Four bands, with maximum image "
              "σ = 16 pixels, balance seam smoothing against the loss of local contrast."),
            figure("blend-custom", "blend_custom_landscape_process", height=175),
            note("Rows show detail levels 0, 2 and 3, then the full reconstruction including "
                 "residual level 4. Supplementary trials vary band count over 3, 4 and 5, "
                 "and initial-mask σ over 0, 0.5, 1, 2, 4 and 8 pixels. Larger mask widths "
                 "increasingly mix rock and lake texture; σ = 1 retains the foreground edge."),
        ),
        page(
            "blend-planet-registration", "2.4", "Joining Earth and Moon",
            p("An S-shaped boundary joins Earth’s oceans and clouds to lunar craters. "
              "The similar disk outlines support this composite, although the same "
              "photographs did not produce a clear subject change in the hybrid experiment."),
            figure("blend-custom", "blend_custom_planet_inputs", height=75),
            note("The largest source contours above luminance 0.04 are fitted with "
                 "cv2.fitEllipse and mapped affinely to a circle of radius 220 pixels at "
                 "(256, 256). Thresholding measures the outlines only; the transforms "
                 "sample original RGB pixels. Earth’s axis scale factors differ by 1.06%; "
                 "the Moon’s differ by 0.03%."),
            p("Earth–Moon uses six detail bands, adding image σ = 64 pixels, plus the "
              "coarse residual. The initial mask uses σ = 8, giving one further "
              "nominal mask width of 64.5 pixels."),
            table("blend-custom", 0),
            note("Boundary jump is the mean absolute RGB difference between adjacent pixels "
                 "on opposite sides of the original binary contour. It includes natural "
                 "texture as well as the seam. Feathering mixes more detail and gives "
                 "smaller values; this alone does not establish a better-looking or "
                 "physically realistic composite. Processing retains signed float64 "
                 "values; only final display images are clipped to [0, 1]."),
        ),
        page(
            "blend-planet-comparison", "2.4", "Planet blending: brightness and detail",
            p("The Earth–Moon blend uses a maximum image σ of 64 pixels because the "
              "brightness mismatch extends across much of the disk. Fewer bands leave "
              "a more visible boundary."),
            figure("blend-custom", "blend_custom_planet_comparison", height=170,
                   caption="Three methods with the same registered inputs and binary "
                           "selection. Initial mask smoothing at σ = 8 pixels reduces "
                           "the abrupt contrast change where the selection meets the disk outline."),
            p("Multiresolution blending reduces the brightness step and keeps cloud and "
              "crater detail more localized than broad feathering. A binary finest mask "
              "leaves an abrupt outer-edge join; wider masks combine texture across a "
              "larger region. The same six initial widths and four-, five- and six-band "
              "comparisons are retained in the supplementary figures."),
            p("The composite remains an imaginary surface: lunar features do not continue "
              "Earth’s clouds. Smoothing a boundary cannot reconcile different surface structures."),
        ),
        page(
            "blend-color", "2.4", "Color separates the source regions",
            p("The final composites use RGB. Orange sandstone, golden snowy peaks and "
              "blue water make the arch–lake source regions distinct. Blue oceans "
              "distinguish Earth from the nearly neutral Moon. These differences are "
              "less evident in grayscale, although the boundaries remain smoothed."),
            figure("blend-custom", "blend_custom_color_comparison", height=175),
            note("Framing or registration, masks and stack settings are identical in this "
                 "comparison. RGB channels are blended independently. Supplementary figures "
                 "retain matched boundary crops, complete mask stacks, mask-width sweeps "
                 "and band-count trials for both examples."),
            supplements("blend-custom"),
        ),
    ]
