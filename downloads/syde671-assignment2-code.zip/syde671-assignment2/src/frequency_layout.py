"""Authored reading order for the frequency and blending report pages.

The experiment records remain the source of figures, measurements and captions.
This module only places that evidence beside the explanation it supports.
"""


def frequency_pages(sections):
    """Return explicit report pages for Sections 2.2 onward.

    ``sections`` is the report's dictionary of saved experiment sections.  Figure
    and table blocks refer to those records rather than copying measured values.
    """
    required = ("part22", "hybrid-color", "part23", "part24", "blend-custom")
    for section_id in required:
        if section_id not in sections:
            raise KeyError(f"Missing frequency report section: {section_id}")
    settings = sections['part22']['hybrid_settings']
    favorite = settings['astronaut_chelsea']
    obama = settings['obama_tabby']
    filter_summary = '; '.join(
        f'{name}: ({settings[ident]["sigma_low"]:g}, '
        f'{settings[ident]["sigma_high"]:g}, {settings[ident]["gain"]:g})'
        for ident, name in [('derek_nutmeg', 'Derek'),
                            ('astronaut_chelsea', 'astronaut'), ('obama_tabby', 'Obama')])

    def p(text):
        return {"type": "p", "text": text}

    def note(text):
        return {"type": "note", "text": text}

    def heading(text):
        return {"type": "heading", "text": text}

    def equation(label, html):
        return {"type": "equation", "label": label, "html": html}

    def figure(section, index, *, caption=None, height=None):
        block = {"type": "figure", "section": section, "index": index}
        if caption is not None:
            block["caption"] = caption
        if height is not None:
            block["height"] = height
        return block

    def table(section, index, *, title=None):
        block = {"type": "table", "section": section, "index": index}
        if title is not None:
            block["title"] = title
        return block

    def supplements(section):
        return {"type": "supplements", "section": section}

    def page(page_id, number, title, *blocks):
        return {
            "id": page_id,
            "number": number,
            "title": title,
            "kicker": "Part Two · Frequencies",
            "blocks": list(blocks),
        }

    return [
        page(
            "part22", "2.2", "Hybrid images at different scales",
            p("A hybrid image combines the broad structure of one image with fine detail "
              "from another. Here, a blurred human portrait supplies the low frequencies "
              "and an aligned cat photograph supplies the high frequencies."),
            equation("Hybrid construction",
                     "I<sub>hybrid</sub> = G<sub>σL</sub> ∗ A + g(B − G<sub>σH</sub> ∗ B)"),
            note("A is the human portrait, B is the cat, g is the detail gain, and Gσ is a "
                 "Gaussian kernel with standard deviation σ. The symbol ∗ denotes convolution."),
            figure("part22", 0, height=100,
                   caption="Astronaut + portrait cat: the same hybrid at 512, 256, 128 and "
                           "64 pixels, reduced with Lanczos."),
            p("Cat eyes and muzzle dominate the 512- and 256-pixel views. At 64 pixels, "
              "the astronaut’s face becomes recognizable. The 128-pixel view retains "
              "features from both sources; the change in appearance is gradual."),
            table("part22", 0),
            note("For a distance comparison, keep the largest image at a fixed display size "
                 "and move farther away. The reduced versions provide another comparison; "
                 "screen size, zoom and eyesight prevent assigning them a calibrated viewing distance."),
            {"type": "viewer"},
        ),
        page(
            "hybrid-filter-selection", "2.2", "Choosing filter widths and gain",
            p("High-pass σ values of 1.5 or 2 pixels remove more broad cat shading than σ = 5, "
              "leaving less cat structure in the reduced views. The selected gains retain "
              "visible fur detail."),
            figure("part22", 1, height=145),
            heading("What changes in the trials"),
            p("The six trials keep the selected alignment fixed. Increasing the astronaut’s "
              "low-pass σ to 18 blurs the eyes and smile in the reduced view. Increasing "
              "the high-pass σ from 1.5 to 3 retains broader cat structure that competes "
              "with the human face."),
            p("Selected (σL, σH, g) settings are " + filter_summary + ". "
              "They were chosen visually for these inputs. The controlled "
              "comparison below varies alignment and filtering separately."),
        ),
        page(
            "hybrid-registration", "2.2", "Aligning the two faces",
            p("The initial two-point similarity transforms map both pairs of eye centers "
              "to (170, 210) and (330, 210). Each transform combines rotation, uniform "
              "scale and translation. Exact eye alignment leaves a separate human mouth "
              "or chin below the cat muzzle. Broad smile structure survives low-pass "
              "filtering, so adding fur contrast alone does not remove it."),
            figure("part22", 2, height=105),
            heading("Refining the human position"),
            p("The human portrait is scaled about (250, 210), then shifted vertically; "
              "the cat remains fixed. The smaller human face places the mouth within "
              "the cat muzzle, although the eye centers no longer coincide."),
            table("part22", 1),
            p("The following controlled comparison separates the geometry and filter "
              "changes. It shows the effect of the human position while holding the "
              "filter settings fixed, and the effect of filtering on each geometry."),
            note("Each original is resampled once with the composed similarity transform, "
                 "using bilinear interpolation and replicated borders. Face proportions "
                 "are unchanged. Original landmarks and exact 2 × 3 matrices are saved "
                 "with the experiment records."),
        ),
        page(
            "hybrid-frequency-content", "2.2", "Frequency content of the hybrid",
            p("A Gaussian has no sharp cutoff. Its approximate half-amplitude frequency "
              "provides a reference for the selected filter widths."),
            equation("Half-amplitude frequency",
                     "f<sub>½</sub> = √(2 ln 2) / (2πσ)"),
            note("For the astronaut pair, the low-pass and complementary high-pass values "
                 f"are {favorite['low_half_amplitude_cycles_per_pixel']:.4f} and "
                 f"{favorite['high_half_amplitude_cycles_per_pixel']:.4f} cycles per output pixel, respectively. Filtering "
                 "uses spatial convolution; Fourier plots show the resulting frequency content."),
            figure("part22", 3, height=130, caption="Low-pass energy is concentrated near the center; the high-pass suppresses central energy and retains fine detail. Adding the two components produces the hybrid. Both Fourier figures use the same logarithmic scale and display maximum."),
            equation("Fourier display",
                     "log(1 + 1,000,000 |fftshift(fft2(Y))| / N)"),
            note("Y is luminance and N is the number of image pixels. Division by N permits "
                 "comparison of differently sized inputs. The source and process spectra "
                 "share one display maximum. No window or mean subtraction is applied."),
        ),
        page(
            "hybrid-other-pairs", "2.2", "Two more portrait–cat pairs",
            figure("part22", 4, height=82,
                   caption="Derek + Nutmeg: original sources and the final hybrid at "
                           "512, 128 and 64 pixels."),
            p("The smaller human face reduces the separate mouth and chin below the cat "
              "muzzle. Nutmeg dominates at 512 pixels; Derek becomes recognizable at "
              "64 pixels. The 128-pixel view retains features from both sources."),
            figure("part22", 5, height=82,
                   caption="Obama + tabby: original sources and the final hybrid at "
                           "512, 128 and 64 pixels."),
            p("The smaller, higher human face places Obama’s broad smile within the cat "
              f"muzzle. Low-pass σ = {obama['sigma_low']:g} softens the teeth patch; "
              f"high-pass σ = {obama['sigma_high']:g} and gain {obama['gain']:g} retain muzzle detail. "
              "The tabby dominates the large view; Obama becomes recognizable at 64 pixels. "
              "Intermediate views remain mixed."),
            note("Supplementary figures retain each pair’s registration, components and "
                 "parameter comparisons, plus the Earth + Moon limitation study. Its "
                 "similar outlines and overlapping surface structure do not produce a "
                 "clear change in perceived subject."),
            supplements("part22"),
        ),
        page(
            "hybrid-color", "2.2", "Color in the frequency bands",
            p("Four variants retain color in neither source, only the low-frequency "
              "source, only the high-frequency source, or both. Alignment, filter widths "
              "and gain remain identical."),
            figure("hybrid-color", 0, height=105),
            heading("How color changes the result"),
            p("Low-frequency color preserves the astronaut’s broad skin and hair regions, "
              "agreeing with the face visible at smaller sizes. Grayscale fur remains "
              "visible at larger sizes. High-frequency color remains mainly around fine "
              "cat edges because filtering removes the broad coat color."),
            p("Keeping color in both sources adds competing hues around some cat edges. "
              "The main hybrid examples use grayscale so the visible subject can be "
              "assessed without this broad color difference."),
            supplements("hybrid-color"),
        ),
        page(
            "part23", "2.3", "Gaussian and Laplacian stacks",
            p("The supplied burt_apple.png and burt_orange.png images are each 740 × 530 "
              "pixels. One resize with area interpolation gives 512 × 367 working images, "
              "reducing computation while preserving aspect ratio to the nearest output pixel."),
            p("Every Gaussian-stack level keeps the same dimensions. G₀ is the original; "
              "G₁ through G₅ independently blur it at σ = 2, 4, 8, 16 and 32 pixels. "
              "Each width therefore refers to the original image. Construction is explicit, "
              "with no downsampling or built-in pyramid routine."),
            figure("part23", 0, height=65),
            figure("part23", 1, height=65),
            equation("Laplacian detail and residual",
                     "L<sub>i</sub> = G<sub>i</sub> − G<sub>i+1</sub> "
                     "(i = 0, …, 4); &nbsp; L<sub>5</sub> = G<sub>5</sub>"),
            p("The five detail bands sum to the original minus G₅. Adding the coarse "
              "residual restores large-scale brightness and color, reconstructing the "
              "image up to floating-point rounding."),
        ),
        page(
            "stack-contributions", "2.3", "Reconstructing the oraple",
            p("The selected levels show how each source contributes at different scales. "
              "The final row sums all five detail bands and the coarse residual."),
            figure("part23", 3, height=185),
            supplements("part23"),
        ),
        page(
            "part24", "2.4", "A transition that changes with scale",
            p("A binary mask selects apple on the left and orange on the right. Its "
              "Gaussian stack uses the same smoothing scales as the image stacks."),
            figure("part23", 2, height=40),
            equation("Blend each band, then sum",
                     "S<sub>i</sub> = M<sub>i</sub>L<sub>A,i</sub> + "
                     "(1 − M<sub>i</sub>)L<sub>B,i</sub>; &nbsp; "
                     "I<sub>blend</sub> = Σ<sub>i=0</sub><sup>5</sup>S<sub>i</sub>"),
            p("The rule includes the coarse residual. The finest mask has a sharp "
              "transition; coarser masks spread brightness and color changes across wider "
              "regions while retaining local texture."),
            figure("part24", 0, height=45),
            p("Both methods use the same inputs and initial mask. The direct cut leaves "
              "a visible vertical change in brightness and color. The mean absolute RGB "
              "difference across adjoining seam columns falls from 0.1716 to 0.0279 with "
              "multiresolution blending. This measures the local discontinuity, not overall "
              "perceptual quality."),
            table("part23", 0),
            note("The seam lies between zero-based columns 255 and 256. Measurement uses "
                 "the floating-point reconstruction before clipping. Stack construction "
                 "and reconstruction remain unclipped; display export limits 2.35% of "
                 "scalar RGB values to [0, 1]."),
            supplements("part24"),
        ),
        page(
            "blend-custom", "2.4", "A cat face inside another coat",
            p("The tabby’s central face is placed within the orange-and-white cat’s ears, "
              "outer whiskers and chest. A 24-vertex polygon follows the crown, temples, "
              "cheeks and chin, keeping forehead stripes inside the selection. A similarity "
              "transform aligns the eye centers with uniform scale, rotation and translation."),
            figure("blend-custom", 0, height=80),
            heading("A common comparison"),
            p("Both custom examples use complete registered photographs, sampled with "
              "bilinear interpolation and replicated borders. Exposure, color and "
              "backgrounds are unchanged; no retouching or background transfer precedes blending."),
            p("The hard cut, single-scale feathering and multiresolution blend use identical "
              "registered arrays and the same binary selection. Feathering applies the exact "
              "coarsest Gaussian mask to the full images. Multiresolution blending applies "
              "the corresponding Gaussian mask to each Laplacian band."),
            heading("Selection weights"),
            p("The cat uses five detail bands at σ = 2, 4, 8, 16 and 32 pixels, plus the "
              "coarse residual. An initial mask σ of 8 softens the crown and cheeks while "
              "keeping the eyes, nose and muzzle within the tabby selection."),
            equation("Nominal mask width after further smoothing",
                     "σ<sub>mask</sub> = √(8<sup>2</sup> + σ<sub>stack</sub><sup>2</sup>)"),
            note("The resulting cat mask widths are 8, 8.2, 8.9, 11.3, 17.9 and 33.0 pixels. "
                 "These are nominal equivalent widths; weights come from the discrete "
                 "convolutions. Only selection weights change; photographs and image "
                 "detail bands stay fixed. The oraple retains a binary finest mask."),
        ),
        page(
            "blend-cat-comparison", "2.4", "Cat blending: boundary and texture",
            p("The direct cut exposes the polygon around the face. Broad feathering mixes "
              "the two coat textures over one wide transition."),
            figure("blend-custom", 1, height=170,
                   caption="Three methods with the same registered inputs and binary "
                           "selection. The mask is initially smoothed at σ = 8 pixels "
                           "before constructing the mask stack."),
            p("Multiresolution blending reduces the coat-color change and retains clearer "
              "tabby detail around the cheek and muzzle. Eye outlines, forehead stripes, "
              "nose and muzzle remain distinct. The gradual transition still contains "
              "differences in muzzle shape and fur direction; blending does not correct anatomy."),
        ),
        page(
            "blend-cat-contributions", "2.4", "Cat contributions at each scale",
            p("A maximum image σ of 16 leaves a more visible facial patch. σ = 32 softens "
              "the coat boundary; σ = 64 spreads the color transition farther into the "
              "surrounding fur without a clear improvement in the fur boundary."),
            figure("blend-custom", 6, height=175),
            note("Supplementary trials compare four, five and six detail bands with other "
                 "inputs fixed. Initial-mask trials compare σ = 0, 2, 4, 8, 12 and 16 "
                 "pixels: a binary mask leaves an abrupt crown texture change, σ = 4 "
                 "leaves a more visible fur boundary, and σ = 12 or 16 mixes a wider "
                 "region of the two coats. The selected σ = 8 balances these effects."),
        ),
        page(
            "blend-planet-registration", "2.4", "Joining Earth and Moon",
            p("An S-shaped boundary joins Earth’s oceans and clouds to lunar craters. "
              "The similar disk outlines support this composite, although the same "
              "photographs did not produce a clear subject change in the hybrid experiment."),
            figure("blend-custom", 7, height=75),
            note("The largest source contours above luminance 0.04 are fitted with "
                 "cv2.fitEllipse and mapped affinely to a circle of radius 220 pixels at "
                 "(256, 256). Thresholding measures the outlines only; the transforms "
                 "sample original RGB pixels. Earth’s axis scale factors differ by 1.06%; "
                 "the Moon’s differ by 0.03%."),
            p("Earth–Moon uses six detail bands, adding image σ = 64 pixels, plus the "
              "coarse residual. The initial mask again uses σ = 8, giving one further "
              "nominal mask width of 64.5 pixels."),
            table("blend-custom", 0),
            note("Boundary jump is the mean absolute RGB difference between adjacent pixels "
                 "on opposite sides of the original binary contour. It includes natural "
                 "texture as well as the seam. Feathering mixes more detail and gives "
                 "smaller values; this alone does not establish a better-looking or "
                 "physically realistic composite. Processing retains signed float64 "
                 "values; only final display images are clipped to [0, 1]."),
        ),
        page(
            "blend-planet-comparison", "2.4", "Planet blending: brightness and detail",
            p("The Earth–Moon blend uses a maximum image σ of 64 pixels because the "
              "brightness mismatch extends across much of the disk. Fewer bands leave "
              "a more visible boundary."),
            figure("blend-custom", 8, height=170,
                   caption="Three methods with the same registered inputs and binary "
                           "selection. Initial mask smoothing at σ = 8 pixels reduces "
                           "the abrupt contrast change where the selection meets the disk outline."),
            p("Multiresolution blending reduces the brightness step and keeps cloud and "
              "crater detail more localized than broad feathering. A binary finest mask "
              "leaves an abrupt outer-edge join; wider masks combine texture across a "
              "larger region. The same six initial widths and four-, five- and six-band "
              "comparisons are retained in the supplementary figures."),
            p("The composite remains an imaginary surface: lunar features do not continue "
              "Earth’s clouds. Smoothing a boundary cannot reconcile different surface structures."),
        ),
        page(
            "blend-color", "2.4", "Color separates the source regions",
            p("The final composites use RGB. The tabby’s coat separates its face from "
              "white fur and orange ears; blue oceans distinguish Earth from the nearly "
              "neutral Moon. These regions are less distinct in grayscale, even though "
              "the boundary is still smoothed."),
            figure("blend-custom", 13, height=175),
            note("Registration, masks and stack settings are identical in this comparison. "
                 "RGB channels are blended independently. Supplementary figures retain "
                 "the matched boundary crops, complete mask stacks, initial-mask sweeps "
                 "and band-count comparisons for both examples."),
            supplements("blend-custom"),
        ),
    ]
